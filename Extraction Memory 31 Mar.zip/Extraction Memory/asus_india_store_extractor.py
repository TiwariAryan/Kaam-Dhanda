import httpx
import json
import csv
import os
import time

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
BASE_URL       = "https://www.asus.com/in/microsite/shop-near-me/"
API_URL        = "https://wheretobuy.asus.in/r/getStoreDetails"
OUTPUT_DIR     = "C:\\Users\\aryan\\Downloads\\31Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}_India.csv"

# Captured Token (Update if expired)
API_TOKEN      = "7d879b6fa4ab37c0980ffc2fba829f27da844508e70f6b12c3b01df4f2fa09ef5ccd43c469e0bba6fb9550f44002db24"

# Coordinate seeds for major Indian cities to trigger local results
# Format: (CityName, Lat, Lng)
CITY_COORDS = [
    ("Mumbai", 19.076, 72.8777),
    ("Delhi", 28.6139, 77.2090),
    ("Bangalore", 12.9716, 77.5946),
    ("Hyderabad", 17.3850, 78.4867),
    ("Ahmedabad", 23.0225, 72.5714),
    ("Chennai", 13.0827, 80.2707),
    ("Kolkata", 22.5726, 88.3639),
    ("Surat", 21.1702, 72.8311),
    ("Pune", 18.5204, 73.8567),
    ("Jaipur", 26.9124, 75.7873),
    ("Lucknow", 26.8467, 80.9462),
    ("Kanpur", 26.4499, 80.3319),
    ("Nagpur", 21.1458, 79.0882),
    ("Indore", 22.7196, 75.8577),
    ("Thane", 19.2183, 72.9781),
    ("Bhopal", 23.2599, 77.4126),
    ("Visakhapatnam", 17.6868, 83.2185),
    ("Patna", 25.5941, 85.1376),
    ("Vadodara", 22.3072, 73.1812),
    ("Ghaziabad", 28.6692, 77.4538),
    ("Ludhiana", 30.9010, 75.8573),
    ("Agra", 27.1767, 78.0081),
    ("Nashik", 19.9975, 73.7898),
    ("Faridabad", 28.4089, 77.3178),
    ("Meerut", 28.9845, 77.7064),
    ("Rajkot", 22.3039, 70.8022),
    ("Varanasi", 25.3176, 82.9739),
    ("Srinagar", 34.0837, 74.7973),
    ("Aurangabad", 19.8762, 75.3433),
    ("Dhanbad", 23.7957, 86.4304),
    ("Amritsar", 31.6340, 74.8723),
    ("Navi Mumbai", 19.0330, 73.0297),
    ("Allahabad", 25.4358, 81.8463),
    ("Howrah", 22.5958, 88.2636),
    ("Gwalior", 26.2183, 78.1828),
    ("Jabalpur", 23.1815, 79.9864),
    ("Coimbatore", 11.0168, 76.9558),
    ("Vijayawada", 16.5062, 80.6480),
    ("Jodhpur", 26.2389, 73.0243),
    ("Madurai", 9.9252, 78.1198),
    ("Raipur", 21.2514, 81.6296),
    ("Kota", 25.2138, 75.8648),
    ("Guwahati", 26.1445, 91.7362),
    ("Chandigarh", 30.7333, 76.7794),
    ("Hubli", 15.3647, 75.1240),
    ("Mysore", 12.2958, 76.6394),
    ("Gurgaon", 28.4595, 77.0266),
    ("Noida", 28.5355, 77.3910),
    ("Kochi", 9.9312, 76.2673),
    ("Dehradun", 30.3165, 78.0322),
    ("Bhubaneswar", 20.2961, 85.8245),
    ("Jammu", 32.7266, 74.8570),
    ("Agartala", 23.8315, 91.2868),
    ("Aizawl", 23.7271, 92.7176),
    ("Imphal", 24.8170, 93.9368),
    ("Kohima", 25.6751, 94.1086),
    ("Shillong", 25.5788, 91.8933),
    ("Itanagar", 27.0844, 93.6053),
    ("Panaji", 15.4909, 73.8278),
    ("Silvassa", 20.2763, 73.0022),
    ("Puducherry", 11.9416, 79.8083),
    ("Port Blair", 11.6234, 92.7265)
]

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

def clean_address(addr):
    if not addr: return ""
    addr = addr.replace("#", "").replace("\n", ", ").replace("\r", "")
    addr = " ".join(addr.split()).strip().strip(", ")
    return addr

def fetch_stores(lat, lng, category="2", token=API_TOKEN):
    headers = {
        "Content-Type": "application/json",
        "Origin": "https://www.asus.com",
        "Referer": "https://www.asus.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "token": token
    }
    
    payload = {
        "lat": lat,
        "lng": lng,
        "city": "", # Keep empty as discovered
        "category": category,
        "recNum": "1000", # Fetch bulk per location
        "exclusive": (category == "2"),
        "multibrand": (category == "1"),
        "search": "",
        "placeId": "",
        "productCategory": "",
        "modelName": "",
        "pincode": ""
    }
    
    try:
        with httpx.Client(timeout=30) as client:
            resp = client.post(API_URL, headers=headers, json=payload)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, dict):
                    return data.get('data', [])
                return []
            else:
                print(f"Error {resp.status_code} at {lat},{lng}: {resp.text}")
                return []
    except Exception as e:
        print(f"Request failed at {lat},{lng}: {e}")
        return []

def extract_india_stores():
    all_stores = {}
    
    for category in ["2", "1"]:
        cat_name = "Exclusive" if category == "2" else "Multi-Brand"
        print(f"Extracting {cat_name} stores...")
        
        for city_name, lat, lng in CITY_COORDS:
            print(f"  Searching near {city_name}...", end="\r")
            stores = fetch_stores(lat, lng, category=category)
            if stores:
                for s in stores:
                    store_id = s.get('storeID')
                    if store_id:
                        all_stores[store_id] = s
            time.sleep(0.5)
            
        print(f"\nUnique stores found so far: {len(all_stores)}")
        
    return list(all_stores.values())

def export_to_csv(stores, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    fields = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for s in stores:
            addr = s.get('address', '')
            if not addr or len(addr) < 5:
                # Fallback to name + city if address is garbage
                addr = (s.get('name', '') + ", " + s.get('city', '')).strip(", ")
                
            activity = "Asus Exclusive Store" if str(s.get('category')) == "2" else "Asus Multi-Brand Store"
            
            row = {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": s.get('name', ''),
                "LOCATION_ADDRESS": clean_address(addr),
                "LATITUDE": s.get('lat', ''),
                "LONGITUDE": s.get('lng', ''),
                "COUNTRY": "India",
                "COUNTRY_ISO3": "IND",
                "POSTCODE": s.get('postal', s.get('pincode', '')),
                "STATE": s.get('state', ''),
                "CITY": s.get('city', ''),
                "SOURCE_URL": BASE_URL,
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": activity,
                "coord_source": "website" if s.get('lat') else ""
            }
            writer.writerow(row)

if __name__ == "__main__":
    data = extract_india_stores()
    export_to_csv(data, os.path.join(OUTPUT_DIR, OUTPUT_FILE))
    print(f"Final Count: {len(data)} India stores extracted.")
