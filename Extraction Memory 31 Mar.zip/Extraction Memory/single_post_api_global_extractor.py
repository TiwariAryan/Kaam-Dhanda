import urllib.request
import json
import csv
import os
import time
from deep_translator import GoogleTranslator

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME     = "HAIDILAO INTERNATIONAL HOLDING LTD."
ISSUER_ID       = "IID000000002921087"
API_ENDPOINT    = "https://www.haidilao.com/eportal/store/listShowStore?country=&language=en"
HTTP_METHOD     = "POST"
BASE_URL        = "https://www.haidilao.com/serve/storeSearch"
SOURCE_TYPE     = "COMPANY WEBSITE"
ACTIVITY        = "Restaurant"
OUTPUT_DIR      = r"C:\Users\aryan\Downloads\31Mar Extractions"
CHECKPOINT_NUM  = 50  # Checkpoint size for writing CSV progress

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

def clean_text(text):
    if not text:
        return ""
    text = str(text).replace("\n", " ").replace("\r", " ").replace("#", "").strip()
    return " ".join(text.split())

def is_chinese_heavy(text):
    if not text: return False
    cjk_count = sum(1 for char in text if '\u4e00' <= char <= '\u9fff')
    return cjk_count > 0

def run_extraction():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_file = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME.replace('/', '_').replace(':', '')}.csv")
    
    headers = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", 
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE", 
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_SOURCE", 
        "coord_source", "LOCATION_NAME_NATIVE", "LOCATION_ADDRESS_NATIVE"
    ]
    
    with open(out_file, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        
    print(f"Fetching data from {API_ENDPOINT} ...", flush=True)
    req = urllib.request.Request(
        API_ENDPOINT,
        method=HTTP_METHOD,
        data=b'',
        headers={'User-Agent': 'Mozilla/5.0'}
    )
    
    res = urllib.request.urlopen(req)
    data = json.loads(res.read().decode('utf-8'))
    
    cities = data.get('value', [])
    if not cities:
        print("No data found!", flush=True)
        return
        
    translator = GoogleTranslator(source='auto', target='en')
    
    count = 0
    buffer = []
    
    # Pre-parse all stores to collect strings to translate
    raw_rows = []
    for city_obj in cities:
        city_name_native = clean_text(city_obj.get("cityName"))
        
        for store in city_obj.get("stores", []):
            name_native = clean_text(store.get("storeName"))
            address_native = clean_text(store.get("storeAddress"))
            
            coord_str = store.get("coordinate", "")
            lat, lng = "", ""
            coord_source = ""
            if coord_str and "," in coord_str:
                parts = coord_str.split(",")
                if len(parts) >= 2:
                    lng, lat = parts[0].strip(), parts[1].strip()
                    coord_source = "Website"
            
            country_code = store.get("countryId", "CN")
            iso3 = country_code
            if country_code == "CN": iso3, country_en = "CHN", "China"
            elif country_code == "MO": iso3, country_en = "MAC", "Macau"
            elif country_code == "HK": iso3, country_en = "HKG", "Hong Kong"
            elif country_code == "TW": iso3, country_en = "TWN", "Taiwan"
            elif country_code == "US": iso3, country_en = "USA", "United States"
            elif country_code == "GB": iso3, country_en = "GBR", "United Kingdom"
            elif country_code == "MY": iso3, country_en = "MYS", "Malaysia"
            elif country_code == "TH": iso3, country_en = "THA", "Thailand"
            elif country_code == "SG": iso3, country_en = "SGP", "Singapore"
            elif country_code == "JP": iso3, country_en = "JPN", "Japan"
            elif country_code == "AU": iso3, country_en = "AUS", "Australia"
            else: country_en = country_code
                
            raw_rows.append({
                "city_native": city_name_native,
                "name_native": name_native,
                "address_native": address_native,
                "lat": lat, "lng": lng, "coord_source": coord_source,
                "iso3": iso3, "country": country_en
            })

    print(f"Total stores prepared for translation: {len(raw_rows)}", flush=True)
    batch_size = 5
    
    # Process batches
    for i in range(0, len(raw_rows), batch_size):
        batch_slice = raw_rows[i:i+batch_size]
        
        # We join Name + ||| + Address + ||| + City for each row, and join rows by \n
        joined_texts = []
        for r in batch_slice:
            s_tr = f"{r['city_native']} ||| {r['name_native']} ||| {r['address_native']}"
            joined_texts.append(s_tr)
            
        full_text = "\n".join(joined_texts)
        
        # Wait to avoid 429
        time.sleep(1)
        
        translated_text = ""
        try:
            translated_text = translator.translate(full_text)
        except Exception as e:
            print("Translate Error:", e, flush=True)
            time.sleep(3)
            try:
                translated_text = translator.translate(full_text)
            except Exception as e2:
                print("Retry Failed!", e2, flush=True)
                translated_text = full_text # fallback to native if everything fails
                
        # Split back
        translated_rows = translated_text.split("\n")
        
        # Check alignment, if translation lost newlines or formatting, fallback
        if len(translated_rows) < len(batch_slice):
            translated_rows = full_text.split("\n")
            
        for idx, row in enumerate(batch_slice):
            tr_line = translated_rows[idx] if idx < len(translated_rows) else ""
            parts = tr_line.split("|||")
            
            c_tr = parts[0].strip() if len(parts) > 0 else row["city_native"]
            n_tr = parts[1].strip() if len(parts) > 1 else row["name_native"]
            a_tr = parts[2].strip() if len(parts) > 2 else row["address_native"]
            
            csv_row = {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": n_tr if n_tr else row["name_native"],
                "LOCATION_ADDRESS": a_tr if a_tr else "N/A",
                "LATITUDE": row["lat"],
                "LONGITUDE": row["lng"],
                "COUNTRY": row["country"],
                "COUNTRY_ISO3": row["iso3"],
                "POSTCODE": "", 
                "STATE": "",    
                "CITY": c_tr if c_tr else "N/A",
                "SOURCE_URL": BASE_URL,
                "SOURCE_TYPE": SOURCE_TYPE,
                "ACTIVITY_AT_SOURCE": ACTIVITY,
                "coord_source": row["coord_source"],
                "LOCATION_NAME_NATIVE": row["name_native"],
                "LOCATION_ADDRESS_NATIVE": row["address_native"]
            }
            buffer.append(csv_row)
            count += 1
            
        print(f"Processed: {count}/{len(raw_rows)}", flush=True)
        
        # Checkpoint writing
        if len(buffer) >= CHECKPOINT_NUM or count == len(raw_rows):
            with open(out_file, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=headers)
                writer.writerows(buffer)
            buffer.clear()
            
    print(f"Extraction complete! Total records: {count}", flush=True)

if __name__ == '__main__':
    run_extraction()
