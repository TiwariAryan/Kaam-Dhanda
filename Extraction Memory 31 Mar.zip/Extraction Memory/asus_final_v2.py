import asyncio
import json
import os
import csv
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

async def extract_asus_india():
    async with async_playwright() as p:
        # Launching with specific arguments to look like a real browser
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080}
        )
        page = await context.new_page()
        
        # 1. Navigate to the page - trigger JS context
        print("Navigating to ASUS India Store Locator...")
        await page.goto("https://www.asus.com/in/microsite/shop-near-me/", wait_until="networkidle")
        await asyncio.sleep(5) 
        
        # 2. Close the modal if it exists (X is at 725, 102 as per subagent)
        try:
            await page.mouse.click(725, 102)
            await asyncio.sleep(1)
        except:
            pass

        # 3. Define the hub coordinates
        HUBS = [
            { "name": "Mumbai", "lat": 19.0760, "lng": 72.8777 },
            { "name": "Delhi", "lat": 28.6139, "lng": 77.2090 },
            { "name": "Bangalore", "lat": 12.9716, "lng": 77.5946 },
            { "name": "Hyderabad", "lat": 17.3850, "lng": 78.4867 },
            { "name": "Chennai", "lat": 13.0827, "lng": 80.2707 },
            { "name": "Kolkata", "lat": 22.5726, "lng": 88.3639 },
            { "name": "Ahmedabad", "lat": 23.0225, "lng": 72.5714 },
            { "name": "Pune", "lat": 18.5204, "lng": 73.8567 },
            { "name": "Jaipur", "lat": 26.9124, "lng": 75.7873 },
            { "name": "Lucknow", "lat": 26.8467, "lng": 80.9462 },
            # Additional hubs for coverage
            { "name": "Surat", "lat": 21.1702, "lng": 72.8311 },
            { "name": "Kanpur", "lat": 26.4499, "lng": 80.3319 },
            { "name": "Nagpur", "lat": 21.1458, "lng": 79.0882 },
            { "name": "Indore", "lat": 22.7196, "lng": 75.8577 },
            { "name": "Thane", "lat": 19.2183, "lng": 72.9781 },
            { "name": "Bhopal", "lat": 23.2599, "lng": 77.4126 },
            { "name": "Visakhapatnam", "lat": 17.6868, "lng": 83.2185 },
            { "name": "Pimpri-Chinchwad", "lat": 18.6298, "lng": 73.7997 },
            { "name": "Patna", "lat": 25.5941, "lng": 85.1376 },
            { "name": "Vadodara", "lat": 22.3072, "lng": 73.1812 }
        ]
        
        all_stores = {}
        
        for hub in HUBS:
            print(f"Extracting near {hub['name']}...")
            # Execute fetch in page context for each hub/category
            for cat in [2, 1]:
                print(f"  Category {cat}...")
                
                # Dynamic fetch logic
                js_fetch = f"""
                async (config) => {{
                    // 1. Get Refresh Token
                    const tResp = await fetch("https://wheretobuy.asus.in/r/gen-token");
                    const tData = await tResp.json();
                    const token = tData.token;
                    
                    // 2. Fetch Details
                    const payload = {{
                        "lat": config.lat,
                        "lng": config.lng,
                        "city": "",
                        "category": String(config.cat),
                        "recNum": "1000",
                        "exclusive": (config.cat === 2),
                        "multibrand": (config.cat === 1),
                        "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
                    }};
                    
                    const resp = await fetch("https://wheretobuy.asus.in/r/getStoreDetails", {{
                        method: "POST",
                        headers: {{
                            "Content-Type": "application/json",
                            "token": token,
                            "referer": "https://www.asus.com/",
                            "origin": "https://www.asus.com"
                        }},
                        body: JSON.stringify(payload)
                    }});
                    return await resp.json();
                }}
                """
                
                try:
                    data = await page.evaluate(js_fetch, {"lat": hub['lat'], "lng": hub['lng'], "cat": cat})
                    if data.get("status") == "SUCCESS" and data.get("data"):
                        found = data["data"]
                        print(f"    Found {len(found)} stores")
                        for s in found:
                            sid = s.get('storeID')
                            if sid: 
                                # Add activity marker for later mapping
                                s['activity_type'] = "Ex" if cat == 2 else "Mb"
                                all_stores[sid] = s
                    else:
                        print(f"    No success status: {data.get('status')}")
                except Exception as e:
                    print(f"    Error: {str(e)[:100]}")
                
                await asyncio.sleep(1) # Rate limit safety
                
        print(f"Total Unique India Stores Captured: {len(all_stores)}")
        await browser.close()
        return all_stores

def finalize(all_stores_dict):
    final_records = []
    
    # 1. Load Global
    global_csv = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    if os.path.exists(global_csv):
        with open(global_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                final_records.append(row)
    
    # 2. Add India
    for s in all_stores_dict.values():
        activity = "Asus Exclusive Store" if s.get('activity_type') == "Ex" else "Asus Multi-Brand Store"
        # Clean Address
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', '')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })
        
    # Standardize and Deduplicate
    # (Simplified deduplication on Name+Address)
    seen = set()
    unique_final = []
    for r in final_records:
        key = (str(r['LOCATION_NAME']).lower().strip(), str(r['LOCATION_ADDRESS']).lower().strip())
        if key not in seen:
            unique_final.append(r)
            seen.add(key)
            
    # Write output
    output_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(unique_final)
        
    print(f"\nFinal Consolidated File Created: {output_path}")
    print(f"Total Unique Records: {len(unique_final)}")
    return len(unique_final)

if __name__ == "__main__":
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        india_stores = loop.run_until_complete(extract_asus_india())
        finalize(india_stores)
    finally:
        loop.close()
