"""
AEM /bin/ocp Servlet General Extractor
======================================
This generalized script targets AEM backends that expose JSON via the /bin/ocp servlet directly 
(e.g., apiName=getContentByCategory). It handles dual-fetch for retrieving both English AND 
native-language data cleanly via Accept-Language headers, automatically merging them.

CONFIGURATION INSTRUCTIONS:
Set the variables in the CONFIGURATION block to match the specific issuer.

Run this script directly to produce a compliant CSV.
"""

import json
import csv
import urllib.request
import re
import os
import sys

# Windows UTF-8 console output fix
sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "SAUDI TELECOM COMPANY SJSC"
ISSUER_ID      = "IID000000002153141"
BASE_URL       = "https://www.stc.com.sa"
SOURCE_URL     = "https://www.stc.com.sa/en/personal/support/contact-us/business-offices-coverage-maps.html#listview"

API_ENDPOINT   = "https://www.stc.com.sa/bin/ocp?apiName=getContentByCategory&category=offices"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\28Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

# Global Defaults
COUNTRY        = "Saudi Arabia"
COUNTRY_ISO3   = "SAU"
SOURCE_TYPE    = "Facility"
# ═══════════════════════════════════════════════════════════

def fetch_data(lang="en"):
    """Fetch the API data with a specific Accept-Language header."""
    print(f"Fetching API with language: {lang} ...")
    req = urllib.request.Request(API_ENDPOINT, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        "x-requested-with": "XMLHttpRequest",
        "accept": "application/json, text/javascript, */*; q=0.01",
        "referer": SOURCE_URL,
        "accept-language": lang,
        "sec-ch-ua-platform": '"Windows"',
        "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
        "sec-ch-ua-mobile": "?0"
    })
    
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        print(f"Error fetching data for language {lang}: {e}")
        return None

def clean_address(address):
    """Clean the address string, removing '#' for geocoding safety."""
    if not address: return ""
    addr = str(address).replace("#", "")
    addr = re.sub(r'\s+', ' ', addr).strip()
    return addr

def run_extraction():
    # 1. Fetch English Baseline
    data_en = fetch_data("en")
    # 2. Fetch Native (Arabic) Data
    data_ar = fetch_data("ar")
    
    if not data_en or 'content' not in data_en:
        print("Failed to fetch primary english content.")
        return
        
    records_en = data_en.get("content", [])
    records_ar = data_ar.get("content", []) if data_ar else []
    
    print(f"Loaded {len(records_en)} English records.")
    print(f"Loaded {len(records_ar)} Arabic records (for native fields cross-reference).")
    
    # Map Arabic records by ID or Key for fast lookup
    ar_map = {}
    for r in records_ar:
        k = r.get("key")
        ar_map[k] = r.get("message", {})
        
    final_rows = []
    
    for en_item in records_en:
        key = en_item.get("key")
        en_msg = en_item.get("message", {})
        ar_msg = ar_map.get(key, {})
        
        # Primary English Fields
        loc_name = en_msg.get("name", "").strip()
        loc_city = en_msg.get("city", "").strip()
        loc_area = en_msg.get("area", "").strip()
        lat = en_msg.get("lat", "")
        lng = en_msg.get("long", "")
        # Activity from source 'type'
        source_activity = en_msg.get("type", "Office")
        coord_source = "Website" if (lat and lng and lat != "0" and lat != "") else ""
        
        # Address composition
        addr_parts = [loc_name]
        if loc_city and loc_city.lower() not in loc_name.lower(): addr_parts.append(loc_city)
        if loc_area and loc_area.lower() not in loc_city.lower(): addr_parts.append(loc_area)
        en_address = clean_address(", ".join(addr_parts))
        
        # Native Language Fields
        ar_name = ar_msg.get("name", "").strip()
        ar_city = ar_msg.get("city", "").strip()
        ar_area = ar_msg.get("area", "").strip()
        
        ar_addr_parts = [ar_name]
        if ar_city and ar_city not in ar_name: ar_addr_parts.append(ar_city)
        if ar_area and ar_area not in ar_city: ar_addr_parts.append(ar_area)
        ar_address = clean_address("\u060C ".join(ar_addr_parts)) # Arabic comma
        
        row = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": loc_name,
            "LOCATION_ADDRESS": en_address,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "COUNTRY": COUNTRY,
            "COUNTRY_ISO3": COUNTRY_ISO3,
            "POSTCODE": "",
            "STATE": loc_area,
            "CITY": loc_city,
            "SOURCE_URL": SOURCE_URL,
            "SOURCE_TYPE": SOURCE_TYPE,
            "ACTIVITY_AT_SOURCE": source_activity,
            "coord_source": coord_source,
            "FACILITY_NAME_LOCAL": ar_name,
            "FACILITY_ADDRESS_LOCAL": ar_address
        }
        
        if en_address: # As per requirements, FACILITY_ADDRESS cannot be blank.
            final_rows.append(row)
            
    # Output to CSV
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, OUTPUT_FILE)
    
    headers = ["ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", 
               "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE", 
               "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_SOURCE", 
               "coord_source", "FACILITY_NAME_LOCAL", "FACILITY_ADDRESS_LOCAL"]
               
    print(f"Writing {len(final_rows)} records to {out_path} ...")
    with open(out_path, mode="w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for r in final_rows:
            writer.writerow(r)
            
    print("Extraction complete!")

if __name__ == "__main__":
    run_extraction()
