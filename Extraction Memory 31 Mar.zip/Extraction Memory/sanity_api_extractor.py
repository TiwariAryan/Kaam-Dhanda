"""
Extraction Script for Sanity CMS API
Pattern: Sanity API Extractor (GROQ API)

This pattern handles modern headless CMS architectures (Next.js + Sanity) where 
data is fetched client-side or server-side via Sanity's REST API using GROQ queries.
Instead of parsing large HTML or RSC blocks, it queries the API directly.

To configure for a new issuer:
1. Find the Sanity Project ID (e.g., from image URLs `cdn.sanity.io/images/<PROJECT_ID>/...`).
2. Construct the GROQ query based on the `_type` and fields needed.
3. Update specific mappings below.
"""

import urllib.request
import urllib.parse
import json
import csv
import os
import ssl
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME       = "AYALA LAND INC."
ISSUER_ID         = "IID000000002158574"
SANITY_PROJECT_ID = "4f3ey4m9"
SANITY_DATASET    = "production"
SANITY_VERSION    = "v2021-10-21"

# GROQ query to extract complete dataset
GROQ_QUERY = '''*[_type == "propertyDocument"] {
  "id": _id,
  name,
  "slug": slug.current,
  "location": location->name,
  "address": location->address,
  "brand": brand->name,
  status,
  geopoint
}'''

OUTPUT_DIR     = r"C:\Users\aryan\Downloads\28Mar Extractions"
OUTPUT_FILE    = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}.csv")
MEMORY_DIR     = r"C:\Users\aryan\Downloads\Extraction Memory 28 Mar\Extraction Memory"
PROGRESS_FILE  = os.path.join(MEMORY_DIR, f"{ISSUER_ID}_progress.json")

# Mapping Config
COUNTRY        = "Philippines"
COUNTRY_ISO3   = "PHL"
ACTIVITY       = "Real Estate Property"
BASE_URL       = "https://ayalaland.com.ph/properties/"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW
# ═══════════════════════════════════════════════════════════

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_sanity_data(query: str) -> list:
    encoded = urllib.parse.quote(query)
    url = f"https://{SANITY_PROJECT_ID}.api.sanity.io/{SANITY_VERSION}/data/query/{SANITY_DATASET}?query={encoded}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    print(f"Fetching from Sanity API: {url}")
    with urllib.request.urlopen(req, context=ctx) as response:
        text = response.read().decode('utf-8')
        return json.loads(text).get('result', [])

def save_checkpoint(records, offset):
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump({"offset": offset, "records": records}, f)
    print(f"[CHECKPOINT] Saved {offset} records to {PROGRESS_FILE}.")

def load_checkpoint():
    if Path(PROGRESS_FILE).exists():
        with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            print(f"[RESUME] Resuming from offset {data.get('offset', 0)}")
            return data.get("records", []), data.get("offset", 0)
    return [], 0

def clean_text(text: str) -> str:
    if not text:
        return ""
    # Remove # characters for geocoding
    text = str(text).replace("#", "").replace("\n", " ").strip()
    return text

def append_to_csv(headers, rows, filepath, write_headers=False):
    mode = 'w' if write_headers else 'a'
    with open(filepath, mode, newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        if write_headers:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)

def run_extraction():
    all_raw_data = fetch_sanity_data(GROQ_QUERY)
    total_records = len(all_raw_data)
    print(f"Discovered {total_records} total records from API.")

    processed_records, offset = load_checkpoint()

    headers = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS",
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3",
        "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source", "FACILITY_REGION",
        "FACILITY_NAME", "FACILITY_ADDRESS"
    ]

    # Initialize CSV if starting fresh
    if offset == 0:
        append_to_csv(headers, [], OUTPUT_FILE, write_headers=True)

    batch = []
    
    for idx in range(offset, total_records):
        raw = all_raw_data[idx]
        
        name = clean_text(raw.get("name", ""))
        location_city = clean_text(raw.get("location", ""))
        address = clean_text(raw.get("address", ""))
        
        # Address logic: property Address if exists, else use Location/City name as address since it can't be blank.
        final_address = address if address else location_city
        if not final_address:
            final_address = name  # Fallback
            
        slug = raw.get("slug", "")
        source_url = f"{BASE_URL}{slug}" if slug else "https://ayalaland.com.ph/properties/"
        
        lat = ""
        lng = ""
        coord_source = "none"
        geopoint = raw.get("geopoint")
        if geopoint and isinstance(geopoint, dict):
            lat = geopoint.get("lat", "")
            lng = geopoint.get("lng", "")
            if lat and lng:
                coord_source = "website"

        row = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": name,
            "LOCATION_ADDRESS": final_address,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "COUNTRY": COUNTRY,
            "COUNTRY_ISO3": COUNTRY_ISO3,
            "POSTCODE": "",
            "STATE": "",
            "CITY": location_city,
            "SOURCE_URL": source_url,
            "SOURCE_TYPE": "API",
            "ACTIVITY_AT_SOURCE": ACTIVITY,
            "coord_source": coord_source,
            "FACILITY_REGION": COUNTRY,
            "FACILITY_NAME": "",
            "FACILITY_ADDRESS": ""
        }
        
        batch.append(row)
        processed_records.append(row)
        
        current_offset = idx + 1
        # Progress threshold (checkpoint every 20)
        if current_offset % 20 == 0 or current_offset == total_records:
            save_checkpoint(processed_records, current_offset)
            append_to_csv(headers, batch, OUTPUT_FILE, write_headers=False)
            print(f"[CSV] Appended {len(batch)} records to CSV. Total exported: {current_offset}")
            batch = []

    print(f"Extraction complete! Total {len(processed_records)} records saved to {OUTPUT_FILE}.")

if __name__ == "__main__":
    run_extraction()

