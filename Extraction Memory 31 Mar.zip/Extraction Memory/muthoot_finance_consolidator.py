import pandas as pd
import os
from pathlib import Path

OUTPUT_DIR = r"C:\Users\aryan\Downloads\ACWI Geo Analysts Gap Collection"
AUTO_CSV = Path(OUTPUT_DIR) / "muthoot_gap_fill.csv"
MANUAL_CSV = Path(OUTPUT_DIR) / "muthoot_gap_fill_manual.csv"
HOMEFIN_CSV = Path(OUTPUT_DIR) / "muthoot_gap_fill_homefin.csv"
FINAL_CSV = Path(OUTPUT_DIR) / "muthoot_finance_assets_final.csv"

def consolidate():
    dfs = []
    
    if AUTO_CSV.exists():
        print(f"Loading automated results from {AUTO_CSV}")
        df_auto = pd.read_csv(AUTO_CSV, encoding='utf-8-sig')
        dfs.append(df_auto)
        print(f"  Found {len(df_auto)} automated records")
    else:
        print(f"Warning: {AUTO_CSV} not found yet.")

    if MANUAL_CSV.exists():
        print(f"Loading manual results from {MANUAL_CSV}")
        df_manual = pd.read_csv(MANUAL_CSV, encoding='utf-8-sig')
        dfs.append(df_manual)
        print(f"  Found {len(df_manual)} manual records")

    if HOMEFIN_CSV.exists():
        print(f"Loading Homefin results from {HOMEFIN_CSV}")
        df_home = pd.read_csv(HOMEFIN_CSV, encoding='utf-8-sig')
        dfs.append(df_home)
        print(f"  Found {len(df_home)} Homefin records")

    if not dfs:
        print("No data to consolidate.")
        return

    # Combine
    df_combined = pd.concat(dfs, ignore_index=True)
    
    # Deduplicate primarily by name + address
    before = len(df_combined)
    # We want to keep the manual ones if there's a conflict since they are higher quality
    # So we sort by manual being at the top, or just use keep='last' if we appended manual last
    # Manual was appended last in dfs list.
    df_combined = df_combined.drop_duplicates(subset=['FACILITY_NAME', 'FACILITY_ADDRESS'], keep='last')
    after = len(df_combined)
    print(f"Deduplication: {before} -> {after} ({before-after} removed)")

    # Standardize column order
    expected_cols = [
        'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
        'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL', 'BUSINESS_ACTIVITY'
    ]
    
    # Fill missing expected columns with empty strings
    for col in expected_cols:
        if col not in df_combined.columns:
            df_combined[col] = ''
            
    df_final = df_combined[expected_cols]
    
    # Final data cleaning
    df_final['ISSUER_ID'] = 'IID000000002618636'
    df_final['ISSUER_NAME'] = 'MUTHOOT FINANCE LIMITED'
    
    # Save
    df_final.to_csv(FINAL_CSV, index=False, encoding='utf-8-sig')
    print(f"Successfully saved {len(df_final)} records to {FINAL_CSV}")

if __name__ == "__main__":
    consolidate()
