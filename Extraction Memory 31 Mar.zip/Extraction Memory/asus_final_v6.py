import asyncio
import os
import csv
import json
import httpx
import string
import itertools
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

async def get_session():
    print("Launching Playwright to bypass WAF and generate session token...")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        await page.goto("https://wheretobuy.asus.in/r/gen-token", wait_until="networkidle", timeout=60000)
        
        text = await page.inner_text("body")
        token = json.loads(text).get('token')
        cookies = {c['name']: c['value'] for c in await context.cookies()}
        
        await browser.close()
        return token, cookies

async def fetch_auto_search(client, token, kw, semaphore):
    async with semaphore:
        url = f"https://wheretobuy.asus.in/r/auto-search?kw={kw}"
        try:
            resp = await client.get(url, headers={"token": token}, timeout=10.0)
            if resp.status_code == 200:
                d = resp.json()
                results = d.get('results', d.get('data', []))
                return results if isinstance(results, list) else []
        except:
            pass
    return []

async def get_all_cities(client, token):
    print("Generating alphabetical combinations for autocomplete dictionary exhaustive sweep...")
    combos = [''.join(p) for p in itertools.product(string.ascii_lowercase, repeat=2)] # 676 combinations
    
    unique_cities = {}
    semaphore = asyncio.Semaphore(50)
    
    tasks = [fetch_auto_search(client, token, kw, semaphore) for kw in combos]
    print(f"Executing {len(tasks)} autocomplete requests...")
    
    completed = 0
    for future in asyncio.as_completed(tasks):
        results = await future
        completed += 1
        for r in results:
            desc = r.get('description', '')
            val = r.get('value', desc)
            if val:
                unique_cities[val] = {"name": val, "place_id": r.get('place_id', r.get('placeId', ''))}
                
    print(f"Discovered {len(unique_cities)} unique verified geographical entities.")
    return list(unique_cities.values())

async def fetch_stores(client, token, city, category, semaphore):
    async with semaphore:
        url = "https://wheretobuy.asus.in/r/getStoreDetails"
        headers = {
            "Content-Type": "application/json",
            "token": token,
            "origin": "https://www.asus.com",
            "referer": "https://www.asus.com/"
        }
        
        payload = {
            "lat": 0.0, "lng": 0.0,
            "city": city['name'],
            "category": "2",
            "recNum": "5000",
            "exclusive": (category == 2),
            "multibrand": (category == 1),
            "search": city['name'],
            "placeId": city['place_id'],
            "productCategory": "", "modelName": "", "pincode": ""
        }
        try:
            resp = await client.post(url, headers=headers, json=payload, timeout=20.0)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "SUCCESS" and "stores" in data:
                    return category, data["stores"]
        except:
            pass
    return category, []

async def extract_asus_india():
    token, cookies = await get_session()
    
    timeout = httpx.Timeout(20.0, read=40.0)
    async with httpx.AsyncClient(cookies=cookies, timeout=timeout) as client:
        # Phase 1: Exhaustive Dictionary Discovery
        cities = await get_all_cities(client, token)
        
        # Phase 2: Iterate Verified Cities
        semaphore = asyncio.Semaphore(100)
        tasks = []
        for city in cities:
            tasks.append(fetch_stores(client, token, city, 2, semaphore))
            tasks.append(fetch_stores(client, token, city, 1, semaphore))
            
        print(f"Executing {len(tasks)} targeted store queries based on unique verified places...")
        all_stores = {}
        for future in asyncio.as_completed(tasks):
            cat, stores = await future
            for s in stores:
                sid = s.get('storeId') or s.get('id') or f"{s.get('lat')}_{s.get('lng')}"
                if sid and sid not in all_stores:
                    s['activity_type'] = "Ex" if cat == 2 else "Mb"
                    all_stores[sid] = s
                    
    print(f"Total Unique India Stores Captured: {len(all_stores)}")
    return all_stores

def finalize(all_stores_dict):
    final_records = []
    
    global_csv = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    if os.path.exists(global_csv):
        with open(global_csv, 'r', encoding='utf-8') as f:
            for row in csv.DictReader(f):
                final_records.append(row)
        print(f"Merged {len(final_records)} global records.")
    
    for s in all_stores_dict.values():
        activity = "Asus Exclusive Store" if s.get('activity_type') == "Ex" else "Asus Multi-Brand Store"
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', 'ASUS Store')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })
        
    deduped = []
    seen = set()
    for r in final_records:
        key = (str(r['LOCATION_NAME']).lower().strip(), str(r['LOCATION_ADDRESS']).lower().strip())
        if key not in seen:
            deduped.append(r)
            seen.add(key)
            
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(deduped)
        
    print(f"Final CSV saved: {out_path}")
    print(f"Total Unique Assets: {len(deduped)}")

if __name__ == "__main__":
    try:
        india_stores = asyncio.run(extract_asus_india())
        finalize(india_stores)
    except Exception as e:
        print(f"Execution failed: {e}")
