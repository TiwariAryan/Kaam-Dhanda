"""
Mapplic jQuery Map Plugin Extractor
====================================
Platform Pattern: WordPress + Mapplic jQuery plugin with per-country JSON data files.

This script extracts facility/asset data from websites using the Mapplic jQuery
interactive map plugin. Data is typically stored in JSON files segmented by 
country and asset category index.

The key structure: each JSON has a root-level `locations` array. Each location 
represents a state/region or an individual facility. If it's a region, individual 
facility names are often stored as HTML <p> tags in the `description` field.

URL Pattern:
    {BASE_URL}/themes/custom/{THEME}/assets/mapplic/data/data-{country_slug}-{index}.json

Requirements:
    - requests (pip install requests)
    - json, csv, re, time, os (built-in)

Usage:
    1. Set the CONFIGURATION block below for the target issuer.
    2. Adjust COUNTRY_SLUGS based on discovered file indices.
    3. Run: python mapplic_map_extractor.py
"""

import requests
import json
import csv
import sys
import os
import re
import time

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME = "SD GUTHRIE BERHAD"
ISSUER_ID = "IID000000002727794"
BASE_URL = "https://www.sdguthrie.com"
THEME_PATH = "/themes/custom/sdguthrie_theme/assets/mapplic/data"
SOURCE_URL = "https://www.sdguthrie.com/who-we-are/worldwide"
OUTPUT_DIR = r"C:\Users\aryan\Downloads\28Mar Extractions"

# Country slug -> max index discovered on the map
COUNTRY_SLUGS = {
    "malaysia": 13,
    "indonesia": 9,
    "singapore": 2,
    "thailand": 2,
    "uk": 1,
    "netherland": 3,
    "south-africa": 2,
    "papua": 11,
    "usa": 1,
    "solomon": 4,
}

# Country name mapping
COUNTRY_NAME_MAP = {
    "malaysia": "Malaysia",
    "indonesia": "Indonesia",
    "singapore": "Singapore",
    "thailand": "Thailand",
    "uk": "United Kingdom",
    "netherland": "Netherlands",
    "south-africa": "South Africa",
    "papua": "Papua New Guinea",
    "usa": "United States",
    "solomon": "Solomon Islands",
}

# ISO3 mapping
COUNTRY_ISO3_MAP = {
    "Malaysia": "MYS",
    "Indonesia": "IDN",
    "Singapore": "SGP",
    "Thailand": "THA",
    "United Kingdom": "GBR",
    "Netherlands": "NLD",
    "South Africa": "ZAF",
    "Papua New Guinea": "PNG",
    "United States": "USA",
    "Solomon Islands": "SLB",
}

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

def fetch_json(url):
    """Fetch JSON with session headers."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json, text/plain, */*",
        "Referer": SOURCE_URL,
    }
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            return resp.json()
        return None
    except Exception as e:
        print(f"  [ERROR] {url}: {e}")
        return None

def detect_category(text):
    """Detect facility category from its name."""
    text_lower = text.lower()
    
    # Specific keywords for classification
    category_keywords = [
        ("biogas", "Biogas Plant"),
        ("biodiesel", "Biodiesel Plant"),
        ("kernel crushing", "Kernel Crushing Plant"),
        ("copra crushing", "Copra Crushing Plant"),
        ("copra", "Copra Processing"),
        ("refinery", "Refinery"),
        ("refining", "Refinery"),
        ("oleochemical", "Oleochemical Plant"),
        ("downstream", "Downstream Manufacturing"),
        ("abattoir", "Livestock Processing"),
        ("oil mill", "Palm Oil Mill"),
        ("palm oil mill", "Palm Oil Mill"),
        ("kernel mill", "Palm Oil Mill"),
        ("sugar mill", "Sugar Mill"),
        ("mill", "Palm Oil Mill"),
        ("factory", "Palm Oil Mill / Factory"),
        ("estate", "Oil Palm Estate / Plantation"),
        ("plantation", "Oil Palm Estate / Plantation"),
        ("research", "Research & Development"),
        ("r&d", "Research & Development"),
        ("tech center", "Research & Development"),
        ("tech centre", "Research & Development"),
        ("technology", "Research & Development"),
        ("laboratory", "Research & Development"),
        ("lab", "Research & Development"),
        ("seeds", "Seed Production"),
        ("nursery", "Nursery"),
        ("headquarters", "Corporate Headquarters"),
        ("office", "Office"),
        ("sales", "Sales Office"),
        ("bulking", "Bulking Terminal"),
        ("terminal", "Bulking Terminal"),
        ("rubber", "Rubber Processing"),
        ("cocoa", "Cocoa Processing"),
        ("sugar", "Sugar Processing"),
        ("cattle", "Cattle Ranch"),
    ]
    
    for keyword, category in category_keywords:
        if keyword in text_lower:
            return category
            
    # Hint for grouped estate names common in SD Guthrie
    if "+" in text and len(text) < 100:
        return "Oil Palm Estate / Plantation"
    
    return "Facility"

def clean_text(text):
    """Remove HTML tags, #, and normalize whitespace."""
    if not text: return ""
    text = re.sub(r'<[^>]+>', ', ', text)
    text = text.replace('#', '')
    text = re.sub(r',\s*,', ',', text)
    text = re.sub(r'\s+', ' ', text).strip(', ')
    return text

def parse_mapplic_json(data, country_slug, index):
    """Extract individual facilities from Mapplic JSON data."""
    extracted = []
    country_name = COUNTRY_NAME_MAP.get(country_slug, country_slug.title())
    country_iso3 = COUNTRY_ISO3_MAP.get(country_name, "")
    
    locations = data.get("locations", [])
    for loc in locations:
        state = loc.get("title", "").strip()
        description = loc.get("description", "").strip()
        
        # Extract individual facility names from <p> tags
        facility_names = re.findall(r'<p>(.*?)</p>', description, re.DOTALL)
        if not facility_names and description:
            # Fallback for simple description
            facility_names = [description]
            
        for name_html in facility_names:
            name = clean_text(name_html)
            if not name: continue
            
            activity = detect_category(name)
            
            # Source coordinates if present
            lat = loc.get("lat", "")
            lng = loc.get("lng", "")
            
            # Build clean address
            address = f"{name}, {state}, {country_name}"
            address = clean_text(address)
            
            extracted.append({
                "ISSUER_ID": ISSUER_ID,
                "LOCATION_NAME": name,
                "LOCATION_ADDRESS": address,
                "LATITUDE": str(lat) if lat else "",
                "LONGITUDE": str(lng) if lng else "",
                "COUNTRY": country_name,
                "COUNTRY_ISO3": country_iso3,
                "POSTCODE": "",
                "STATE": state,
                "CITY": "",
                "SOURCE_URL": SOURCE_URL,
                "SOURCE_TYPE": "Website Map JSON",
                "ACTIVITY_AT_SOURCE": activity,
                "coord_source": "website" if lat and lng else ""
            })
            
    return extracted

def main():
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
        
    all_facilities = []
    print(f"Starting extraction for {ISSUER_NAME}...")
    
    for slug, max_idx in COUNTRY_SLUGS.items():
        print(f"Processing {slug} ({max_idx} files)...")
        for i in range(1, max_idx + 1):
            url = f"{BASE_URL}{THEME_PATH}/data-{slug}-{i}.json"
            data = fetch_json(url)
            if data:
                recs = parse_mapplic_json(data, slug, i)
                all_facilities.extend(recs)
                print(f"  File {i}: Found {len(recs)} records")
            time.sleep(0.1) # Polite delay
            
    # Deduplicate
    unique_data = {}
    for f in all_facilities:
        key = (f["LOCATION_NAME"].lower(), f["STATE"].lower(), f["COUNTRY"].lower())
        if key not in unique_data:
            unique_data[key] = f
            
    final_list = list(unique_data.values())
    print(f"Extraction complete. Found {len(all_facilities)} total, {len(final_list)} unique.")
    
    output_file = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME.replace(' ', '_')}.csv")
    fieldnames = [
        "ISSUER_ID", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", 
        "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE", 
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", 
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(output_file, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_list)
        
    print(f"CSV saved to: {output_file}")

if __name__ == "__main__":
    main()
