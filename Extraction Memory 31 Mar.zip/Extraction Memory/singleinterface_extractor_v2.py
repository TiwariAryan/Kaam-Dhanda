"""
AU Small Finance Bank — SingleInterface Branch Extractor FINAL
===============================================================
Platform  : SingleInterface (locate.au.bank.in), master_outlet_id=99682
URL format: /location/{state-slug}/{city-slug} — data server-rendered in HTML
            No Search button click needed. Pagination via ?page=N (max 20 pages safety cap).

Key insights discovered during development:
  1. ?state_name=X&city_name=Y params → 404/no cards (documented ❌)
  2. /location/{state}/{city} → data is server-rendered in initial HTML
  3. Search button click is for analytics only, not data loading
  4. Pagination uses ?page=N — stop when page has 0 new cards vs prev page
  5. AP/early cities get 0 because browser hasn't warmed up — first 5s after launch
  6. Simple requests (no Playwright) works for data extraction since HTML is static!

Usage:
  python au_sfb_final_extractor.py

Output:
  au_sfb_output/AU_SFB_branches_YYYYMMDD_HHMMSS.csv
"""

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
import sys, json, re, time, warnings
from pathlib import Path
from datetime import datetime

warnings.filterwarnings("ignore")
sys.stdout.reconfigure(encoding='utf-8')

ISSUER_NAME   = "AU Small Finance Bank Limited"
ISSUER_ID     = "IID000000002158574"
BASE_URL      = "https://locate.au.bank.in"
MASTER_OUTLET = 99682
OUTPUT_DIR    = Path("au_sfb_output")
PROGRESS_FILE = OUTPUT_DIR / "progress_final.json"
OUTLETS_FILE  = OUTPUT_DIR / "outlets_final.json"
STATE_CITY_FILE = OUTPUT_DIR / "state_city_map.json"  # already built

MAX_PAGES = 15  # Safety cap — most cities have ≤3 pages of 6 outlets each

# ═══════════════════════════════════════════════════════════════
OUTPUT_DIR.mkdir(exist_ok=True)

import requests
from bs4 import BeautifulSoup
import pandas as pd

# requests session with browser-like headers
session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Referer': BASE_URL + '/',
    'Connection': 'keep-alive',
})

def log(msg): print(msg, flush=True)

# ── Pincode → State fallback ──────────────────────────────────
PINCODE_STATE = {
    '11':'Delhi','12':'Haryana','13':'Haryana','14':'Punjab',
    '15':'Himachal Pradesh','16':'Punjab','17':'Himachal Pradesh',
    '18':'Jammu and Kashmir','19':'Jammu and Kashmir',
    '20':'Uttar Pradesh','21':'Uttar Pradesh','22':'Uttar Pradesh',
    '23':'Uttar Pradesh','24':'Uttar Pradesh','25':'Uttar Pradesh',
    '26':'Uttarakhand','27':'Uttar Pradesh','28':'Uttar Pradesh','29':'Uttarakhand',
    '30':'Rajasthan','31':'Rajasthan','32':'Rajasthan','33':'Rajasthan',
    '34':'Rajasthan','35':'Rajasthan',
    '36':'Gujarat','37':'Gujarat','38':'Gujarat','39':'Gujarat',
    '40':'Maharashtra','41':'Maharashtra','42':'Maharashtra','43':'Maharashtra',
    '44':'Maharashtra','45':'Madhya Pradesh','46':'Madhya Pradesh',
    '47':'Madhya Pradesh','48':'Madhya Pradesh','49':'Chhattisgarh',
    '50':'Telangana','51':'Andhra Pradesh','52':'Andhra Pradesh',
    '53':'Andhra Pradesh','54':'Andhra Pradesh',
    '55':'Karnataka','56':'Karnataka','57':'Karnataka','58':'Karnataka','59':'Karnataka',
    '60':'Tamil Nadu','61':'Tamil Nadu','62':'Tamil Nadu','63':'Tamil Nadu',
    '64':'Tamil Nadu','65':'Tamil Nadu','66':'Tamil Nadu',
    '67':'Kerala','68':'Kerala','69':'Kerala',
    '70':'West Bengal','71':'West Bengal','72':'West Bengal','73':'West Bengal',
    '74':'West Bengal','75':'Odisha','76':'Odisha','77':'Odisha',
    '78':'Assam','79':'Assam',
    '80':'Bihar','81':'Bihar','82':'Jharkhand','83':'Jharkhand','84':'Bihar','85':'Bihar',
    '403':'Goa',
}
def state_from_pin(pin):
    if not pin or len(pin)<2: return ""
    if pin[:3] in PINCODE_STATE: return PINCODE_STATE[pin[:3]]
    return PINCODE_STATE.get(pin[:2], "")


# ── Card parser ───────────────────────────────────────────────
def parse_cards(html, state_name, city_name):
    soup = BeautifulSoup(html, 'html.parser')
    cards = soup.find_all('div', class_='store-info-box')
    results = []
    for card in cards:
        o = {
            'ISSUER_ID': ISSUER_ID, 'ISSUER_NAME': ISSUER_NAME,
            'STATE': state_name, 'CITY': city_name, 'COUNTRY': 'India',
            'POSTAL_CODE': '', 'FACILITY_CONTACT_NUMBER': '',
            'FACILITY_REGION': '',
        }

        lat = card.find('input', class_='outlet-latitude')
        lng = card.find('input', class_='outlet-longitude')
        o['LATITUDE']  = lat.get('value','').strip() if lat else ''
        o['LONGITUDE'] = lng.get('value','').strip() if lng else ''

        name_a = card.find('a', attrs={'data-track-event-business-name': True})
        if name_a:
            o['FACILITY_NAME'] = name_a.get('data-track-event-business-name','').strip()
            o['CITY']  = name_a.get('data-track-event-city',  city_name).strip()  or city_name
            o['STATE'] = name_a.get('data-track-event-state', state_name).strip() or state_name
            href = name_a.get('href','').strip()
            o['RELEVANT_URL'] = href
            m = re.search(r'-(\d{4,10})/Home', href)
            if m: o['_oid'] = m.group(1)

        addr_li = card.find('li', class_='outlet-address')
        if addr_li:
            parts = [s.get_text(strip=True) for s in addr_li.find_all('span') if s.get_text(strip=True)]
            o['FACILITY_ADDRESS'] = ', '.join(parts)
            for p in parts:
                if re.match(r'^\d{6}$', p): o['POSTAL_CODE'] = p

        ph = card.find('a', href=re.compile(r'^tel:'))
        o['FACILITY_CONTACT_NUMBER'] = ph.get_text(strip=True) if ph else ''

        # Category detection
        cat = ''
        for sel in ['store-category','outlet-category','store-type','outlet-type']:
            el = card.find(class_=re.compile(sel, re.I))
            if el: cat = el.get_text(strip=True).lower(); break
        if 'mfi' in cat or 'microfinance' in cat:
            o['BUSINESS_ACTIVITY'] = 'Microfinance Branch'
        elif 'loan' in cat:
            o['BUSINESS_ACTIVITY'] = 'Loan Centre'
        elif 'atm' in cat:
            o['BUSINESS_ACTIVITY'] = 'ATM'
        else:
            o['BUSINESS_ACTIVITY'] = 'Banking'

        results.append(o)
    return results


def dedup_key(o):
    oid = o.get('_oid')
    if oid: return oid
    lat, lng = o.get('LATITUDE',''), o.get('LONGITUDE','')
    if lat and lng and lat != '0' and lng != '0': return f"ll:{lat},{lng}"
    name = o.get('FACILITY_NAME','').lower().strip()
    addr = o.get('FACILITY_ADDRESS','').lower().strip()[:50]
    return f"na:{name}|{addr}"


def fetch_city(state_slug, city_slug, state_name, city_name):
    """Fetch all pages for a city using requests (no Playwright needed — data is static HTML)."""
    city_outlets = []
    seen_oids = set()
    
    for page_num in range(1, MAX_PAGES + 1):
        if page_num == 1:
            url = f"{BASE_URL}/location/{state_slug}/{city_slug}"
        else:
            url = f"{BASE_URL}/location/{state_slug}/{city_slug}?page={page_num}"

        try:
            r = session.get(url, timeout=15, verify=False)
            if r.status_code != 200:
                break
        except Exception as e:
            log(f"    fetch error p{page_num}: {e}")
            break

        cards = parse_cards(r.text, state_name, city_name)
        if not cards:
            break  # No cards on this page → all pages exhausted

        # Count genuinely new cards to detect pagination end
        new_this_page = 0
        for c in cards:
            k = dedup_key(c)
            if k not in seen_oids:
                seen_oids.add(k)
                city_outlets.append(c)
                new_this_page += 1

        if new_this_page == 0:
            break  # Pagination is looping (same cards again) → stop

        # Check if there's actually a next page link
        soup = BeautifulSoup(r.text, 'html.parser')
        has_next = bool(
            soup.find('a', string=re.compile(r'next|›|»', re.I)) or
            soup.find('a', href=re.compile(rf'page={page_num+1}'))
        )
        if not has_next and page_num >= 1:
            # Only stop if we got fewer than 6 cards (partial last page)
            if len(cards) < 6:
                break
            # Otherwise check page 2 (might not have explicit "next" link)
            if page_num >= 3:
                break  # Conservative: stop after 3 pages if no next link

        time.sleep(0.2)

    return city_outlets


# ── Progress helpers ──────────────────────────────────────────
def load_progress():
    outlets, done = {}, {}
    if OUTLETS_FILE.exists():
        with open(OUTLETS_FILE, encoding='utf-8') as f: outlets = json.load(f)
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, encoding='utf-8') as f:
            prog = json.load(f)
        done = {s: set(c) for s,c in prog.get('done_cities', {}).items()}
    return outlets, done

def save_progress(outlets, done):
    with open(OUTLETS_FILE, 'w', encoding='utf-8') as f:
        json.dump(outlets, f, ensure_ascii=False, indent=2)
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'done_cities': {s: list(c) for s,c in done.items()}}, f)


def export_csv(all_outlets):
    rows = []
    for k, o in all_outlets.items():
        state = o.get('STATE','')
        if not state and o.get('POSTAL_CODE'):
            state = state_from_pin(o['POSTAL_CODE'])
        rows.append({
            'ISSUER_ID':               ISSUER_ID,
            'ISSUER_NAME':             ISSUER_NAME,
            'FACILITY_NAME':           o.get('FACILITY_NAME',''),
            'FACILITY_ADDRESS':        o.get('FACILITY_ADDRESS',''),
            'CITY':                    o.get('CITY',''),
            'STATE':                   state,
            'POSTAL_CODE':             o.get('POSTAL_CODE',''),
            'FACILITY_REGION':         '',
            'LATITUDE':                o.get('LATITUDE',''),
            'LONGITUDE':               o.get('LONGITUDE',''),
            'FACILITY_CONTACT_NUMBER': o.get('FACILITY_CONTACT_NUMBER',''),
            'RELEVANT_URL':            o.get('RELEVANT_URL', BASE_URL),
            'BUSINESS_ACTIVITY':       o.get('BUSINESS_ACTIVITY','Banking'),
            'COUNTRY':                 'India',
        })

    df = pd.DataFrame(rows)
    df = df[df['FACILITY_NAME'].notna() & (df['FACILITY_NAME'] != '')]
    df = df.drop_duplicates(subset=['FACILITY_NAME','FACILITY_ADDRESS'])

    ts  = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = OUTPUT_DIR / f"AU_SFB_branches_{ts}.csv"
    df.to_csv(out, index=False, encoding='utf-8-sig')
    log(f"\nExported {len(df)} records → {out}")
    return df, out


def main():
    log("=" * 70)
    log(f"AU SFB Final Extractor — {ISSUER_NAME}")
    log(f"Strategy: requests (no Playwright) — data is server-rendered HTML")
    log("=" * 70)

    all_outlets, done_cities = load_progress()
    log(f"Resumed: {len(all_outlets)} outlets captured so far")

    if not STATE_CITY_FILE.exists():
        log("ERROR: state_city_map.json not found.")
        return
    with open(STATE_CITY_FILE, encoding='utf-8') as f:
        state_city_map = json.load(f)

    total_cities = sum(len(v['cities']) for v in state_city_map.values())
    log(f"Map: {len(state_city_map)} states, {total_cities} cities\n")

    processed = 0
    cumulative = sum(len(v) for v in done_cities.values())

    for state_slug, state_data in state_city_map.items():
        state_name = state_data['name']
        cities     = state_data['cities']

        state_done   = done_cities.get(state_slug, set())
        cities_to_do = {s: n for s,n in cities.items() if s not in state_done}

        if not cities_to_do:
            log(f"[SKIP] {state_name} — all {len(cities)} cities done")
            continue

        log(f"\n[STATE] {state_name} — {len(cities_to_do)}/{len(cities)} to do")

        for city_slug, city_name in cities_to_do.items():
            cumulative += 1
            pct = cumulative * 100 // total_cities

            outlets = fetch_city(state_slug, city_slug, state_name, city_name)
            new_n = 0
            for o in outlets:
                k = dedup_key(o)
                if k and k not in all_outlets:
                    all_outlets[k] = o
                    new_n += 1

            log(f"  [{pct:3d}%] {state_name}/{city_name}: {len(outlets)} found, {new_n} new | Total: {len(all_outlets)}")

            if state_slug not in done_cities:
                done_cities[state_slug] = set()
            done_cities[state_slug].add(city_slug)
            processed += 1

            if processed % 20 == 0:
                save_progress(all_outlets, done_cities)
                log(f"  [SAVED] {len(all_outlets)} outlets")

            time.sleep(0.3)

        save_progress(all_outlets, done_cities)
        log(f"[STATE DONE] {state_name} | Running total: {len(all_outlets)}")

    log(f"\n{'='*70}")
    log(f"EXTRACTION COMPLETE — {len(all_outlets)} unique outlets")
    df, out = export_csv(all_outlets)
    log(f"Done! {len(df)} rows → {out}")


if __name__ == '__main__':
    main()
