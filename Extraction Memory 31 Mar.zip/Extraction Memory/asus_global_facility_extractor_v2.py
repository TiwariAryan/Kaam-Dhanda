import httpx
from bs4 import BeautifulSoup
import csv
import re
import os

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
BASE_URL       = "https://www.asus.com/us/About_ASUS/Facilities-Branches/"
OUTPUT_DIR     = "C:\\Users\\aryan\\Downloads\\31Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

def clean_address(addr):
    if not addr: return ""
    # Remove URL-looking things and boilerplate
    addr = re.sub(r'https?://\S+', '', addr)
    addr = addr.replace("Tel:", "|").replace("Fax:", "|").replace("Website:", "|").replace("Support Site:", "|")
    addr = addr.split("|")[0] # Take only the part before contact info
    addr = addr.replace("#", "").replace("\n", ", ").replace("\r", "")
    addr = " ".join(addr.split()).strip().strip(", ")
    return addr

def parse_global_facilities():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    }
    
    print(f"Fetching {BASE_URL}...")
    resp = httpx.get(BASE_URL, headers=headers, timeout=30)
    soup = BeautifulSoup(resp.text, 'html.parser')
    
    facilities = []
    
    # Based on the markdown capture, office names are in h5 or similar.
    # Actually, they might be in <div class="title"> or <strong>
    # Let's try finding all h5 tags first.
    
    # Looking at the markdown, we have:
    # ##### ASUS COMPUTER INTERNATIONAL (North America)
    # ##### US Headquarters:
    
    # Let's search for tags containing "Office", "Headquarters", or "S.R.L", "Ltd", "GmbH"
    keywords = ["Office", "Headquarters", "S.R.L", "Ltd", "GmbH", "S.L", "B.V", "AB", "S.R.O", "Kft"]
    
    # Also countries
    countries = ["Australia", "Hong Kong", "Indonesia", "Singapore", "South Africa", "Thailand", "UAE", "Bangladesh", "India", "Malaysia", "Sri Lanka", "Turkey", "Vietnam"]
    
    # The structure seems to be:
    # <h5>Office Name</h5>
    # <p>Address Line 1<br>Address Line 2...</p>
    
    # Let's try getting all text and splitting by known headers or regions.
    # Region headers in markdown: America, Asia Pacific, China, Europe
    
    # Find all h5 tags
    h5_tags = soup.find_all('h5')
    if not h5_tags:
        # Fallback to stronger search
        h5_tags = soup.find_all(['h4', 'h5', 'h6', 'strong'])
    
    for tag in h5_tags:
        name = tag.get_text(strip=True)
        if not name: continue
        
        # Check if it looks like an office or a country
        if not (any(k in name for k in keywords) or name in countries or ":" in name):
            continue
            
        # The address is likely in the next few siblings or the parent's next sibling
        address_text = ""
        
        # Case 1: Address is in the next sibling <p> or <div>
        candidate = tag.find_next(['p', 'div', 'ul'])
        if candidate and candidate.get_text(strip=True):
            # Make sure it's not another header
            if not candidate.find(['h4', 'h5', 'h6']):
                address_text = candidate.get_text(separator=', ', strip=True)
        
        # Case 2: Address is direct siblings (text / br)
        if not address_text or len(address_text) < 10:
            parts = []
            sib = tag.next_sibling
            while sib and sib.name not in ['h4', 'h5', 'h6', 'strong']:
                if isinstance(sib, str):
                    parts.append(sib.strip())
                elif sib.name == 'br':
                    pass
                elif sib.name in ['p', 'div']:
                    parts.append(sib.get_text(strip=True))
                sib = sib.next_sibling
                if len(parts) > 5: break
            address_text = ", ".join(filter(None, parts))

        cleaned_addr = clean_address(address_text)
        if len(cleaned_addr) > 5:
            # Determine country from name or address
            country = ""
            for c in countries + ["USA", "Canada", "Mexico", "France", "Italy", "UK", "Germany", "Spain", "Netherlands", "Taiwan"]:
                if c.lower() in name.lower() or c.lower() in cleaned_addr.lower():
                    country = c
                    break
            
            # Simple city extraction (very rough, better than nothing)
            city = ""
            if "," in cleaned_addr:
                parts = [p.strip() for p in cleaned_addr.split(",")]
                if len(parts) >= 2:
                    # Look for City, State Zip or similar
                    for p in parts:
                        if re.search(r'^[A-Za-z\s]+$', p) and len(p) > 3:
                            city = p
                            break
            
            facilities.append({
                "LOCATION_NAME": name.rstrip(":"),
                "LOCATION_ADDRESS": cleaned_addr,
                "COUNTRY": country,
                "CITY": city,
                "SOURCE_URL": BASE_URL,
                "ACTIVITY_AT_SOURCE": "Corporate Office / Branch"
            })
            
    return facilities

def export_to_csv(facilities, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    fields = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        
        # Dedup by address
        seen = set()
        for fac in facilities:
            if fac['LOCATION_ADDRESS'] in seen: continue
            seen.add(fac['LOCATION_ADDRESS'])
            
            row = {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": fac.get("LOCATION_NAME", ""),
                "LOCATION_ADDRESS": fac.get("LOCATION_ADDRESS", ""),
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": fac.get("COUNTRY", ""),
                "COUNTRY_ISO3": "", 
                "POSTCODE": "",
                "STATE": "",
                "CITY": fac.get("CITY", ""),
                "SOURCE_URL": fac.get("SOURCE_URL", ""),
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": fac.get("ACTIVITY_AT_SOURCE", ""),
                "coord_source": ""
            }
            writer.writerow(row)

if __name__ == "__main__":
    data = parse_global_facilities()
    export_to_csv(data, os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv"))
    print(f"Extracted {len(data)} unique global facilities.")
