"""
CATL Master Extraction Script (v2026.03)
Platform: Multi-source Image/Web Extraction (Section 3.7 / 4.14)
Issuer: CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD. | IID000000002841129
Output: Standalone CSV with 36+ facilities, full transliteration and geocoding.
"""

import re
import sys
import time
import json
import requests
import pandas as pd
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD."
ISSUER_ID      = "IID000000002841129"
SOURCE_URL     = "https://www.catl.com/en/uploads/1/image/public/202603/20260317210914_ny0ie1ycx1.png"
OUTPUT_DIR     = Path(r"C:\Users\aryan\Downloads\28Mar Extractions")
OUTPUT_FILE    = OUTPUT_DIR / f"{ISSUER_ID}_{ISSUER_NAME}.csv"

BING_API_KEY   = "yGyflKQJyJ3lNV3yKcYP~FSPEyZhJWuaj1EsG7Ajmkg~AkM_12vG3agHCBs6OD3BxSGIJ38YadqKG687egd-7Mvzp4qrkNnMMvbal7v3xIYw"
BING_API_URL   = "http://dev.virtualearth.net/REST/v1/Locations"

# ═══════════════════════════════════════════════════════════
# DATA - Compiled from Global Facilities Map (2026) + Search
# ═══════════════════════════════════════════════════════════
RAW_FACILITIES = [
    # ── Headquarters & Labs ──────────────────────────────────────────────────
    {
        "NAME": "CATL Global Headquarters",
        "ADDR": "No. 2, Xingang Road, Zhangwan Town, Jiaocheng District, Ningde, Fujian",
        "CITY": "Ningde", "STATE": "Fujian", "ZIP": "352100", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代新能源科技股份有限公司 全球总部",
        "NATIVE_ADDR": "福建省宁德市蕉城区漳湾镇新港路2号",
        "ACTIVITY": "Global headquarters and battery manufacturing",
    },
    {
        "NAME": "21C Lab",
        "ADDR": "No. 2, Xingang Road, Jiaocheng District, Ningde, Fujian",
        "CITY": "Ningde", "STATE": "Fujian", "ZIP": "352100", "COUNTRY": "China",
        "NATIVE_NAME": "21C创新实验室",
        "NATIVE_ADDR": "福建省宁德市蕉城区新港路2号",
        "ACTIVITY": "Frontier research for next-gen energy storage (solid-state, sodium-ion)",
    },
    
    # ── Production Bases (China) ─────────────────────────────────────────────
    {
        "NAME": "Jiangsu CATL (Liyang Base)",
        "ADDR": "No. 1000, Chengbei Road, Liyang, Jiangsu",
        "CITY": "Liyang", "STATE": "Jiangsu", "ZIP": "213300", "COUNTRY": "China",
        "NATIVE_NAME": "江苏时代新能源科技有限公司",
        "NATIVE_ADDR": "江苏省溧阳市城北路1000号",
        "ACTIVITY": "Battery cell and energy storage manufacturing",
    },
    {
        "NAME": "Qinghai CATL (Xining Base)",
        "ADDR": "No. 182, Chuangye Road, Nanchuan Industry Park, Xining, Qinghai",
        "CITY": "Xining", "STATE": "Qinghai", "ZIP": "810000", "COUNTRY": "China",
        "NATIVE_NAME": "青海时代新能源科技有限公司",
        "NATIVE_ADDR": "青海省西宁市南川区创业路182号",
        "ACTIVITY": "High-altitude battery manufacturing",
    },
    {
        "NAME": "Sichuan CATL (Yibin Base)",
        "ADDR": "No. 1, Industry Avenue, Lingang Economic Development Zone, Yibin, Sichuan",
        "CITY": "Yibin", "STATE": "Sichuan", "ZIP": "644000", "COUNTRY": "China",
        "NATIVE_NAME": "四川时代新能源科技有限公司",
        "NATIVE_ADDR": "四川省宜宾市临港经开区产业大道1号",
        "ACTIVITY": "Zero-carbon battery production base",
    },
    {
        "NAME": "Ruiting CATL (Shanghai Base)",
        "ADDR": "No. 168, Xinsiping Road, Lin-gang Special Area, Shanghai",
        "CITY": "Shanghai", "STATE": "Shanghai", "ZIP": "201306", "COUNTRY": "China",
        "NATIVE_NAME": "瑞廷时代（上海）新能源科技有限公司",
        "NATIVE_ADDR": "上海自贸区临港新片区新四平公路168号",
        "ACTIVITY": "Advanced battery manufacturing (Shanghai cluster)",
    },
    {
        "NAME": "Guizhou CATL (Guiyang Base)",
        "ADDR": "Gui'an New Area, Guiyang, Guizhou",
        "CITY": "Guiyang", "STATE": "Guizhou", "ZIP": "550025", "COUNTRY": "China",
        "NATIVE_NAME": "贵州时代新能源科技有限公司",
        "NATIVE_ADDR": "贵州省贵阳市贵安新区",
        "ACTIVITY": "EV and energy storage battery manufacturing",
    },
    {
        "NAME": "Shandong CATL (Jining Base)",
        "ADDR": "Yanzhou District, Jining, Shandong",
        "CITY": "Jining", "STATE": "Shandong", "ZIP": "272100", "COUNTRY": "China",
        "NATIVE_NAME": "时代新能源（山东）有限公司",
        "NATIVE_ADDR": "山东省济宁市兖州区",
        "ACTIVITY": "Energy storage and EV battery manufacturing",
    },
    {
        "NAME": "Zhongzhou CATL (Luoyang Base)",
        "ADDR": "Luoyang High-tech Development Zone, Luoyang, Henan",
        "CITY": "Luoyang", "STATE": "Henan", "ZIP": "471000", "COUNTRY": "China",
        "NATIVE_NAME": "中原时代（洛阳）新能源科技有限公司",
        "NATIVE_ADDR": "河南省洛阳市高新技术产业开发区",
        "ACTIVITY": "Mid-China battery manufacturing hub",
    },
    {
        "NAME": "Yichun CATL (Yichun Base)",
        "ADDR": "Yichun Economic and Technological Development Zone, Yichun, Jiangxi",
        "CITY": "Yichun", "STATE": "Jiangxi", "ZIP": "336000", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代宜春锂电池生产基地",
        "NATIVE_ADDR": "江西省宜春市经济技术开发区",
        "ACTIVITY": "Lithium resource extraction and battery manufacturing",
    },
    {
        "NAME": "Zhaoqing CATL (Ruiqing Base)",
        "ADDR": "No. 1, Shidai Road, High-tech Development Zone, Zhaoqing, Guangdong",
        "CITY": "Zhaoqing", "STATE": "Guangdong", "ZIP": "526000", "COUNTRY": "China",
        "NATIVE_NAME": "广东瑞庆时代新能源科技有限公司",
        "NATIVE_ADDR": "广东省肇庆市高新技术开发区时代大道1号",
        "ACTIVITY": "Southern China battery base",
    },
    {
        "NAME": "Xiamen CATL",
        "ADDR": "Haicang District, Xiamen, Fujian",
        "CITY": "Xiamen", "STATE": "Fujian", "ZIP": "361026", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代厦门锂离子电池生产基地",
        "NATIVE_ADDR": "福建省厦门市海沧区",
        "ACTIVITY": "High-end EV battery manufacturing",
    },
    {
        "NAME": "Fuding CATL",
        "ADDR": "Fuding City, Ningde, Fujian",
        "CITY": "Fuding", "STATE": "Fujian", "ZIP": "355200", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代福鼎锂电池生产基地",
        "NATIVE_ADDR": "福建省宁德市福鼎市",
        "ACTIVITY": "Largest single battery production base",
    },

    # ── Joint Venture Plants (New from Map/Search) ───────────────────────────
    {
        "NAME": "CATL-FAW Power Battery Co., Ltd.",
        "ADDR": "Xiapu Economic Development Zone, Ningde, Fujian",
        "CITY": "Xiapu", "STATE": "Fujian", "ZIP": "355100", "COUNTRY": "China",
        "NATIVE_NAME": "时代一汽动力电池有限公司",
        "NATIVE_ADDR": "福建省宁德市霞浦县经济开发区",
        "ACTIVITY": "Joint venture with FAW Group",
    },
    {
        "NAME": "SAIC-CATL Power Battery Co., Ltd.",
        "ADDR": "No. 1000 Chengbei Road, Liyang, Jiangsu",
        "CITY": "Liyang", "STATE": "Jiangsu", "ZIP": "213300", "COUNTRY": "China",
        "NATIVE_NAME": "上汽时代动力电池系统有限公司",
        "NATIVE_ADDR": "江苏省溧阳市城北路1000号",
        "ACTIVITY": "Joint venture with SAIC Motor",
    },
    {
        "NAME": "GAC-CATL Power Battery Co., Ltd.",
        "ADDR": "Panyu District, Guangzhou, Guangdong",
        "CITY": "Guangzhou", "STATE": "Guangdong", "ZIP": "511400", "COUNTRY": "China",
        "NATIVE_NAME": "广汽时代动力电池系统有限公司",
        "NATIVE_ADDR": "广东省广州市番禺区",
        "ACTIVITY": "Joint venture with GAC Group",
    },
    {
        "NAME": "CATL-Geely Power Battery Co., Ltd.",
        "ADDR": "Hangzhou Bay New Area, Ningbo, Zhejiang",
        "CITY": "Ningbo", "STATE": "Zhejiang", "ZIP": "315336", "COUNTRY": "China",
        "NATIVE_NAME": "时代吉利动力电池有限公司",
        "NATIVE_ADDR": "浙江省宁波市杭州湾新区",
        "ACTIVITY": "Joint venture with Geely Auto",
    },
    {
        "NAME": "Dongfeng-CATL (Wuhan) Battery System Co., Ltd.",
        "ADDR": "Wuhan Economic & Technological Development Zone, Wuhan, Hubei",
        "CITY": "Wuhan", "STATE": "Hubei", "ZIP": "430056", "COUNTRY": "China",
        "NATIVE_NAME": "东风时代（武汉）电池系统有限公司",
        "NATIVE_ADDR": "湖北省武汉市经济技术开发区",
        "ACTIVITY": "Joint venture with Dongfeng Motor",
    },
    {
        "NAME": "Chongqing CATL (Western Science City)",
        "ADDR": "Western Science City, High-tech Zone, Chongqing",
        "CITY": "Chongqing", "STATE": "Chongqing", "ZIP": "401331", "COUNTRY": "China",
        "NATIVE_NAME": "重庆时代新能源科技有限公司",
        "NATIVE_ADDR": "重庆市高新区西部科学城",
        "ACTIVITY": "Southwestern China manufacturing hub",
    },
    {
        "NAME": "Xinjin CATL",
        "ADDR": "Xinjin District, Chengdu, Sichuan",
        "CITY": "Chengdu", "STATE": "Sichuan", "ZIP": "611430", "COUNTRY": "China",
        "NATIVE_NAME": "成都时代新能源科技有限公司",
        "NATIVE_ADDR": "四川省成都市新津区",
        "ACTIVITY": "Battery manufacturing facility",
    },
    {
        "NAME": "Xiamen Ampace Technology Limited",
        "ADDR": "Haicang District, Xiamen, Fujian",
        "CITY": "Xiamen", "STATE": "Fujian", "ZIP": "361026", "COUNTRY": "China",
        "NATIVE_NAME": "厦门新能安科技有限公司",
        "NATIVE_ADDR": "福建省厦门市海沧区",
        "ACTIVITY": "JV (CATL + ATL) for consumer/energy storage batteries",
    },
    {
        "NAME": "Funing Contemporary New Energy",
        "ADDR": "Funing, Ningde, Fujian",
        "CITY": "Ningde", "STATE": "Fujian", "ZIP": "352100", "COUNTRY": "China",
        "NATIVE_NAME": "福宁时代新能源科技有限公司",
        "NATIVE_ADDR": "福建省宁德市福宁",
        "ACTIVITY": "Battery manufacturing extension",
    },
    {
        "NAME": "Jiaocheng CATL",
        "ADDR": "Jiaocheng District, Ningde, Fujian",
        "CITY": "Ningde", "STATE": "Fujian", "ZIP": "352100", "COUNTRY": "China",
        "NATIVE_NAME": "蕉城时代新能源科技有限公司",
        "NATIVE_ADDR": "福建省宁德市蕉城区",
        "ACTIVITY": "Regional production unit",
    },
    {
        "NAME": "Sanjiang CATL",
        "ADDR": "Sanjiang New District, Yibin, Sichuan",
        "CITY": "Yibin", "STATE": "Sichuan", "ZIP": "644000", "COUNTRY": "China",
        "NATIVE_NAME": "宜宾三江时代新能源科技有限公司",
        "NATIVE_ADDR": "四川省宜宾市三江新区",
        "ACTIVITY": "Production expansion base",
    },

    # ── R&D Centers (New from Map/Search) ────────────────────────────────────
    {
        "NAME": "Hong Kong International R&D Center",
        "ADDR": "Hong Kong Science Park (HKSTP), Sha Tin",
        "CITY": "Hong Kong", "STATE": "", "ZIP": "", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代香港国际创新研发中心",
        "NATIVE_ADDR": "香港沙田科学园",
        "ACTIVITY": "International hub for innovation and R&D projects",
    },
    {
        "NAME": "Shanghai R&D Center",
        "ADDR": "Xuhui District, Shanghai",
        "CITY": "Shanghai", "STATE": "Shanghai", "ZIP": "200030", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代上海研发中心",
        "NATIVE_ADDR": "上海市徐汇区",
        "ACTIVITY": "Electrochemical research and intelligent manufacturing R&D",
    },
    {
        "NAME": "Xiamen R&D Center (Xiamen CATL Institute)",
        "ADDR": "Tongxiang High-tech City, Xiamen, Fujian",
        "CITY": "Xiamen", "STATE": "Fujian", "ZIP": "361100", "COUNTRY": "China",
        "NATIVE_NAME": "宁德时代厦门研发中心 (厦门时代新能研究院)",
        "NATIVE_ADDR": "福建省厦门市同翔高新城",
        "ACTIVITY": "Electrochemical energy storage research",
    },
    {
        "NAME": "Liyang R&D Center",
        "ADDR": "No. 1000 Chengbei Road, Liyang, Jiangsu",
        "CITY": "Liyang", "STATE": "Jiangsu", "ZIP": "213300", "COUNTRY": "China",
        "NATIVE_NAME": "溧阳时代研发中心",
        "NATIVE_ADDR": "江苏省溧阳市城北路1000号",
        "ACTIVITY": "Process engineering and performance R&D",
    },

    # ── Overseas Facilities (Europe/Americas/Asia) ───────────────────────────
    {
        "NAME": "Contemporary Amperex Technology Thuringia GmbH (Erfurt Plant)",
        "ADDR": "Robert-Bosch-Strasse 1, 99310 Arnstadt",
        "CITY": "Arnstadt", "STATE": "Thuringia", "ZIP": "99310", "COUNTRY": "Germany",
        "NATIVE_NAME": "德国时代新能源科技（图林根）有限公司",
        "NATIVE_ADDR": "Robert-Bosch-Straße 1, 99310 Arnstadt",
        "ACTIVITY": "Overseas battery manufacturing base",
    },
    {
        "NAME": "CATL Hungary Kft. (Debrecen Plant)",
        "ADDR": "Southern Industrial Park, Debrecen",
        "CITY": "Debrecen", "STATE": "Hajdu-Bihar", "ZIP": "4031", "COUNTRY": "Hungary",
        "NATIVE_NAME": "CATL Magyarország Akkumulátorgyár",
        "NATIVE_ADDR": "Déli Ipari Park, Debrecen",
        "ACTIVITY": "European battery production (under construction/partial operation)",
    },
    {
        "NAME": "Contemporary Amperex Technology GmbH (Munich Office)",
        "ADDR": "Bayerstrasse 83-85a, 80335 Munich",
        "CITY": "Munich", "STATE": "Bavaria", "ZIP": "80335", "COUNTRY": "Germany",
        "NATIVE_NAME": "德国时代新能源科技有限公司 (慕尼黑)",
        "NATIVE_ADDR": "Bayerstr 83-85a, 80335 München",
        "ACTIVITY": "European R&D and regional headquarters",
    },
    {
        "NAME": "Contemporary Amperex Technology France",
        "ADDR": "66 Champs Elysees, Paris",
        "CITY": "Paris", "STATE": "Ile-de-France", "ZIP": "75020", "COUNTRY": "France",
        "NATIVE_NAME": "法国时代新能源科技有限公司",
        "NATIVE_ADDR": "66 Champs Elysées, Paris",
        "ACTIVITY": "Regional office for customer relations",
    },
    {
        "NAME": "Contemporary Amperex Technology Japan K.K. (Yokohama)",
        "ADDR": "11F Landmark Tower, 2-2-1 Minatomirai, Nishi-ku, Yokohama",
        "CITY": "Yokohama", "STATE": "Kanagawa", "ZIP": "220-8111", "COUNTRY": "Japan",
        "NATIVE_NAME": "時代新能源日本合同会社",
        "NATIVE_ADDR": "〒220-8111 神奈川県横浜市西区みなとみらい2-2-1 ランドマークタワー11F",
        "ACTIVITY": "Japan regional headquarters",
    },
    {
        "NAME": "Contemporary Amperex Technology (USA), inc. (Detroit/Wilmington)",
        "ADDR": "1209 Orange Street, Wilmington, Delaware",
        "CITY": "Wilmington", "STATE": "Delaware", "ZIP": "19801", "COUNTRY": "United States",
        "NATIVE_NAME": "美国时代新能源科技有限公司",
        "NATIVE_ADDR": "1209 Orange Street, Wilmington, DE 19801",
        "ACTIVITY": "US registered corporate headquarters",
    },
    {
        "NAME": "CATL USA Auburn Hills Engineering Office",
        "ADDR": "2455 Featherstone Road, Auburn Hills, Michigan",
        "CITY": "Auburn Hills", "STATE": "Michigan", "ZIP": "48326", "COUNTRY": "United States",
        "NATIVE_NAME": "美国时代新能源（奥本山）研发中心",
        "NATIVE_ADDR": "2455 Featherstone Rd, Auburn Hills, MI 48326",
        "ACTIVITY": "Sales, R&D and engineering support office",
    },
    {
        "NAME": "NING SERVICE Experience Center Riyadh",
        "ADDR": "Riyadh, Saudi Arabia",
        "CITY": "Riyadh", "STATE": "Riyadh Province", "ZIP": "", "COUNTRY": "Saudi Arabia",
        "NATIVE_NAME": "NING SERVICE体验中心（利雅得）",
        "NATIVE_ADDR": "利雅得，沙特阿拉伯",
        "ACTIVITY": "New energy aftermarket service hub",
    },
]

# ═══════════════════════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════════════════════
def strip_cjk(text: str) -> str:
    """Remove CJK characters from bilingual text."""
    if not text: return ""
    CJK_RE = re.compile(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af\u3400-\u4dbf]')
    result = CJK_RE.sub('', text)
    result = re.sub(r'\(.*?\)', '', result)  # remove ()
    result = re.sub(r'（.*?）', '', result)  # remove native ()
    result = re.sub(r'\s+', ' ', result).strip()
    return result

COUNTRY_TO_ISO3 = {
    "China": "CHN", "Germany": "DEU", "Hungary": "HUN", 
    "France": "FRA", "Japan": "JPN", "United States": "USA", "Saudi Arabia": "SAU"
}

def bing_geocode(query: str) -> tuple:
    """Get lat/lng from Bing Maps."""
    try:
        params = {"q": query, "key": BING_API_KEY, "maxResults": 1}
        resp = requests.get(BING_API_URL, params=params, timeout=10)
        data = resp.json()
        resources = data.get("resourceSets", [{}])[0].get("resources", [])
        if resources:
            coords = resources[0]["point"]["coordinates"]
            return float(coords[0]), float(coords[1])
    except: pass
    return None, None

# ═══════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════
def main():
    if not OUTPUT_DIR.exists(): OUTPUT_DIR.mkdir(parents=True)
    
    records = []
    print(f"Standardizing {len(RAW_FACILITIES)} facility records...")
    
    for fac in RAW_FACILITIES:
        print(f"  Processing: {fac['NAME'][:50]}...", end=" ", flush=True)
        
        # Address Cleaning
        clean_addr = fac['ADDR'].replace("#", "No.")
        
        # Geocoding
        lat, lon = bing_geocode(f"{clean_addr}, {fac['CITY']}, {fac['COUNTRY']}")
        coord_source = "bing" if lat else ""
        
        records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": fac['NAME'],
            "LOCATION_ADDRESS": clean_addr,
            "LATITUDE": lat if lat else "",
            "LONGITUDE": lon if lon else "",
            "COUNTRY": fac['COUNTRY'],
            "COUNTRY_ISO3": COUNTRY_TO_ISO3.get(fac['COUNTRY'], ""),
            "POSTCODE": fac['ZIP'],
            "STATE": fac['STATE'],
            "CITY": fac['CITY'],
            "SOURCE_URL": SOURCE_URL,
            "SOURCE_TYPE": "Global Facility Map (Image)",
            "ACTIVITY_AT_SOURCE": fac['ACTIVITY'],
            "coord_source": coord_source,
            "FACILITY_NAME_LOCAL": fac['NATIVE_NAME'],
            "FACILITY_ADDRESS_LOCAL": fac['NATIVE_ADDR']
        })
        print("Done.")
        time.sleep(0.3) # Rate limit

    df = pd.DataFrame(records)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
    print(f"\n[SUCCESS] Extracted {len(df)} facilities to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
