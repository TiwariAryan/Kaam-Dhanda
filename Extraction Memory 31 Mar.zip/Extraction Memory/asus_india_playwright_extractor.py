import asyncio
import json
import os
from playwright.async_api import async_playwright

async def extract_asus_india():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        url = "https://www.asus.com/in/microsite/shop-near-me/"
        print(f"Navigating to {url}...")
        await page.goto(url, wait_until="networkidle")
        
        # Give some time for background tokens/cookies to settle
        await asyncio.sleep(2)
        
        js_code = """
        (async () => {
            const HUBS = [
                { name: "Mumbai", lat: 19.0760, lng: 72.8777 },
                { name: "Delhi", lat: 28.6139, lng: 77.2090 },
                { name: "Bangalore", lat: 12.9716, lng: 77.5946 },
                { name: "Hyderabad", lat: 17.3850, lng: 78.4867 },
                { name: "Chennai", lat: 13.0827, lng: 80.2707 },
                { name: "Kolkata", lat: 22.5726, lng: 88.3639 },
                { name: "Ahmedabad", lat: 23.0225, lng: 72.5714 },
                { name: "Pune", lat: 18.5204, lng: 73.8567 },
                { name: "Jaipur", lat: 26.9124, lng: 75.7873 },
                { name: "Lucknow", lat: 26.8467, lng: 80.9462 }
            ];
            const results = {};
            const tokenResp = await fetch("https://wheretobuy.asus.in/r/gen-token");
            const { token } = await tokenResp.json();
            for (let cat of [2, 1]) {
                for (let hub of HUBS) {
                    const payload = {
                        "lat": hub.lat, "lng": hub.lng, "city": "", "category": String(cat),
                        "recNum": "5000", "exclusive": (cat === 2), "multibrand": (cat === 1),
                        "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
                    };
                    try {
                        const resp = await fetch("https://wheretobuy.asus.in/r/getStoreDetails", {
                            method: "POST",
                            headers: { "Content-Type": "application/json", "token": token },
                            body: JSON.stringify(payload)
                        });
                        const data = await resp.json();
                        if (data.data) {
                            data.data.forEach(s => { if (s.storeID) results[s.storeID] = s; });
                        }
                    } catch (e) {}
                    await new Promise(r => setTimeout(r, 200));
                }
            }
            return results;
        })()
        """
        
        print("Executing in-browser extraction script...")
        # Fix: page.evaluate takes an expression or a function. 
        # Using a template literal for the script and ensuring it returns the result.
        results = await page.evaluate(js_code)
        
        output_path = r"C:\Users\aryan\Downloads\31Mar Extractions\india_stores_raw.json"
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2)
        
        print(f"Extracted {len(results)} unique India stores.")
        await browser.close()

if __name__ == "__main__":
    asyncio.run(extract_asus_india())
