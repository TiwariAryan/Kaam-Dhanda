import asyncio
import json
import os
import csv
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

async def extract_asus_india():
    async with async_playwright() as p:
        # Launching with specific arguments to look like a real browser
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080}
        )
        page = await context.new_page()
        
        # 1. Navigate to the API origin directly to ensure cookies/CORS are perfectly handled natively.
        print("Navigating to ASUS API origin...")
        await page.goto("https://wheretobuy.asus.in/r/gen-token", wait_until="networkidle", timeout=60000)
        
        # 2. Define the hub coordinates (Cities)
        HUBS = [
            { "name": "Mumbai", "lat": 19.0760, "lng": 72.8777 },
            { "name": "Delhi", "lat": 28.6139, "lng": 77.2090 },
            { "name": "Bangalore", "lat": 12.9716, "lng": 77.5946 },
            { "name": "Hyderabad", "lat": 17.3850, "lng": 78.4867 },
            { "name": "Chennai", "lat": 13.0827, "lng": 80.2707 },
            { "name": "Kolkata", "lat": 22.5726, "lng": 88.3639 },
            { "name": "Ahmedabad", "lat": 23.0225, "lng": 72.5714 },
            { "name": "Pune", "lat": 18.5204, "lng": 73.8567 },
            { "name": "Jaipur", "lat": 26.9124, "lng": 75.7873 },
            { "name": "Lucknow", "lat": 26.8467, "lng": 80.9462 },
            { "name": "Surat", "lat": 21.1702, "lng": 72.8311 },
            { "name": "Kanpur", "lat": 26.4499, "lng": 80.3319 },
            { "name": "Nagpur", "lat": 21.1458, "lng": 79.0882 },
            { "name": "Indore", "lat": 22.7196, "lng": 75.8577 },
            { "name": "Thane", "lat": 19.2183, "lng": 72.9781 },
            { "name": "Bhopal", "lat": 23.2599, "lng": 77.4126 },
            { "name": "Visakhapatnam", "lat": 17.6868, "lng": 83.2185 },
            { "name": "Pimpri-Chinchwad", "lat": 18.6298, "lng": 73.7997 },
            { "name": "Patna", "lat": 25.5941, "lng": 85.1376 },
            { "name": "Vadodara", "lat": 22.3072, "lng": 73.1812 },
            { "name": "Chandigarh", "lat": 30.7333, "lng": 76.7794 },
            { "name": "Gurugram", "lat": 28.4595, "lng": 77.0266 },
            { "name": "Coimbatore", "lat": 11.0168, "lng": 76.9558 },
            { "name": "Madurai", "lat": 9.9252, "lng": 78.1198 },
            { "name": "Kochi", "lat": 9.9312, "lng": 76.2673 },
            { "name": "Gwalior", "lat": 26.2183, "lng": 78.1828 },
            { "name": "Guwahati", "lat": 26.1445, "lng": 91.7362 },
            { "name": "Bhubaneswar", "lat": 20.2961, "lng": 85.8245 },
            { "name": "Dehradun", "lat": 30.3165, "lng": 78.0322 },
            { "name": "Ranchi", "lat": 23.3441, "lng": 85.3094 }
        ]
        
        all_stores = {}
        
        # 3. Dynamic Fetch Logic with error reporting
        js_fetch_script = """
        async (config) => {
            try {
                // Generate token inside browser to ensure session match
                const tResp = await fetch("https://wheretobuy.asus.in/r/gen-token");
                const tData = await tResp.json();
                const token = tData.token;
                
                const payload = {
                    "lat": config.lat, "lng": config.lng, "city": "",
                    "category": "2", "recNum": "2000",
                    "exclusive": (config.cat === 2), "multibrand": (config.cat === 1),
                    "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
                };
                
                const resp = await fetch("/r/getStoreDetails", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "token": token
                    },
                    body: JSON.stringify(payload)
                });
                return await resp.json();
            } catch (e) {
                return { status: "ERROR", message: e.message };
            }
        }
        """
        
        for hub in HUBS:
            print(f"Querying Hub: {hub['name']}...")
            for cat in [2, 1]:
                try:
                    data = await page.evaluate(js_fetch_script, {"lat": hub['lat'], "lng": hub['lng'], "cat": cat})
                    if data.get("status") == "SUCCESS" and "stores" in data:
                        extracted = data["stores"]
                        count = 0
                        for s in extracted:
                            sid = s.get('storeId') or s.get('id') or str(s.get('lat'))+str(s.get('lng'))
                            if sid:
                                s['activity_type'] = "Ex" if cat == 2 else "Mb"
                                if sid not in all_stores:
                                    all_stores[sid] = s
                                    count += 1
                        print(f"  Category {cat}: Added {count} new stores. (Batch: {len(extracted)})")
                    else:
                        msg = data.get("message", "No stores array found")
                        print(f"  Category {cat}: Failed ({data.get('status')}) - {msg}")
                except Exception as e:
                    print(f"  Category {cat}: Browser Error - {str(e)[:100]}")
                
                await asyncio.sleep(0.5)
        
        print(f"Total Unique India Stores: {len(all_stores)}")
        await browser.close()
        return all_stores

def finalize(all_stores_dict):
    final_records = []
    
    # 1. Load Global (Pre-extracted)
    global_csv = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    if os.path.exists(global_csv):
        with open(global_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                final_records.append(row)
        print(f"Merged {len(final_records)} global records.")
    
    # 2. Add India Stores
    for s in all_stores_dict.values():
        activity = "Asus Exclusive Store" if s.get('activity_type') == "Ex" else "Asus Multi-Brand Store"
        # Address cleaning
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', 'ASUS Store')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })
        
    # Deduplicate
    deduped = []
    seen_keys = set()
    for r in final_records:
        key = (str(r['LOCATION_NAME']).lower(), str(r['LOCATION_ADDRESS']).lower())
        if key not in seen_keys:
            deduped.append(r)
            seen_keys.add(key)
            
    # Write output
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    output_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(deduped)
        
    print(f"Final CSV saved: {output_path}")
    print(f"Total Unique Assets: {len(deduped)}")

if __name__ == "__main__":
    try:
        india_stores = asyncio.run(extract_asus_india())
        finalize(india_stores)
    except Exception as e:
        print(f"Execution failed: {e}")
