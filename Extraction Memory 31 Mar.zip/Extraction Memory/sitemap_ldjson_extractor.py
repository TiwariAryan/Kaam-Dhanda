"""
Sitemap + LD+JSON Extractor
Generic extractor for large locator platforms (like Rio SEO, Yext) that expose a massive xml sitemap index 
and structured `application/ld+json` blocks on individual location pages.

Features:
- Dynamically parse sitemap.xml to find region-specific sub-sitemaps
- Filter URLs based on keywords (e.g. 'customer-center', 'authorized-shipping')
- High-concurrency async HTTPX fetching (150+ connections)
- LocalBusiness schema parsing from LD+JSON
- CJK stripping and text transliteration/normalization
- Chunked CSV writing to prevent memory blowouts and save progress continuously

How to configure:
1. Update ISSUER_ID, ISSUER_NAME, and BASE_SITEMAP_URL.
2. Define URL filters if you only want specific facility types.
3. Update `determine_activity` mapping based on the URL slugs or JSON tags.
"""

import asyncio
import json
import csv
import re
import httpx
from bs4 import BeautifulSoup
import sys

sys.stdout.reconfigure(encoding='utf-8')

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME        = "COMPANY NAME"
ISSUER_ID          = "IID000000000000000"
BASE_SITEMAP_URL   = "https://locations.example.com/sitemap.xml"
OUTPUT_FILE        = "output.csv"
SITEMAP_FILTER     = "sitemap_us_"   # Filter for specific sitemap names
URL_FILTERS        = ["customer-center", "authorized-shipping", "alliance"] # Only fetch URLs with these slugs

CJK_RE = re.compile(r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af\u3400-\u4dbf]')

def strip_cjk(text: str) -> str:
    if not text: return ""
    result = CJK_RE.sub('', text)
    result = re.sub(r'\(\s*\)', '', result)
    result = re.sub(r'\s+', ' ', result).strip()
    return result

def determine_activity(url, raw_name):
    url_lower = url.lower()
    if 'customer-center' in url_lower: return "Customer Center"
    if 'authorized-shipping' in url_lower: return "Authorized Shipping Outlet"
    if 'alliance' in url_lower: return "Alliance Location"
    if 'drop-box' in url_lower: return "Drop Box"
    return "Facility"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW
# ═══════════════════════════════════════════════════════════

import xml.etree.ElementTree as ET

async def get_sitemap_urls(client, url):
    try:
        r = await client.get(url, timeout=10.0)
        root = ET.fromstring(r.text)
        return [c[0].text for c in root if '.html' in c[0].text]
    except Exception:
        return []

async def fetch_page(client, url, semaphore):
    async with semaphore:
        try:
            r = await client.get(url, timeout=15.0)
            if r.status_code != 200: return None
            
            soup = BeautifulSoup(r.text, 'html.parser')
            ld_json = soup.find('script', type='application/ld+json')
            if not ld_json or not ld_json.string: return None
            
            data = json.loads(ld_json.string)
            if isinstance(data, list):
                if not data: return None
                data = data[0]
            
            geo = data.get('geo', {})
            addr_obj = data.get('address', {})
            
            addr_street = strip_cjk(addr_obj.get('streetAddress', '')).replace('#', '').strip()
            if not addr_street: return None
            
            name = strip_cjk(data.get('name', ''))
            
            country_code = addr_obj.get('addressCountry', 'US')
            
            return {
                'ISSUER_ID': ISSUER_ID,
                'ISSUER_NAME': ISSUER_NAME,
                'FACILITY_NAME': name,
                'FACILITY_ADDRESS': addr_street,
                'LATITUDE': geo.get('latitude', ''),
                'LONGITUDE': geo.get('longitude', ''),
                'COUNTRY': country_code,
                'COUNTRY_ISO3': "USA" if country_code == "US" else "Unknown",
                'POSTCODE': str(addr_obj.get('postalCode', '')),
                'STATE': strip_cjk(addr_obj.get('addressRegion', '')),
                'CITY': strip_cjk(addr_obj.get('addressLocality', '')),
                'RELEVANT_URL': url,
                'ACTIVITY_AT_SOURCE': determine_activity(url, name),
                'coord_source': 'website' if geo.get('latitude') else ''
            }
        except Exception:
            return None

async def main():
    async with httpx.AsyncClient(timeout=15.0) as client:
        # Get sitemap index
        r = await client.get(BASE_SITEMAP_URL)
        root = ET.fromstring(r.text)
        sitemaps = [c[0].text for c in root if SITEMAP_FILTER in c[0].text]
        
        # Get all sub-sitemaps
        tasks = [get_sitemap_urls(client, s) for s in sitemaps]
        results = await asyncio.gather(*tasks)
        all_urls = []
        for res in results:
            all_urls.extend(res)
            
        # Filter URLs
        target_urls = [u for u in all_urls if any(f in u for f in URL_FILTERS)]
        
        # Extract pages
        semaphore = asyncio.Semaphore(150)
        limits = httpx.Limits(max_keepalive_connections=150, max_connections=200)
        client = httpx.AsyncClient(limits=limits, timeout=15.0)
        
        fieldnames = ['ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS', 'LATITUDE', 'LONGITUDE', 'COUNTRY', 'COUNTRY_ISO3', 'POSTCODE', 'STATE', 'CITY', 'RELEVANT_URL', 'ACTIVITY_AT_SOURCE', 'coord_source']
        with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8') as f:
            csv.DictWriter(f, fieldnames=fieldnames).writeheader()
            
        total_valid = 0
        tasks = [fetch_page(client, url, semaphore) for url in target_urls]
        chunk_size = 500
        for i in range(0, len(tasks), chunk_size):
            chunk = tasks[i:i+chunk_size]
            results = await asyncio.gather(*chunk)
            valid = [r for r in results if r]
            if valid:
                with open(OUTPUT_FILE, 'a', newline='', encoding='utf-8') as f:
                    csv.DictWriter(f, fieldnames=fieldnames).writerows(valid)
                total_valid += len(valid)
            print(f"Processed chunk, total valid: {total_valid}")

if __name__ == '__main__':
    asyncio.run(main())
