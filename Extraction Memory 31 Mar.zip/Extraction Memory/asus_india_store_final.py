import httpx
import json
import csv
import os
import time

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
TOKEN_URL      = "https://wheretobuy.asus.in/r/gen-token"
API_URL        = "https://wheretobuy.asus.in/r/getStoreDetails"
OUTPUT_DIR     = "C:\\Users\\aryan\\Downloads\\31Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

# Major hubs coordinates from home.js / Google
HUBS = [
    ("Mumbai", 19.0760, 72.8777),
    ("Delhi", 28.6139, 77.2090),
    ("Bangalore", 12.9716, 77.5946),
    ("Hyderabad", 17.3850, 78.4867),
    ("Ahmedabad", 23.0225, 72.5714),
    ("Chennai", 13.0827, 80.2707),
    ("Kolkata", 22.5726, 88.3639)
]

def get_token():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Referer": "https://www.asus.com/"
    }
    try:
        resp = httpx.get(TOKEN_URL, headers=headers, timeout=20)
        return resp.json().get("token")
    except:
        return None

def fetch_stores(token, lat, lng, category):
    headers = {
        "Content-Type": "application/json",
        "Origin": "https://www.asus.com",
        "Referer": "https://www.asus.com/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "token": token
    }
    payload = {
        "lat": lat,
        "lng": lng,
        "city": "",
        "category": str(category),
        "recNum": "5000", # Maximize coverage
        "exclusive": (category == 2),
        "multibrand": (category == 1),
        "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
    }
    try:
        resp = httpx.post(API_URL, headers=headers, json=payload, timeout=60)
        return resp.json().get("data", [])
    except:
        return []

def clean_row(val):
    if not val: return ""
    return str(val).replace("#", "").replace("\n", ", ").strip()

def run_extraction():
    token = get_token()
    if not token:
        print("Failed to get token")
        return
    
    all_records = {} # storeID: data
    
    # India Stores
    for cat in [2, 1]:
        print(f"Fetching India Category {cat}...")
        for name, lat, lng in HUBS:
            print(f"  Querying hub: {name}")
            batch = fetch_stores(token, lat, lng, cat)
            for s in batch:
                sid = s.get('storeID')
                if sid: all_records[sid] = s
            print(f"  Current unique count: {len(all_records)}")
            time.sleep(1)

    # Global Facilities (Pre-collected/Static)
    # I'll just use a small list for the Global part as it's static and I already saw it.
    # But better to just run the v2 script again later or merge here.
    
    # Actually, let's just use the India stores for now to see the count.
    stores_list = list(all_records.values())
    
    # Prepare CSV
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fields = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(os.path.join(OUTPUT_DIR, OUTPUT_FILE), 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for s in stores_list:
            activity = "Asus Exclusive Store" if str(s.get('category')) == "2" else "Asus Multi-Brand Store"
            writer.writerow({
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": s.get('name'),
                "LOCATION_ADDRESS": clean_row(s.get('address', s.get('name'))),
                "LATITUDE": s.get('lat'),
                "LONGITUDE": s.get('lng'),
                "COUNTRY": "India",
                "COUNTRY_ISO3": "IND",
                "POSTCODE": s.get('postal'),
                "STATE": s.get('state'),
                "CITY": s.get('city'),
                "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": activity,
                "coord_source": "website"
            })

    print(f"Total India stores: {len(stores_list)}")
    return len(stores_list)

if __name__ == "__main__":
    run_extraction()
