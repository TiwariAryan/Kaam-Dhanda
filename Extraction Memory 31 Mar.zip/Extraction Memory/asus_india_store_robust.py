import httpx
import json
import csv
import os
import time

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
BASE_DOMAIN    = "https://wheretobuy.asus.in"
OUTPUT_DIR     = "C:\\Users\\aryan\\Downloads\\31Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

# Hubs - enough to cover India if recNum is large
HUBS = [
    ("Mumbai", 19.0760, 72.8777),
    ("Delhi", 28.6139, 77.2090),
    ("Bangalore", 12.9716, 77.5946),
    ("Hyderabad", 17.3850, 78.4867),
    ("Chennai", 13.0827, 80.2707),
    ("Kolkata", 22.5726, 88.3639),
    ("Ahmedabad", 23.0225, 72.5714),
    ("Pune", 18.5204, 73.8567),
    ("Jaipur", 26.9124, 75.7873),
    ("Lucknow", 26.8467, 80.9462)
]

def run_robust_extraction():
    # Use a session to handle cookies/headers consistently
    client = httpx.Client(
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Origin": "https://www.asus.com",
            "Referer": "https://www.asus.com/"
        },
        timeout=60,
        follow_redirects=True
    )
    
    # 1. Get Token
    print("Fetching token...")
    try:
        resp = client.get(f"{BASE_DOMAIN}/r/gen-token")
        token = resp.json().get("token")
        print(f"Token acquired: {token[:10]}...")
    except Exception as e:
        print(f"Token failure: {e}")
        return

    all_stores = {}

    # 2. Iterate Categories (2=Exclusive, 1=Multi-brand)
    for cat in [2, 1]:
        print(f"Extracting Category {cat}...")
        for name, lat, lng in HUBS:
            print(f"  Searching near {name}...")
            payload = {
                "lat": lat,
                "lng": lng,
                "city": "",
                "category": str(cat),
                "recNum": "5000",
                "exclusive": (cat == 2),
                "multibrand": (cat == 1),
                "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
            }
            try:
                resp = client.post(f"{BASE_DOMAIN}/r/getStoreDetails", json=payload, headers={"token": token})
                if resp.status_code == 200:
                    data = resp.json().get("data", [])
                    print(f"    Found {len(data)} items")
                    for s in data:
                        sid = s.get('storeID')
                        if sid: all_stores[sid] = s
                else:
                    print(f"    Error {resp.status_code}: {resp.text[:100]}")
            except Exception as e:
                print(f"    Request error: {e}")
            time.sleep(1)

    print(f"\nTotal Unique India Stores: {len(all_stores)}")
    
    # 3. Global Facilities (Manual merge from v2 results)
    # The v2 script got 22 records. I'll just run it separately and merge or add its logic here.
    
    # Export
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    fields = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(os.path.join(OUTPUT_DIR, OUTPUT_FILE), 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        
        # India stores
        for s in all_stores.values():
            activity = "Asus Exclusive Store" if str(s.get('category')) == "2" else "Asus Multi-Brand Store"
            writer.writerow({
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": s.get('name'),
                "LOCATION_ADDRESS": str(s.get('address', s.get('name'))).replace("#", "").replace("\n", ", ").strip(),
                "LATITUDE": s.get('lat'),
                "LONGITUDE": s.get('lng'),
                "COUNTRY": "India",
                "COUNTRY_ISO3": "IND",
                "POSTCODE": s.get('postal'),
                "STATE": s.get('state'),
                "CITY": s.get('city'),
                "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": activity,
                "coord_source": "website"
            })
            
    return len(all_stores)

if __name__ == "__main__":
    count = run_robust_extraction()
    if count:
        print(f"Success! {count} stores saved.")
