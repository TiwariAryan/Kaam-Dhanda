"""
Drupal /callajax Branch Locator Extractor
==========================================
Platform Pattern: Drupal 10 CMS with custom /callajax POST endpoint.
The locator uses a 3-level hierarchy: State → District → Location.
Each "location" maps to 1-N branches; pagination via 'get_more_branch_list'.

Used for: MUTHOOT FINANCE LIMITED
API Base: https://www.muthootfinance.com/callajax

How to reuse for a different issuer:
  - Change ISSUER_NAME, ISSUER_ID, BASE_URL
  - Verify the same /callajax actions exist (get_all_states, get_distby_states, 
    get_locationby_dist, get_branch_list, get_more_branch_list)
  
Usage:
  python drupal_callajax_branch_extractor.py
  
Output:
  muthoot_branches.csv in OUTPUT_DIR
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME   = "MUTHOOT FINANCE LIMITED"
ISSUER_ID     = "IID000000002618636"
BASE_URL      = "https://www.muthootfinance.com"
OUTPUT_DIR    = r"C:\Users\aryan\Downloads\ACWI Geo Analysts Gap Collection"
OUTPUT_FILE   = "muthoot_gap_fill.csv"
PROGRESS_FILE = r"C:\Users\aryan\Downloads\muthoot_progress.json"

# API endpoint
CALLAJAX_URL  = f"{BASE_URL}/callajax"

# Pagination batch size (API returns this many per call)
PAGE_SIZE = 10

# Max pages per location before giving up (safety cap)
MAX_PAGES_PER_LOC = 20

# Delay between requests (seconds)
REQUEST_DELAY = 0.2

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Parameterized per platform
# ═══════════════════════════════════════════════════════════

import httpx
import sys
import re
import json
import csv
import time
import os
from pathlib import Path
from bs4 import BeautifulSoup

sys.stdout.reconfigure(encoding='utf-8')

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Referer': f'{BASE_URL}/branch-locator',
    'X-Requested-With': 'XMLHttpRequest',
    'Accept': 'text/html, */*; q=0.01',
}

# ─── Utility: Indian pincode → state mapping ──────────────────────────────────
PINCODE_STATE = {
    '11': 'Delhi', '12': 'Haryana', '13': 'Haryana', '14': 'Punjab',
    '15': 'Himachal Pradesh', '16': 'Punjab', '17': 'Himachal Pradesh',
    '18': 'Jammu and Kashmir', '19': 'Jammu and Kashmir',
    '20': 'Uttar Pradesh', '21': 'Uttar Pradesh', '22': 'Uttar Pradesh',
    '23': 'Uttar Pradesh', '24': 'Uttar Pradesh', '25': 'Uttar Pradesh',
    '26': 'Uttarakhand', '27': 'Uttar Pradesh', '28': 'Uttar Pradesh',
    '29': 'Uttarakhand',
    '30': 'Rajasthan', '31': 'Rajasthan', '32': 'Rajasthan', '33': 'Rajasthan',
    '34': 'Rajasthan',
    '36': 'Gujarat', '37': 'Gujarat', '38': 'Gujarat', '39': 'Gujarat',
    '40': 'Maharashtra', '41': 'Maharashtra', '42': 'Maharashtra', '43': 'Maharashtra',
    '44': 'Maharashtra', '45': 'Madhya Pradesh', '46': 'Madhya Pradesh',
    '47': 'Madhya Pradesh', '48': 'Madhya Pradesh', '49': 'Chhattisgarh',
    '50': 'Telangana', '51': 'Andhra Pradesh', '52': 'Andhra Pradesh',
    '53': 'Andhra Pradesh', '54': 'Andhra Pradesh',
    '55': 'Karnataka', '56': 'Karnataka', '57': 'Karnataka', '58': 'Karnataka',
    '59': 'Karnataka',
    '60': 'Tamil Nadu', '61': 'Tamil Nadu', '62': 'Tamil Nadu', '63': 'Tamil Nadu',
    '64': 'Tamil Nadu',
    '67': 'Kerala', '68': 'Kerala', '69': 'Kerala',
    '70': 'West Bengal', '71': 'West Bengal', '72': 'West Bengal', '73': 'West Bengal',
    '74': 'West Bengal', '75': 'Odisha', '76': 'Odisha', '77': 'Odisha',
    '78': 'Assam', '79': 'Assam',
    '80': 'Bihar', '81': 'Bihar', '82': 'Jharkhand', '83': 'Jharkhand',
    '84': 'Bihar', '85': 'Bihar',
    '403': 'Goa',
}

def get_state_from_pincode(pincode):
    if not pincode or len(pincode) < 2:
        return ''
    pincode = pincode.strip()
    if pincode[:3] in PINCODE_STATE:
        return PINCODE_STATE[pincode[:3]]
    return PINCODE_STATE.get(pincode[:2], '')

# ─── Utility: Extract pincode from address ────────────────────────────────────
def extract_pincode(text):
    """Extract 6-digit Indian pincode from address string."""
    m = re.search(r'\b([1-9]\d{5})\b', text)
    return m.group(1) if m else ''

def extract_coords(google_maps_href):
    """Extract lat,lng from Google Maps direction URL like /CurrentLocation/lat,lng"""
    m = re.search(r'CurrentLocation/([\d.\-]+),([\d.\-]+)', google_maps_href)
    if m:
        return m.group(1), m.group(2)
    return '', ''

# ─── API calls ────────────────────────────────────────────────────────────────
def callajax(client, action, extra_data=None):
    data = {'action': action}
    if extra_data:
        data.update(extra_data)
    for attempt in range(3):
        try:
            r = client.post(CALLAJAX_URL, data=data, headers=HEADERS, timeout=30)
            if r.status_code == 200:
                return r.text
            print(f"  [WARN] {action} HTTP {r.status_code}: {r.text[:100]}")
            time.sleep(2 ** attempt)
        except Exception as e:
            print(f"  [ERR] {action} attempt {attempt+1}: {e}")
            time.sleep(2 ** attempt)
    return ''

def parse_options(html):
    """Parse <option> elements from HTML dropdown response."""
    soup = BeautifulSoup(html, 'html.parser')
    return [o.get('value') for o in soup.find_all('option') if o.get('value')]

def parse_branch_rows(html):
    """Parse branch rows from table HTML response.
    Returns list of dicts: {name, branch_code, status, address, contact, lat, lng}
    """
    soup = BeautifulSoup(html, 'html.parser')
    rows = soup.find_all('tr')
    branches = []
    for row in rows:
        tds = row.find_all('td')
        if len(tds) < 4:
            continue
        # TD 0: Branch name + code + status
        td0 = tds[0]
        strong = td0.find('strong')
        name = strong.get_text(strip=True) if strong else ''
        td0_text = td0.get_text(' ', strip=True)
        code_m = re.search(r'Branch Code:\s*(\d+)', td0_text)
        status_m = re.search(r'Branch Status:\s*(\w+)', td0_text)
        branch_code = code_m.group(1) if code_m else ''
        status = status_m.group(1) if status_m else ''
        
        # TD 1: Address
        address = tds[1].get_text(' ', strip=True)
        
        # TD 3: Get Direction link (contains lat/lng)
        direction_link = tds[3].find('a', class_='get_btn')
        lat, lng = '', ''
        if direction_link and direction_link.get('href'):
            lat, lng = extract_coords(direction_link.get('href', ''))
        
        branches.append({
            'name': name,
            'branch_code': branch_code,
            'status': status,
            'address': address,
            'lat': lat,
            'lng': lng,
        })
    return branches

# ─── Progress saving ──────────────────────────────────────────────────────────
def load_progress():
    if Path(PROGRESS_FILE).exists():
        with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"[RESUME] Loaded {len(data['done_keys'])} done keys, {len(data['branches'])} branches")
        return set(data['done_keys']), data['branches']
    return set(), []

def save_progress(done_keys, branches):
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump({'done_keys': list(done_keys), 'branches': branches}, f, ensure_ascii=False)

# ─── Main extraction ──────────────────────────────────────────────────────────
def extract_all_branches():
    done_keys, branches = load_progress()
    seen_codes = {b['branch_code'] for b in branches if b.get('branch_code')}
    
    with httpx.Client(follow_redirects=True) as client:
        # Step 1: Get all states
        print("[1/4] Fetching states...")
        states_html = callajax(client, 'get_all_states')
        states = parse_options(states_html)
        print(f"  States: {len(states)} → {states}")
        
        total_iterations = 0
        
        for state in states:
            # Step 2: Get districts for each state
            print(f"\n[STATE] {state}")
            dists_html = callajax(client, 'get_distby_states', {'state': state})
            time.sleep(REQUEST_DELAY)
            districts = parse_options(dists_html)
            print(f"  Districts: {len(districts)}")
            
            for dist in districts:
                # Step 3: Get locations for each district
                locs_html = callajax(client, 'get_locationby_dist', {'dist': dist})
                time.sleep(REQUEST_DELAY)
                locations = parse_options(locs_html)
                
                for loc in locations:
                    key = f"{state}|{dist}|{loc}"
                    if key in done_keys:
                        continue
                    
                    # Step 4: Get branches for this location (paginated)
                    offset = 0
                    loc_branches = 0
                    while True:
                        if offset == 0:
                            html = callajax(client, 'get_branch_list', {
                                'state': state, 'dist': dist, 'location': loc
                            })
                        else:
                            html = callajax(client, 'get_more_branch_list', {
                                'state': state, 'dist': dist, 'location': loc, 'offset': str(offset)
                            })
                        time.sleep(REQUEST_DELAY)
                        
                        new_rows = parse_branch_rows(html)
                        added = 0
                        for br in new_rows:
                            if br['branch_code'] and br['branch_code'] not in seen_codes:
                                br['state'] = state
                                br['district'] = dist
                                br['location'] = loc
                                branches.append(br)
                                seen_codes.add(br['branch_code'])
                                added += 1
                            elif not br['branch_code']:
                                # No branch code - use name+address as key
                                dedup_key = f"{br['name']}|{br['address']}"
                                if dedup_key not in seen_codes:
                                    br['state'] = state
                                    br['district'] = dist
                                    br['location'] = loc
                                    branches.append(br)
                                    seen_codes.add(dedup_key)
                                    added += 1
                        
                        loc_branches += added
                        
                        # Stop if fewer rows than PAGE_SIZE (last page)
                        if len(new_rows) < PAGE_SIZE or offset >= MAX_PAGES_PER_LOC * PAGE_SIZE:
                            break
                        offset += PAGE_SIZE
                    
                    done_keys.add(key)
                    total_iterations += 1
                    
                    if loc_branches > 0:
                        print(f"    [{state}/{dist}/{loc}] +{loc_branches} branches (total={len(branches)})")
                    
                    # Save progress every 20 locations
                    if total_iterations % 20 == 0:
                        save_progress(done_keys, branches)
                        print(f"  [SAVE] Progress saved @ {len(branches)} branches")
    
    # Final save
    save_progress(done_keys, branches)
    return branches

# ─── Post-processing & CSV export ────────────────────────────────────────────
def build_csv(branches):
    out_path = Path(OUTPUT_DIR) / OUTPUT_FILE
    
    fieldnames = [
        'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
        'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL', 'BUSINESS_ACTIVITY',
    ]
    
    rows_written = 0
    with open(out_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for b in branches:
            address = b.get('address', '').strip()
            pincode = extract_pincode(address)
            
            # State: from API state field (more reliable than pincode)
            state = b.get('state', '').title()
            # Normalize known state name variants
            state_norm = {
                'Tamilnadu': 'Tamil Nadu',
                'A - N Islands': 'Andaman and Nicobar Islands',
                'Bihar': 'Bihar',
                'Daman': 'Daman and Diu',
            }.get(state, state)
            
            # City: use location/district (the district is essentially the "city" here)
            city = b.get('district', '') or b.get('location', '')
            city = city.title()
            
            # Postal code from address
            if not pincode:
                pincode = ''
            
            # State backup from pincode if state is missing
            if not state_norm and pincode:
                state_norm = get_state_from_pincode(pincode)
            
            writer.writerow({
                'ISSUER_ID': ISSUER_ID,
                'ISSUER_NAME': ISSUER_NAME,
                'FACILITY_NAME': b.get('name', ''),
                'FACILITY_ADDRESS': address,
                'CITY': city,
                'STATE': state_norm,
                'POSTAL_CODE': pincode,
                'FACILITY_REGION': 'India',
                'LATITUDE': b.get('lat', ''),
                'LONGITUDE': b.get('lng', ''),
                'FACILITY_CONTACT_NUMBER': '18002021212',  # National toll-free from page
                'RELEVANT_URL': f"{BASE_URL}/branch-locator",
                'BUSINESS_ACTIVITY': 'Gold Loan Branch',
            })
            rows_written += 1
    
    print(f"\n[DONE] Written {rows_written} rows to {out_path}")
    return out_path

# ─── Entry point ──────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import time as _time
    t0 = _time.time()
    
    print(f"{'='*60}")
    print(f"Muthoot Finance Branch Extractor")
    print(f"Target: {BASE_URL}")
    print(f"Output: {OUTPUT_DIR}/{OUTPUT_FILE}")
    print(f"{'='*60}\n")
    
    # Run extraction
    branches = extract_all_branches()
    print(f"\n[EXTRACT] Total unique branches extracted: {len(branches)}")
    
    # Export to CSV
    csv_path = build_csv(branches)
    
    elapsed = _time.time() - t0
    print(f"[TIME] Total time: {elapsed/60:.1f} minutes")
    print(f"[OUTPUT] {csv_path}")
