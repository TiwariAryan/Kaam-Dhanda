"""
Sitecore BranchInfo API Pattern Extractor

Pattern Detection:
- API endpoint typically formatted as `/api/sitecore/{Controller}/{Action}`
- e.g., `/api/sitecore/BranchInfo/getlocationinfo`
- Request method is POST.
- The endpoint often returns all branch data at once when provided with an empty JSON payload `{}`.
- Data might include ATMs and Kiosks which must be filtered if only branches are needed.

Configuration Options:
- Change the `BASE_URL` and `API_ENDPOINT` to match the target issuer.
- If data is returned in a native language (e.g., Arabic), ensure to transliterate fields post-extraction.
"""

import httpx
import json
import logging
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME     = "AL RAJHI BANKING AND INVESTMENT CORPORATION SJSC"
ISSUER_ID       = "IID000000002154955"
BASE_URL        = "https://www.alrajhibank.com.sa"
API_ENDPOINT    = "/api/sitecore/BranchInfo/getlocationinfo"
OUTPUT_DIR      = "company_output"

# Site-specific filters
# Which types to INCLUDE. In some cases, you need to exclude ATMs
EXCLUDE_TYPES   = ["ATM", "Kiosk", "Self Service Kiosk", "Enjaz ATM"]

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def extract_sitecore_branches():
    """Fetches branch data via Sitecore API POST payload."""
    url = f"{BASE_URL}{API_ENDPOINT}"
    
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        # Language cookies or headers might be required for english output
        "Cookie": "sc_lang=en",
        "Referer": f"{BASE_URL}/en/find-branch"
    }
    
    payload = {} # Empty payload often returns all records
    
    logging.info(f"Fetching data from Sitecore API: {url}")
    
    with httpx.Client() as client:
        try:
            response = client.post(url, json=payload, headers=headers, timeout=15.0)
            response.raise_for_status()
        except httpx.HTTPError as e:
            logging.error(f"HTTP error occurred: {e}")
            return []
            
    data = response.json()
    
    # Sometimes data is nested in a 'data' key or 'locations' key
    locations = data.get("data", []) if isinstance(data, dict) else data
    
    if not isinstance(locations, list):
        logging.error("Expected API to return a list of locations.")
        return []

    logging.info(f"Retrieved {len(locations)} total records from API.")

    # Apply filters
    valid_branches = [
        loc for loc in locations 
        if loc.get("Type", "") not in EXCLUDE_TYPES
    ]

    logging.info(f"Filtered down to {len(valid_branches)} valid branches/facilities.")
    return valid_branches


if __name__ == "__main__":
    records = extract_sitecore_branches()
    if records:
        print(f"Sample First Record: {json.dumps(records[0], indent=2)}")
        
        # Save exact payload to output logic
        Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
        out_file = Path(OUTPUT_DIR) / f"{ISSUER_ID}_{ISSUER_NAME}.json"
        
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        
        logging.info("Successfully exported JSON. Post-processing to CSV can follow.")
