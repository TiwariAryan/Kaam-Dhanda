"""
Pattern: 3.7 Direct Contact Page Scraping (Static HTML Table)

This script extracts facility locations from a static HTML table structure, typical
for corporate contact pages. It uses `urllib` to fetch the raw HTML and `BeautifulSoup`
to parse the tabular data.

Setup/Config for new issuers:
- Change the URL and ISSUER constants.
- Adjust the column indexing in the `extract_data` function depending on the site's table structure.
- Some tables might have multiple headers/footers.

Usage:
  python direct_contact_table_extractor.py
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME     = "HINDUSTAN PETROLEUM CORPORATION LIMITED"
ISSUER_ID       = "IID000000002124711"
BASE_URL        = "https://www.hindustanpetroleum.com/pages/POL-Locations"
OUTPUT_DIR      = r"C:\Users\aryan\Downloads\28Mar Extractions"
EXPECTED_COUNT  = 69

# Platform-specific config
TABLE_INDEX     = 0           # Which table on the page to parse
HAS_HEADER      = True        # Skip the first row
COLUMN_MAPPING  = {
    "name": 1,
    "address": 2,
    "latitude": 3,
    "longitude": 4
}
ACTIVITY_VALUE  = "POL Location / Depot"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW
# ═══════════════════════════════════════════════════════════
import urllib.request
import ssl
import re
import os
import csv
import json
import unicodedata
from pathlib import Path
from bs4 import BeautifulSoup

def clean_ascii(text):
    """Transliterate text to ASCII/English to avoid strange chars."""
    if not text:
        return ""
    text = str(text)
    # Normalize to ascii safely
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8')
    # Clean generic weird spacing and hashes
    text = text.replace('#', '')
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def split_address_components(address_str):
    """Extract standard fields from a comma/pipe separated address."""
    parts = [p.strip() for p in address_str.split('|') if p.strip()]
    if not parts:
        parts = [p.strip() for p in address_str.split(',') if p.strip()]
        
    city, state, postcode = "", "", ""
    # Indian postcodes are 6 digits usually at the very end
    # States might be mentioned earlier
    for part in reversed(parts):
        # find postcode
        pc_match = re.search(r'\b(\d{6})\b', part)
        if pc_match and not postcode:
            postcode = pc_match.group(1)
            # Remove postcode from this part for city parsing
            part = part.replace(pc_match.group(1), '').strip(' -/,')
        
        if part and not city:
            # Assume the last valid string part is city
            city = clean_ascii(part)
            
    # For India, often we won't have strict state info just from address
    # We leave State blank or infer if needed
    
    return city, state, postcode

def fetch_html(url):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
    response = urllib.request.urlopen(req, context=ctx)
    return response.read().decode('utf-8', 'ignore')

def main():
    print(f"Starting extraction for {ISSUER_NAME} ({ISSUER_ID})")
    
    html_content = fetch_html(BASE_URL)
    soup = BeautifulSoup(html_content, 'html.parser')
    
    tables = soup.find_all('table')
    if not tables or len(tables) <= TABLE_INDEX:
        print("ERROR: Could not find the target table.")
        return
        
    target_table = tables[TABLE_INDEX]
    rows = target_table.find_all('tr')
    
    if HAS_HEADER:
        rows = rows[1:]
        
    extracted_data = []
    
    for row in rows:
        cells = row.find_all(['td', 'th'])
        if len(cells) < max(COLUMN_MAPPING.values()) + 1:
            continue
            
        # Extract native strings
        cols_text = [td.get_text(separator=' ', strip=True) for td in cells]
        # For address, use | to preserve lines for splitting
        addr_native = cells[COLUMN_MAPPING['address']].get_text(separator='|', strip=True)
        name_native = cols_text[COLUMN_MAPPING['name']]
        lat_native = cols_text[COLUMN_MAPPING['latitude']]
        lng_native = cols_text[COLUMN_MAPPING['longitude']]
        
        # English / ASCII translation
        name_eng = clean_ascii(name_native)
        addr_eng = clean_ascii(addr_native.replace('|', ', '))
        
        # Heuristics for components
        city, state, postcode = split_address_components(addr_native)
        
        lat = lat_native.strip()
        lng = lng_native.strip()
        coord_source = "Website" if lat and lng else ""
        
        record = {
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": name_eng,
            "LOCATION_ADDRESS": addr_eng,
            "LATITUDE": lat,
            "LONGITUDE": lng,
            "COUNTRY": "India",        # Hardcoded based on issuer
            "COUNTRY_ISO3": "IND",
            "POSTCODE": postcode,
            "STATE": state,
            "CITY": city,
            "SOURCE_URL": BASE_URL,
            "SOURCE_TYPE": "Direct Scrape",
            "ACTIVITY_AT_SOURCE": ACTIVITY_VALUE,
            "coord_source": coord_source,
            "FACILITY_NAME_LOCAL": name_native,
            "FACILITY_ADDRESS_LOCAL": addr_native.replace('|', ', ')
        }
        extracted_data.append(record)
        
    print(f"Extracted {len(extracted_data)} records limit target was {EXPECTED_COUNT}.")
    
    # Save to CSV
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_file = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}.csv")
    
    headers = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", 
        "LATITUDE", "LONGITUDE", "COUNTRY", "COUNTRY_ISO3", "POSTCODE", 
        "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE", "ACTIVITY_AT_SOURCE", 
        "coord_source", "FACILITY_NAME_LOCAL", "FACILITY_ADDRESS_LOCAL"
    ]
    
    with open(out_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(extracted_data)
        
    print(f"Data saved to {out_file}")
    
    # Copy to memory folder for reusability if needed
    try:
        import shutil
        memory_dir = r"C:\Users\aryan\Downloads\Extraction Memory 28 Mar\Extraction Memory"
        shutil.copyfile(__file__, os.path.join(memory_dir, "direct_contact_table_extractor.py"))
        print(f"Saved reusable script to {memory_dir}")
    except Exception as e:
        print(f"Could not copy script to memory: {e}")

if __name__ == "__main__":
    main()
