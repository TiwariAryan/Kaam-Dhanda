import asyncio
import json
import os
import csv
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

async def extract_asus_india():
    async with async_playwright() as p:
        # Launching with specific arguments to look like a real browser
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            viewport={'width': 1920, 'height': 1080}
        )
        page = await context.new_page()
        
        # Navigate to set cookies and context
        print("Navigating to ASUS India Store Locator...")
        await page.goto("https://www.asus.com/in/microsite/shop-near-me/", wait_until="networkidle")
        await asyncio.sleep(3) # Wait for session stability
        
        js_code = """
        (async function fetchAllStores() {
            const HUBS = [
                { name: "Mumbai", lat: 19.0760, lng: 72.8777 },
                { name: "Delhi", lat: 28.6139, lng: 77.2090 },
                { name: "Bangalore", lat: 12.9716, lng: 77.5946 },
                { name: "Hyderabad", lat: 17.3850, lng: 78.4867 },
                { name: "Chennai", lat: 13.0827, lng: 80.2707 },
                { name: "Kolkata", lat: 22.5726, lng: 88.3639 },
                { name: "Ahmedabad", lat: 23.0225, lng: 72.5714 },
                { name: "Pune", lat: 18.5204, lng: 73.8567 },
                { name: "Jaipur", lat: 26.9124, lng: 75.7873 },
                { name: "Lucknow", lat: 26.8467, lng: 80.9462 }
            ];
            
            const results = {};
            
            // Step 1: Get Token
            const tokenResp = await fetch("https://wheretobuy.asus.in/r/gen-token");
            const tokenData = await tokenResp.json();
            const token = tokenData.token;

            // Step 2: Iterate categories and hubs
            for (let cat of [2, 1]) {
                for (let hub of HUBS) {
                    const payload = {
                        "lat": hub.lat,
                        "lng": hub.lng,
                        "city": "",
                        "category": String(cat),
                        "recNum": "5000",
                        "exclusive": (cat === 2),
                        "multibrand": (cat === 1),
                        "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
                    };

                    try {
                        const resp = await fetch("https://wheretobuy.asus.in/r/getStoreDetails", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                "token": token,
                                "referer": "https://www.asus.com/",
                                "origin": "https://www.asus.com"
                            },
                            body: JSON.stringify(payload)
                        });
                        const data = await resp.json();
                        if (data.status === "SUCCESS" && data.data) {
                            data.data.forEach(s => {
                                if (s.storeID) results[s.storeID] = s;
                            });
                        }
                    } catch (e) {}
                    await new Promise(r => setTimeout(r, 200));
                }
            }
            return results;
        })()
        """
        
        print("Executing browser-side extraction...")
        stores_dict = await page.evaluate(js_code)
        
        raw_json_path = os.path.join(OUTPUT_DIR, "india_stores_captured.json")
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        with open(raw_json_path, 'w', encoding='utf-8') as f:
            json.dump(stores_dict, f, indent=2)
            
        print(f"Captured {len(stores_dict)} unique stores. Data saved to JSON.")
        await browser.close()
        return list(stores_dict.values())

def finalize_extraction(india_stores):
    print("Finalizing data consolidation...")
    
    # 1. Load Global Data if exists
    global_csv_path = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    final_records = []
    
    if os.path.exists(global_csv_path):
        with open(global_csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                final_records.append(row)
        print(f"Loaded {len(final_records)} global records.")

    # 2. Add India Stores
    for s in india_stores:
        # Map Category to Activity
        activity = "Asus Exclusive Store" if str(s.get('category')) == "2" else "Asus Multi-Brand Store"
        
        # Clean address
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', 'ASUS Store')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })

    # 3. Export Final CSV
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    final_output_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    with open(final_output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(final_records)
        
    print(f"Final CSV exported to {final_output_path}")
    print(f"Total Unique Assets: {len(final_records)}")

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    india_data = loop.run_until_complete(extract_asus_india())
    finalize_extraction(india_data)
