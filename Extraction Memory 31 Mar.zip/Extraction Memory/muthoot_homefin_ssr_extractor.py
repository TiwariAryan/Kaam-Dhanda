"""
Muthoot Homefin GET-Param SSR Extractor
=======================================
Platform Pattern: Traditional SSR with GET parameters for filtering.
The locator uses State → City hierarchy via URL parameters.
Example: /branch-locator/?state=Andhra%20Pradesh&city=Rajahmundry#searchresult

Used for: Muthoot Homefin (India) Limited
API Base: https://www.muthoothomefin.com/branch-locator/
"""

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME   = "MUTHOOT HOMEFIN (INDIA) LIMITED"
ISSUER_ID     = "IID000000002618636" # Shared with parent if consolidated
BASE_URL      = "https://www.muthoothomefin.com/branch-locator/"
OUTPUT_DIR    = r"C:\Users\aryan\Downloads\ACWI Geo Analysts Gap Collection"
OUTPUT_FILE   = "muthoot_homefin_branches.csv"

# ═══════════════════════════════════════════════════════════
# GENERIC SSR LOGIC BELOW
# ═══════════════════════════════════════════════════════════

import httpx
import sys
import re
import csv
import time
from bs4 import BeautifulSoup
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
}

def get_page(client, params=None):
    for attempt in range(3):
        try:
            r = client.get(BASE_URL, params=params, headers=HEADERS, timeout=30)
            if r.status_code == 200:
                return r.text
            print(f"  [WARN] Request failed HTTP {r.status_code}")
            time.sleep(2)
        except Exception as e:
            print(f"  [ERR] {e}")
            time.sleep(2)
    return ""

def parse_dropdown(html, select_id):
    soup = BeautifulSoup(html, 'html.parser')
    select = soup.find('select', id=select_id)
    if not select:
        return []
    return [o.get('value') for o in select.find_all('option') if o.get('value')]

def parse_branches(html, state, city):
    soup = BeautifulSoup(html, 'html.parser')
    results_div = soup.find(id='searchresult')
    if not results_div:
        return []
        
    branches = []
    h4s = results_div.find_all('h4')
    for h in h4s:
        name = h.get_text(strip=True)
        # Skip generic headers like 'Connect With Us' or others if they appear
        if "Muthoot" not in name:
            continue
            
        p = h.find_next_sibling('p')
        address = p.get_text(strip=True) if p else ""
        
        branches.append({
            'FACILITY_NAME': name,
            'FACILITY_ADDRESS': address,
            'CITY': city,
            'STATE': state,
            'RELEVANT_URL': f"{BASE_URL}?state={state}&city={city}#searchresult"
        })
    return branches

def run():
    out_path = Path(OUTPUT_DIR) / OUTPUT_FILE
    branches = []
    seen = set()
    
    with httpx.Client(follow_redirects=True) as client:
        print("[1] Fetching root page for states...")
        root_html = get_page(client)
        states = parse_dropdown(root_html, 'search-state')
        print(f"Found {len(states)} states: {states}")
        
        for state in states:
            print(f"\n[STATE] {state}")
            # Get cities for this state
            state_html = get_page(client, {'state': state})
            cities = parse_dropdown(state_html, 'search-city')
            print(f"  Found {len(cities)} cities")
            
            for city in cities:
                city_html = get_page(client, {'state': state, 'city': city})
                loc_branches = parse_branches(city_html, state, city)
                
                for b in loc_branches:
                    key = (b['FACILITY_NAME'], b['FACILITY_ADDRESS'])
                    if key not in seen:
                        branches.append(b)
                        seen.add(key)
                
                if loc_branches:
                    print(f"    [{city}] +{len(loc_branches)} branches")
                time.sleep(0.5)

    # Save to CSV
    fieldnames = [
        'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
        'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
        'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
        'RELEVANT_URL', 'BUSINESS_ACTIVITY'
    ]
    
    with open(out_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for b in branches:
            row = {
                'ISSUER_ID': ISSUER_ID,
                'ISSUER_NAME': ISSUER_NAME,
                'FACILITY_NAME': b['FACILITY_NAME'],
                'FACILITY_ADDRESS': b['FACILITY_ADDRESS'],
                'CITY': b['CITY'],
                'STATE': b['STATE'],
                'POSTAL_CODE': '', # Scrape or infer if needed
                'FACILITY_REGION': 'India',
                'LATITUDE': '',
                'LONGITUDE': '',
                'FACILITY_CONTACT_NUMBER': '1800-121-1214',
                'RELEVANT_URL': b['RELEVANT_URL'],
                'BUSINESS_ACTIVITY': 'Affordable Housing Finance Branch'
            }
            # Extract pincode from address if possible
            pincode_m = re.search(r'(\d{6})', b['FACILITY_ADDRESS'])
            if pincode_m:
                row['POSTAL_CODE'] = pincode_m.group(1)
            
            writer.writerow(row)
            
    print(f"\n[DONE] Saved {len(branches)} Homefin branches to {out_path}")

if __name__ == "__main__":
    run()
