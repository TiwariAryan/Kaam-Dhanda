import csv
import httpx
import os

ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}.csv")

def append_service_centers():
    # 1. Fetch Service Centers
    url = "https://www.asus.com/support/api/service.asmx/GetServiceCenter?website=in"
    resp = httpx.get(url, timeout=30.0)
    data = resp.json().get('Result', {}).get('Obj', [])
    
    print(f"Fetched {len(data)} Asus Service Centers from India.")
    
    # 2. Read existing CSV records
    existing_records = []
    seen_keys = set()
    
    with open(FINAL_CSV, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        for row in reader:
            existing_records.append(row)
            key = (str(row.get('LOCATION_NAME', '')).lower().strip(), str(row.get('LOCATION_ADDRESS', '')).lower().strip())
            seen_keys.add(key)
            
    print(f"Loaded {len(existing_records)} existing records from CSV.")
    
    # 3. Process new service centers
    added = 0
    for sc in data:
        name = sc.get('SC_Name', "ASUS Service Center").strip()
        addr = sc.get('ADDRESS', '').replace('\n', ', ').strip()
        
        # Fallback to name if address is missing
        if not addr: addr = name
        
        stry_key = (name.lower(), addr.lower())
        
        if stry_key not in seen_keys:
            new_record = {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": name,
                "LOCATION_ADDRESS": addr,
                "LATITUDE": sc.get('GPS_Lat', ''),
                "LONGITUDE": sc.get('GPS_Lng', ''),
                "COUNTRY": "India",
                "COUNTRY_ISO3": "IND",
                "POSTCODE": "", # Address might have pincode but extraction via regex is brittle, leaving empty for now
                "STATE": sc.get('Area_Name', ''),
                "CITY": sc.get('City_Name', ''), # In payload? SC object didn't show city but it had Area_Name
                "SOURCE_URL": "https://www.asus.com/in/support/Service-Center/India",
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": "Asus Service Center",
                "coord_source": "website"
            }
            existing_records.append(new_record)
            seen_keys.add(stry_key)
            added += 1
            
    # 4. Write back
    with open(FINAL_CSV, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(existing_records)
        
    print(f"Added {added} unique service centers. Total Assets now: {len(existing_records)}")

if __name__ == "__main__":
    append_service_centers()
