import asyncio
import os
import csv
import json
import httpx
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

def generate_india_grid():
    # India bounding box roughly:
    # Lat: 8.0 to 37.0
    # Lng: 68.0 to 97.0
    # Step: 0.5 degrees (~55km). This provides extremely dense coverage.
    
    grid = []
    # Using 10x integers for stable float iteration (0.5 degrees)
    for lat in range(80, 375, 5): 
        for lng in range(680, 975, 5):
            grid.append({
                "lat": lat / 10.0,
                "lng": lng / 10.0
            })
    return grid

async def get_session():
    print("Launching Playwright to bypass WAF and generate session token...")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        # Navigate to origin token endpoint
        await page.goto("https://wheretobuy.asus.in/r/gen-token", wait_until="networkidle", timeout=60000)
        
        # Extract token from DOM
        text = await page.inner_text("body")
        token_data = json.loads(text)
        token = token_data.get('token')
        
        # Extract cookies
        cookies = await context.cookies()
        domain_cookies = {c['name']: c['value'] for c in cookies}
        
        await browser.close()
        print("Session established successfully!")
        return token, domain_cookies

async def fetch_stores(client, token, point, category, semaphore):
    async with semaphore:
        url = "https://wheretobuy.asus.in/r/getStoreDetails"
        headers = {
            "Content-Type": "application/json",
            "token": token,
            "origin": "https://www.asus.com",
            "referer": "https://www.asus.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        }
        
        is_exclusive = (category == 2)
        is_multibrand = (category == 1)
        
        payload = {
            "lat": point['lat'],
            "lng": point['lng'],
            "city": "",
            "category": "2", # API always expects "2" in category field
            "recNum": "2000",
            "exclusive": is_exclusive,
            "multibrand": is_multibrand,
            "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
        }
        
        try:
            resp = await client.post(url, headers=headers, json=payload, timeout=30.0)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "SUCCESS" and "stores" in data:
                    res = data["stores"]
                    return category, res
                else:
                    return category, []
            else:
                return category, []
        except Exception as e:
            return category, []

async def extract_asus_india():
    # 1. Setup Session
    token, cookies = await get_session()
    
    # 2. Get Grid Points
    points = generate_india_grid()
    print(f"Generated sparse geographical grid with {len(points)} coordinates covering India.")
    
    all_stores = {}
    semaphore = asyncio.Semaphore(150) # Very high concurrency to chunk the grid
    
    # Add a custom timeout to the httpx client using standard HTTPX parameters
    timeout = httpx.Timeout(30.0, read=60.0, connect=30.0)
    async with httpx.AsyncClient(cookies=cookies, timeout=timeout) as client:
        tasks = []
        for point in points:
            for cat in [2, 1]:  # Cat 2 = Exclusive, Cat 1 = Multi-Brand
                tasks.append(fetch_stores(client, token, point, cat, semaphore))
        
        print(f"Queued {len(tasks)} requests. Executing batch via HTTPX...")
        
        completed = 0
        total = len(tasks)
        for future in asyncio.as_completed(tasks):
            cat, returned_stores = await future
            completed += 1
            if completed % 500 == 0:
                print(f"  Progress: {completed} / {total} parallel tasks fulfilled...")
                
            for s in returned_stores:
                sid = s.get('storeId') or s.get('id') or f"{s.get('lat')}_{s.get('lng')}"
                if sid:
                    if sid not in all_stores:
                        s['activity_type'] = "Ex" if cat == 2 else "Mb"
                        all_stores[sid] = s
                        
    print(f"Total Unique India Stores Captured: {len(all_stores)}")
    return all_stores

def finalize(all_stores_dict):
    final_records = []
    
    # 1. Load Global (Pre-extracted)
    global_csv = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    if os.path.exists(global_csv):
        with open(global_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                final_records.append(row)
        print(f"Merged {len(final_records)} global records.")
    
    # 2. Add India Stores
    for s in all_stores_dict.values():
        activity = "Asus Exclusive Store" if s.get('activity_type') == "Ex" else "Asus Multi-Brand Store"
        # Address cleaning
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', 'ASUS Store')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })
        
    # Deduplicate
    deduped = []
    seen_keys = set()
    for r in final_records:
        key = (str(r['LOCATION_NAME']).lower().strip(), str(r['LOCATION_ADDRESS']).lower().strip())
        if key not in seen_keys:
            deduped.append(r)
            seen_keys.add(key)
            
    # Write output
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    output_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(deduped)
        
    print(f"Final CSV saved: {output_path}")
    print(f"Total Unique Assets: {len(deduped)}")

if __name__ == "__main__":
    try:
        india_stores = asyncio.run(extract_asus_india())
        finalize(india_stores)
    except Exception as e:
        print(f"Execution failed: {e}")
