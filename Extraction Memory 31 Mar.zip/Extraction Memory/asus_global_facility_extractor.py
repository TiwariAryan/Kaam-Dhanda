import httpx
from bs4 import BeautifulSoup
import csv
import re
import os

# ═══════════════════════════════════════════════════════════
# CONFIGURATION — Change these for each new issuer
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
BASE_URL       = "https://www.asus.com/us/About_ASUS/Facilities-Branches/"
OUTPUT_DIR     = "C:\\Users\\aryan\\Downloads\\31Mar Extractions"
OUTPUT_FILE    = f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv"

# ═══════════════════════════════════════════════════════════
# GENERIC EXTRACTION LOGIC BELOW — Do not modify per-issuer
# ═══════════════════════════════════════════════════════════

def clean_address(addr):
    if not addr: return ""
    addr = addr.replace("#", "").replace("\n", ", ").replace("\r", "")
    addr = re.sub(r'\s+', ' ', addr).strip()
    # Remove leading/trailing commas
    addr = addr.strip(", ")
    return addr

def parse_global_facilities():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    }
    
    print(f"Fetching {BASE_URL}...")
    resp = httpx.get(BASE_URL, headers=headers, timeout=30)
    soup = BeautifulSoup(resp.text, 'html.parser')
    
    # The sections are likely in div.AboutAsus-section or similar
    # Based on screenshot, they are in a structure with region headers.
    # Looking at the DOM capture info, we have America, Asia Pacific, China, Europe.
    
    facilities = []
    
    # The structure seems to be h3 or strong tags followed by address info.
    # In the screenshot, it shows "US Headquarters:", "ASUS Canada Branch Office:", etc.
    # We need to find these containers.
    
    # Let's iterate over all strong tags that end with colon or contain "Office" or "Headquarters"
    # Actually, a more robust way is to find the main content area.
    content_area = soup.find('div', class_='AboutAsus-content') or soup.find('div', class_='content') or soup
    
    # Regions are inside some wrapper. Let's look for the region names.
    regions = ["America", "Asia Pacific", "China", "Europe"]
    
    # We'll just find all office blocks. They seem to be structured as:
    # <strong>OFFICE NAME</strong><br>ADDRESS<br>...
    
    # Alternatively, let's find all sets of address data.
    # Based on the screenshot:
    # <strong>US Headquarters:</strong><br> 48720 Kato Rd<br> Fremont, CA 94538<br> USA ...
    
    for strong in soup.find_all('strong'):
        name = strong.get_text(strip=True)
        if not name or ":" not in name and "Office" not in name and "Headquarters" not in name:
            continue
            
        # Clean name
        name = name.rstrip(":")
        
        # Address is the following siblings until next strong or br separator
        address_parts = []
        sibling = strong.next_sibling
        while sibling and sibling.name != 'strong':
            if isinstance(sibling, str):
                text = sibling.strip()
                if text and "Tel:" not in text and "Fax:" not in text and "Website:" not in text and "Support Site:" not in text:
                    address_parts.append(text)
            elif sibling.name == 'br':
                pass # skip br tags but use them as delimiters visually
            elif sibling.name == 'a':
                # Skip links like Website or Contact form
                pass
            
            # Stop if we hit contact info
            if sibling.name == 'br' and sibling.next_sibling and isinstance(sibling.next_sibling, str):
                next_text = sibling.next_sibling.strip()
                if any(x in next_text for x in ["Tel:", "Fax:", "Website:", "Support Site:", "Email:"]):
                    break
            
            sibling = sibling.next_sibling
            if not sibling: break

        full_address = ", ".join(address_parts)
        full_address = clean_address(full_address)
        
        if not full_address or len(full_address) < 10:
            continue
            
        # Try to extract city/country/postcode from the address parts
        # Most of these follow: Street \n City, State Postcode \n Country
        country = ""
        city = ""
        postcode = ""
        state = ""
        
        if address_parts:
            # Last part is usually country
            candidate_country = address_parts[-1].strip(", ")
            if len(candidate_country) > 2 and not any(char.isdigit() for char in candidate_country):
                country = candidate_country
                # 2nd to last is usually City, State Postcode
                if len(address_parts) >= 2:
                    city_state_zip = address_parts[-2]
                    # Try to separate city, state, zip
                    # Fremont, CA 94538
                    match = re.search(r'^(.*?),\s*([A-Z]{2})\s*(\d{5}(?:-\d{4})?)', city_state_zip)
                    if match:
                        city = match.group(1)
                        state = match.group(2)
                        postcode = match.group(3)
                    else:
                        # Markham, Ontario L3R 0E9
                        match_ca = re.search(r'^(.*?),\s*(.*?)\s+([A-Z]\d[A-Z]\s?\d[A-Z]\d)', city_state_zip)
                        if match_ca:
                            city = match_ca.group(1)
                            state = match_ca.group(2)
                            postcode = match_ca.group(3)
                            
        # Final cleanup for country-specifics if regex failed
        if not country and "USA" in full_address: country = "USA"
        if not country and "Canada" in full_address: country = "Canada"
        if not country and "Mexico" in full_address: country = "Mexico"
        
        facilities.append({
            "LOCATION_NAME": name,
            "LOCATION_ADDRESS": full_address,
            "COUNTRY": country,
            "CITY": city,
            "STATE": state,
            "POSTCODE": postcode,
            "SOURCE_URL": BASE_URL,
            "ACTIVITY_AT_SOURCE": "Corporate Office / Branch"
        })
        
    return facilities

def export_to_csv(facilities, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    fields = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for fac in facilities:
            row = {
                "ISSUER_ID": ISSUER_ID,
                "ISSUER_NAME": ISSUER_NAME,
                "LOCATION_NAME": fac.get("LOCATION_NAME", ""),
                "LOCATION_ADDRESS": fac.get("LOCATION_ADDRESS", ""),
                "LATITUDE": "",
                "LONGITUDE": "",
                "COUNTRY": fac.get("COUNTRY", ""),
                "COUNTRY_ISO3": "", # Will fill later
                "POSTCODE": fac.get("POSTCODE", ""),
                "STATE": fac.get("STATE", ""),
                "CITY": fac.get("CITY", ""),
                "SOURCE_URL": fac.get("SOURCE_URL", ""),
                "SOURCE_TYPE": "COMPANY WEBSITE",
                "ACTIVITY_AT_SOURCE": fac.get("ACTIVITY_AT_SOURCE", ""),
                "coord_source": ""
            }
            writer.writerow(row)

if __name__ == "__main__":
    data = parse_global_facilities()
    export_to_csv(data, os.path.join(OUTPUT_DIR, OUTPUT_FILE))
    print(f"Extracted {len(data)} global facilities.")
