import asyncio
import os
import csv
import json
import httpx
from playwright.async_api import async_playwright

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
ISSUER_NAME    = "ASUSTEK COMPUTER INCORPORATION"
ISSUER_ID      = "IID000000002141568"
OUTPUT_DIR     = r"C:\Users\aryan\Downloads\31Mar Extractions"
FINAL_CSV      = f"{ISSUER_ID}_{ISSUER_NAME}.csv"

async def get_session():
    print("Launching Playwright to bypass WAF and generate session token...")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        # Navigate to origin token endpoint
        await page.goto("https://wheretobuy.asus.in/r/gen-token", wait_until="networkidle", timeout=60000)
        
        # Extract token from DOM
        text = await page.inner_text("body")
        token_data = json.loads(text)
        token = token_data.get('token')
        
        # Extract cookies
        cookies = await context.cookies()
        domain_cookies = {c['name']: c['value'] for c in cookies}
        
        await browser.close()
        print("Session established successfully!")
        return token, domain_cookies

async def fetch_stores(client, token, city, category, semaphore):
    async with semaphore:
        url = "https://wheretobuy.asus.in/r/getStoreDetails"
        headers = {
            "Content-Type": "application/json",
            "token": token,
            "origin": "https://www.asus.com",
            "referer": "https://www.asus.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        }
        
        # category mapping: "2" for exclusive, "1" for multibrand
        is_exclusive = (category == 2)
        is_multibrand = (category == 1)
        
        payload = {
            "lat": float(city.get('lat', 0)),
            "lng": float(city.get('lng', 0) if city.get('lng') else city.get('lon', 0)),
            "city": "",
            "category": "2", # API always expects "2" in category field
            "recNum": "2000",
            "exclusive": is_exclusive,
            "multibrand": is_multibrand,
            "search": "", "placeId": "", "productCategory": "", "modelName": "", "pincode": ""
        }
        
        try:
            resp = await client.post(url, headers=headers, json=payload, timeout=20.0)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("status") == "SUCCESS" and "stores" in data:
                    res = data["stores"]
                    return category, res
                else:
                    return category, []
            else:
                return category, []
        except Exception as e:
            return category, []

async def extract_asus_india():
    # 1. Setup Session
    token, cookies = await get_session()
    
    # 2. Get Cities
    print("Downloading massive Indian Cities listing (1200+)...")
    async with httpx.AsyncClient() as c:
        resp = await c.get("https://raw.githubusercontent.com/nshntarora/Indian-Cities-JSON/master/cities.json")
        cities = resp.json()
        
    print(f"Loaded {len(cities)} cities. Generating parallel requests...")
    
    all_stores = {}
    semaphore = asyncio.Semaphore(100) # 100 concurrent requests!
    
    async with httpx.AsyncClient(cookies=cookies) as client:
        tasks = []
        for city in cities:
            for cat in [2, 1]:  # Cat 2 = Exclusive, Cat 1 = Multi-Brand
                tasks.append(fetch_stores(client, token, city, cat, semaphore))
        
        print(f"Queued {len(tasks)} requests. Executing batch...")
        
        # Using enumerate to track progress without blocking
        completed = 0
        total = len(tasks)
        for future in asyncio.as_completed(tasks):
            cat, returned_stores = await future
            completed += 1
            if completed % 500 == 0:
                print(f"  Progress: {completed} / {total} requests complete...")
                
            for s in returned_stores:
                sid = s.get('storeId') or s.get('id') or f"{s.get('lat')}_{s.get('lng')}"
                if sid:
                    if sid not in all_stores:
                        s['activity_type'] = "Ex" if cat == 2 else "Mb"
                        all_stores[sid] = s
                        
    print(f"Total Unique India Stores Captured: {len(all_stores)}")
    return all_stores

def finalize(all_stores_dict):
    final_records = []
    
    # 1. Load Global (Pre-extracted)
    global_csv = os.path.join(OUTPUT_DIR, f"{ISSUER_ID}_{ISSUER_NAME}_Global.csv")
    if os.path.exists(global_csv):
        with open(global_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                final_records.append(row)
        print(f"Merged {len(final_records)} global records.")
    
    # 2. Add India Stores
    for s in all_stores_dict.values():
        activity = "Asus Exclusive Store" if s.get('activity_type') == "Ex" else "Asus Multi-Brand Store"
        # Address cleaning
        addr = str(s.get('address', '')).replace('#', '').replace('\n', ', ').strip()
        if not addr: addr = s.get('name', 'ASUS Store')
        
        final_records.append({
            "ISSUER_ID": ISSUER_ID,
            "ISSUER_NAME": ISSUER_NAME,
            "LOCATION_NAME": s.get('name'),
            "LOCATION_ADDRESS": addr,
            "LATITUDE": s.get('lat'),
            "LONGITUDE": s.get('lng'),
            "COUNTRY": "India",
            "COUNTRY_ISO3": "IND",
            "POSTCODE": s.get('postal'),
            "STATE": s.get('state'),
            "CITY": s.get('city'),
            "SOURCE_URL": "https://www.asus.com/in/microsite/shop-near-me/",
            "SOURCE_TYPE": "COMPANY WEBSITE",
            "ACTIVITY_AT_SOURCE": activity,
            "coord_source": "website"
        })
        
    # Deduplicate
    deduped = []
    seen_keys = set()
    for r in final_records:
        key = (str(r['LOCATION_NAME']).lower().strip(), str(r['LOCATION_ADDRESS']).lower().strip())
        if key not in seen_keys:
            deduped.append(r)
            seen_keys.add(key)
            
    # Write output
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    output_path = os.path.join(OUTPUT_DIR, FINAL_CSV)
    fieldnames = [
        "ISSUER_ID", "ISSUER_NAME", "LOCATION_NAME", "LOCATION_ADDRESS", "LATITUDE", "LONGITUDE",
        "COUNTRY", "COUNTRY_ISO3", "POSTCODE", "STATE", "CITY", "SOURCE_URL", "SOURCE_TYPE",
        "ACTIVITY_AT_SOURCE", "coord_source"
    ]
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(deduped)
        
    print(f"Final CSV saved: {output_path}")
    print(f"Total Unique Assets: {len(deduped)}")

if __name__ == "__main__":
    try:
        india_stores = asyncio.run(extract_asus_india())
        finalize(india_stores)
    except Exception as e:
        print(f"Execution failed: {e}")
