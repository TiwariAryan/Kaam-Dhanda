---
name: rooftop-geocoder
version: 0.6.23
description: >
  Populate missing rooftop-precision LATITUDE/LONGITUDE for facility/asset records by
  resolving each row to an authoritative location and then visually confirming the pin on
  satellite imagery via the browser. Trigger whenever a facility/asset spreadsheet has empty
  or low-confidence coordinates and the user asks to find, fill, verify, re-evaluate, or QA
  them — phrasings like "geocode these facilities", "get rooftop coordinates", "fill the
  lat/long", "coordinate QA", "re-evaluate the manual_review rows", or "run the geocoder".
  Runs as chained passes across multiple sessions against one shared results file, and
  combines them into a final, satellite-verified output. Handles Korea, Japan, China, and
  global rows.
---

# Rooftop Geocoder — v0.6.23 (shared core)

A facility coordinate is **rooftop-grade only when two independent things are true**: the
location is *correct* (an authoritative address/POI) **and** the pin *physically sits* on a
structure consistent with the facility (satellite-confirmed). Text evidence (maps, web
search, registries, filings) establishes the first; satellite establishes the second.
Neither alone is sufficient. This skill is built around that fact.

The work runs as four chained passes over **one shared, append-only `results.jsonl`** that is
the single source of truth and survives any session reset. You will usually run many sessions;
each resumes from that file, and a final session combines everything.

---

## §0 — CONTRACT (non-negotiable; the validator enforces these)

These are gates, not suggestions. A row that violates them is not "done".

0. **Pass A and Pass B are agent-driven browser loops — NEVER a deterministic script or geocoding API.**
   Do not write or run a `*_runner.py`, a `requests`/`httpx` geocoder, a headless-browser scraper, or any
   batch job that "resolves rows" by fetching a coordinate. These are **API-residual** records — the
   deterministic path already failed on them — so resolving them *requires* live map navigation plus visual
   identity reasoning, which only the agent (you, via `@Browser`) performs per row. Python's role is limited
   to the **helper scripts** (`query_builder` suggests queries; `geo_convert`/`geo_bbox` do datum and bbox
   math; `generate_handoff` writes a resume record; `validate_results`/`assemble_results` gate and build) —
   none of them fetches a coordinate. Translations and name variants are resolved by **reading the native
   map**, never hardcoded in a dict. If you catch yourself building a runner to "speed up" Pass B, stop: that
   reproduces the very failures these rows represent and does none of the trap-checking the ladder exists for.
1. **No row is `resolved` without evidence.** To mark `resolved` a row MUST carry: a
   coordinate, a non-empty `RESOLUTION_QUERY`, an `EVIDENCE_SOURCE`, and `SATELLITE_VERDICT = pass`.
   The only exception is a row explicitly flagged by the gold-standard exemption (§4) — and that
   exemption is **off by default**.
2. **No processed row is left blank.** Every row you touch ends as `resolved`, `manual_review`,
   or `not_found`, and every non-`resolved` row has an actionable `REVIEW_REASON`.
3. **`manual_review` requires an exhausted ladder.** A row may only *stay* `manual_review` after
   the full Pass-B ladder (§3) has been attempted and recorded in `LADDER_TRIED`. "I reached a
   ceiling" means "the recorded ladder is exhausted", never a hunch.
4. **Carry `FACILITY_ID` programmatically** through query → result → record. Never map a result
   to a row by position, order, or memory.
5. **Read minimal text, not pixels or the whole DOM** (the single biggest per-row token lever). Two tiny
   strings settle most rows: the coordinate from the **complete page URL** (`!3d<lat>!4d<lng>` in the
   `data=` segment, *after* `@<viewport>,<zoom>` — read the whole URL / Tab Context / `location.href`, not
   the truncated address bar, which often shows only `@<viewport>`; the `@<viewport>` is the map camera,
   **never** the recorded answer), and the matched place name from **`document.title`** — which also runs
   your identity / name-match and trap checks (e.g. a title of "VGP Universal Kingdom" is the Chennai
   brand-trap). **Do NOT take a full-page snapshot by default** — the Google Maps DOM/accessibility tree is
   huge and is usually the largest single cost in a row; capture a snapshot **only** when you must reason
   over page *content*, i.e. to disambiguate a `/maps/search/` results list. **Stop the moment the URL
   yields the coordinate**: if the search redirected to `/maps/place/…!3d!4d`, read it and move on — do not
   click the pin or grab extra observations. If the card shows a **Plus Code** but the URL has no
   `!3d!4d`, decode it (`geo_convert`) → `COORD_SOURCE=plus_code`. Spend a screenshot only on the satellite
   check (§4), and keep it **full fidelity** (it is the quality gate — never downscale it). Pace the browser
   at **≤4–5 ops per batch** where the connector is fragile (the Cowork sandbox freezes after ~12–15 consecutive ops; built-in waits do not reset it). Batching is an internal pacing mechanic; how a pass continues past it is environment-specific (**§6**) — in Cursor you recover and resume the loop yourself without stopping, in Cowork the freeze bounds a session before handoff.
6. **China coordinates are datum-corrected before writing** (GCJ-02/BD-09 → WGS-84 via
   `geo_convert`) and satellite-confirmed on **Google** imagery (which is WGS-84-aligned over China).
7. **The KB is append-only** (§7): deprecate-and-point, never rewrite or delete.
8. **Use the most authoritative *native* map per region for the coordinate, queried in the local script** —
   **mainland China** (route by **`COUNTRY_ISO3` == `CHN` exactly** — never `FACILITY_REGION` *containing*
   "China", as Taiwan's region is "Taiwan (Province of China)"; **HKG / MAC / TWN have their own ISO3 and are
   NOT China-routed** — they take the Google path) → Baidu (BD-09) with a **Chinese-script** query; Korea →
   Kakao (WGS-84) with a **Korean-script** query; elsewhere → Google — **where your runner environment
   supports it** (the runner file, `AGENTS.md` or the Claude `README`, states what is usable here), and
   **always validate the result on Google satellite** (§4, §6). Persist any native query string actually used
   in the `<COL>_NATIVE` columns (§5), under the native-script discipline in §4. Where a native map is blocked
   in your environment, route around it (native-language text search; China registry) and still verify on
   Google satellite — never spin on a blocked tool.
9. **`resolved_pending_qa` requires a candidate coordinate.** That status means "a coordinate awaiting
   the satellite check". If none could be extracted (no `!3d!4d`, no decodable Plus Code, no clean
   place-page coordinate), the row is `manual_review` with a reason — **never** `resolved_pending_qa` off
   an address that was never actually geocoded. (The validator hard-fails a pending row without a coordinate.)

---

## §1 — Inputs, paths, and naming

Provided per run (in the trigger prompt):
- `INPUT_PATH` — the facility file (.xlsx/.csv) to process.
- `KB_PATH` — the technical knowledge base (read region-relevant sections on demand; append per §7).
- `FS_DIR` — the shared filesystem folder (where the KB lives). Durable state goes in `FS_DIR/results/`.
- Optional params: `PASS` (A|B|C|combine, default A), `BATCH_ROWS` (default all remaining),
  `CHECKPOINT_EVERY` (default 25), `SESSION_N` (the nth session for this input), `GOLD_EXEMPTION` (default off).

Derive `BASE = <input file name without extension>`. Then:
- **State (shared across all sessions for this input):** `FS_DIR/results/<BASE>_results.jsonl`
  — keyed on `FACILITY_ID`, append-only, the source of truth. One per input file.
- **Handoff (per session):** `FS_DIR/results/<BASE>_HANDOFF_n<SESSION_N>.md`.
- **Final deliverable:** `FS_DIR/results/<BASE>_rooftop_geocoded.xlsx`.

If `FACILITY_ID` is absent in the input, synthesize a stable `ROW_ID = <ISSUER_ID>_<index:03d>`
once and use it everywhere; never re-derive it positionally later.

---

## §2 — The passes (chained; each reads + appends `results.jsonl`)

Run one pass per instruction, completing it per **§6** (one autonomous loop in Cursor; handed-off
sessions in Cowork / Claude chat). Always **resume first**: read `<BASE>_results.jsonl`, skip every
`FACILITY_ID` already at a terminal state for this pass, and work the remainder. The chain is
**A → B → B.1 → C → (out) → D → (out)**: Pass C is the satellite gate every candidate must clear, and Phase D
is an **optional** deep pass over the residual. The workflow has a clean **out at the end of Pass C** (ship
what's `resolved`, leave the rest `manual_review`) and again at the **end of Phase D**.

- **Pass A — Resolve from the existing address (browser, image-light).** The bulk pass, and the first
  thing tried for every row: take the address **already in the input**, run it on Google Maps
  (`/maps/search/<query>`, never `/maps/place/`), and **reason about the result the way the ground-truth
  cases were solved** — does the returned POI/area match the facility by name, type, and location?
  Use `geo_convert.triage_address` first to route obvious non-geocodables; read the coordinate from the
  URL (`!3d!4d`); use `isPlace` + result-count to tell a clean single POI from an ambiguous list or the
  Mumbai 19.16,72.86 user-location trap. Datum-convert China. **Run the centroid check (§3.5) before
  accepting a coordinate** — a town/admin centroid is not a rooftop. Write a candidate coordinate,
  `PRECISION_TIER`, `RESOLUTION_QUERY`, `EVIDENCE_SOURCE=address_on_maps`, and a status of
  `resolved_pending_qa` (confident, name-matching pin) or `manual_review` (ambiguous / list-centre / low
  confidence / no name match / **centroid**). **A centroid / `town_centroid` flag from Pass A is NOT
  terminal — it is a mandatory Pass B input** (the POI ladder is what turns a town hit into a building);
  never leave a Pass-A centroid row unprocessed by Pass B.

- **Pass B — Re-resolve the `manual_review` set.** For every `manual_review` row, construct a better
  POI/search query from *all* attributes and climb the §3 ladder, record `LADDER_TRIED`, and either
  produce a better candidate (`resolved_pending_qa`) or leave it `manual_review`/`not_found` with a reason.
  **`town_centroid` / `centroid_fallback` rows from Pass A are PRIMARY Pass B inputs, not Phase-D inputs** —
  converting those locality hits into building POIs is Pass B's whole job, so it must process every one
  (their `LADDER_TRIED` is non-empty afterward). **Apply the centroid check (§3.5) to every candidate**; a
  candidate that is *still* a centroid after the ladder is exhausted retains its coordinate and routes to
  Phase D. This is where `manual_review` is driven to the minimum — honestly, by exhausting techniques, not
  guessing. **Guard: never take the Pass-C out on a `town_centroid` row whose `LADDER_TRIED` is empty — an
  empty ladder means Pass B was skipped (the failure mode that silently inflates the residual); run Pass B
  on it first.**

- **Pass B.1 — Address/POI enrichment (before the gate, §3.6).** For rows still `manual_review` after Pass
  B — stuck mainly because the *input is too thin to find the building* (place-only, no street number) — the
  LLM builds a **more specific address or POI** from `RELEVANT_URL` + web search + all attributes, then
  re-resolves it the Pass A way. Browser + LLM, **no geocoder/scraper** (§0 rule 0). A more specific
  candidate → `resolved_pending_qa` (→ Pass C); nothing more specific found → stays `manual_review`, and the
  attempt earns the honest `needs_operator_data` label.

- **Pass C — Satellite verification gate (mandatory, verify-all).** For **every** `resolved_pending_qa`
  row, open Google satellite at the candidate coordinate and confirm the pin sits on a structure
  consistent with `BUSINESS_ACTIVITY`/`FACILITY_NAME` (§4). Record `SATELLITE_VERDICT`. Pass →
  `resolved`. A **wrong-location** fail (farmland/water/town-centroid) → fix if a better pin is visible,
  else `manual_review`. An **activity-mismatch** fail (precise structure, but its type doesn't match the
  activity) → set `BIZ_SATELLITE_MISMATCH=true`, **retain the coordinate** at `structure` tier, and hold as
  `manual_review` for adjudication (§4). Only Pass C can move a row to `resolved`.

- **OUT (end of Pass C).** At this point the deliverable is shippable: validate + assemble (below). Every
  `resolved` row is satellite-confirmed; the residual (`manual_review`/`not_found`, plus centroid and
  `BIZ_SATELLITE_MISMATCH` rows) is honestly flagged. **Phase D is optional** — run it only if the residual
  size justifies the extra spend.

- **Phase D — Deep investigation of the residual (optional, §4.7).** Uses the browser's full capability —
  Street View / road-view signage, open web + image search, multi-signal disambiguation, phone/field
  cross-check — on the *typed* residual: `manual_review`-from-B (find), `BIZ_SATELLITE_MISMATCH` (adjudicate),
  and centroid/`town_centroid` (refine to the real roof). Every candidate D produces still flows back
  through the **same Pass C gate** before it can become `resolved`. Bounded by a per-row budget and pre-D
  triage (§4.7).

- **OUT (end of Phase D).** Validate + assemble again. What D couldn't crack stays `manual_review`/`not_found`
  honestly — D shrinks the residual, it does not eliminate it.

- **Combine (final session).** Read the cumulative `results.jsonl`, run `validate_results.py`
  (the §0 gate), assemble `<BASE>_rooftop_geocoded.xlsx` with the evidence columns, and emit a QA
  report (counts by status/tier/region, the false-fail and disagreement lists).

- **Alternate entry — Satellite-Direct (§4.8).** For rows that already carry a coordinate (QA / precision-
  upgrade) or that are visually-distinctive landmarks, you may enter at **Pass C directly** and resolve the
  roof from satellite. It is **not** a general A→B replacement — the satellite camera needs an anchor, so
  coordinate-less generic rows still go through A/B.

Passes A→B→C are sequential *per row* but you may interleave at the session level (e.g., a session
that does Pass A on one cluster and Pass C on an already-resolved cluster) — the row's status field
tracks where each row is.

### §2.1 — End-of-pass NEXT STEPS (every pass tells the user where to go)

At the end of **every** pass, after its run report, the agent prints a short **NEXT STEPS** block — the next
phase to run, the full path map, and (tailored to what just happened) the live residual counts. State the
optional/required nature explicitly:
- after **A** → next is **B** (the `manual_review` rows). Nothing is shippable yet — no row is confirmed
  until Pass C.
- after **B** → next is **B.1** (rows still `manual_review`). Still nothing shippable until C.
- after **B.1** → next is **Pass C** (the satellite gate — the first point anything becomes `resolved`).
- after **C** → present the fork **in this order**: **(1) push the residual further (the expected path):**
  run **Phase D**, then **Pass C again** on D's new candidates, then validate + assemble; **(2) optional —
  ship here (Pass C is a valid exit):** run validate + assemble now. Include the live residual
  (X `manual_review`, of which Y `needs_operator_data`, Z `town_centroid`) and the rule of thumb (run D when
  the residual justifies the spend).
- after **Phase D** → **REQUIRED next: Pass C again** on the `resolved_pending_qa` rows (D never marks rows
  `resolved` itself), then validate + assemble. **D→C is the end of the chain — no further phase.**
- after **validate + assemble** → output is terminal; optional follow-ups: a curated weird-case QA sample,
  or **Satellite-Direct (§4.8)** to re-QA already-`resolved` rows.

Full chain for reference: **A → B → B.1 → C → (optional: D → C again) → validate + assemble.**

---

## §3 — The technique ladder (Pass B; ordered, must-record)

**Pass B is run by the agent in the browser, one row at a time — not by a script.** (§0 rule 0.) You climb
the ladder by driving `@Browser` and *reasoning* over each result — these are the ambiguous rows Pass A
could not name-match, so the entire point is judging "is this the right facility or a same-name trap?", which
a scraper cannot do. `query_builder.py` only *proposes* queries; you navigate and confirm them.

The street address is already in the input (the extraction pipeline produced it), so Pass B does **not**
re-find addresses — it constructs a better POI/search query from the attributes already present and
confirms the pin. Climb in this order; stop at the first rung that yields a satellite-confirmable pin.
Record every rung attempted in `LADDER_TRIED` (e.g. `poi;native;url`).

1. **POI / search-query construction (primary).** From the name + (already-extracted) address + region
   (+ any brand from `RELEVANT_URL`), build the best Google Maps query and try the ranked variants
   (`query_builder.py` proposes them). **For any non-English facility, render the query into the local
   script** (hanzi / kanji / Hangul) — native-language rendering is part of constructing the query, not a
   separate step. Geocode on Google (`/maps/search/`); read the coordinate from the URL.
2. **`RELEVANT_URL` / official page (fallback).** If the constructed query yields no confirmable POI,
   check the facility's own page or the issuer filing for a more specific landmark/POI. (`web_fetch`
   returns empty on SPA pages → web-search the company + facility instead.)
3. **[China-only exception] business registry / Baike.** For Chinese-language records still unresolved,
   search a registry/Baike page — `<company-hanzi> <city> 分公司 地址` — which often gives a registered
   address inside a named development that then geocodes cleanly. **Do not use this rung for non-Chinese
   records**; their address is already provided, so POI construction + satellite is the path.
4. If no rung yields a confirmable location → `manual_review` (with the reason) or `not_found`
   (genuinely no single site: portfolios, "(multiple)", province-wide multi-dealer, undeveloped land, "Remote").

Do **not** declare a ceiling before the ladder is recorded as exhausted (§0.3). Every candidate still
goes through Pass C (satellite) before it can become `resolved`.

---

## §3.5 — Centroid check (run on every candidate, in Pass A and Pass B)

A town/admin/region centroid is not a rooftop. Before promoting any candidate to `resolved_pending_qa`,
screen it with **three complementary layers** (a flagged row keeps its coordinate and routes to Phase D —
it is never discarded; Pass C is the final backstop, so a miss costs only a wasted screenshot and a false
flag costs only some Phase D effort):

1. **Matched-place-type (primary, live).** Read what the map actually matched. If it is an area entity —
   a city/town/district/region/postal area — and **not** a building/POI, the coordinate is a centroid.
   `geo_convert.is_centroid_place_type(types)` decides from the place-type string you read off the result
   (Google `location_type` `APPROXIMATE`/`GEOMETRIC_CENTER`, or types like `locality` /
   `administrative_area_level_N` / `postal_code` / `route`). This is the one signal that catches a
   **single-record** centroid that no clustering check can see.
2. **Known-centroid fingerprint (live, deterministic).** `geo_convert.known_centroid_match(lat, lng)` →
   flags a coordinate sitting on a documented national/junk centroid (e.g. the KR 36.438/127.833
   fingerprint). Extend `KNOWN_CENTROIDS` as new ones surface.
3. **Clustering sweep (dataset-level, deterministic).** `scripts/centroid_fallback.py` flags coordinates
   reused across unrelated entities (4-tier + co-location safety valve) and same-issuer coordinate
   duplicates. Run it over a large input or the assembled output (its thresholds are tuned for big sets);
   `IS_CENTROID_FALLBACK`/`CENTROID_TIER` rows route to Phase D. This catches systematic mass-reuse that
   per-row logic can't.

If any layer flags a row: keep the coordinate, set `STATUS=manual_review`, `REVIEW_REASON=town_centroid`
(or `centroid_fallback:<tier>`). Do **not** promote a centroid to `resolved_pending_qa`. **Route order:
Pass B first** — the POI ladder is built to turn a locality hit into a building POI and rescues the majority
of these — then Phase D **only** for rows Pass B still cannot resolve to a structure. A centroid flagged in
Pass A must not skip Pass B.

---

## §3.6 — Pass B.1: Address/POI enrichment (between Pass B and Pass C)

Most rows that survive Pass B as `manual_review` are stuck for one reason: **the input is too thin to find
the building** (place-only address, no street number — e.g. "Rabigh, Saudi Arabia", "Gujarat", "Fornebu"),
not because the facility is genuinely unfindable. Pass B.1 runs **before** such a row is sent to Pass C as a
coarse pin (or declared stuck): it has the LLM **build a more specific address or POI from everything
available**, then re-resolve. This is browser + LLM work — **no geocoder, no scraper** (§0 rule 0).

**Input.** Every row still `manual_review` after Pass B (whether it carries a coarse coordinate or none).

**Method (per row, bounded):**
1. **Fetch the `RELEVANT_URL`** — the operator's own site / store-/branch-/plant-locator / facility page —
   and read it for *this* facility's specific street address, building name, or embedded map link.
2. **Web-search** the facility name + issuer/company + city/region (+ any partial address) for a specific
   street address, building, or named POI.
3. **LLM synthesis.** Combine *all* attributes (name, issuer, city, state, region, business activity, any
   partial address, the URL content, the search hits) into the single **most specific address or POI query
   you can justify** — e.g. turn a bare "<issuer>, <city>" into "<issuer> <specific building / park / road>,
   <city>" when the URL or search reveals it, or construct a named-POI query the map can resolve to a
   building. **Do not invent specificity the evidence doesn't support.**
4. **Re-resolve** the enriched query the Pass A way: `/maps/search/<enriched query>` (CN→Baidu, KR→Kakao),
   read the coordinate from the **complete URL** (`!3d!4d`), datum-convert China, run the §3.5 centroid
   check. Record the enriched query in `RESOLUTION_QUERY`, `EVIDENCE_SOURCE = relevant_url | web_search |
   operator_site`, and add a `b1_enrich` rung to `LADDER_TRIED`.

**Output.** A more specific candidate → `resolved_pending_qa` (→ Pass C, the same gate). If enrichment
yields nothing more specific than the place-only input, the row stays `manual_review` with
`needs_operator_data` — the enrichment attempt is what earns it (public *address* sources were tried). **This
label is NOT terminal at B.1:** Phase D still re-attempts these rows with techniques that need no street
address — landmark visual signature, Street View signage, deep registry (§4.7) — so a `needs_operator_data`
from B.1 is a hand-off to D, not a dead end.

**Cost control & honest bound.** Per-row budget like Phase D; lead with the `RELEVANT_URL` (cheapest,
highest-yield), escalate to web search, stop when a specific query is in hand. B.1 rescues rows whose
more-specific address/POI **exists somewhere public**; it **cannot** manufacture precision for genuinely
unpublished facilities. Those become `needs_operator_data` — but that is a B.1→D hand-off, not the end:
D's address-independent techniques get a shot before the label is re-confirmed, and only a row that defeats
*both* B.1 and D genuinely needs issuer-supplied data.

---

## §4 — The satellite gate (Pass C)

**Open satellite deterministically by URL** — navigate straight to
`https://www.google.com/maps/@<lat>,<lng>,150m/data=!3m1!1e3` (`!3m1!1e3` forces satellite, `150m` ≈
rooftop zoom) rather than toggling the Layers panel (which wastes ops). Spend **one** screenshot per row.
For a coordinate that came from a **native** map (Baidu / Kakao), this Google-satellite check is also how
it is *validated against Google* — the converted WGS-84 pin must land on the right structure.

> **Pin the tab and prove it before you trust the pixels (mandatory).** The screenshot is the verification
> — so a screenshot of the *wrong tab* silently passes the wrong coordinate. This is a real failure mode:
> the browser surface is shared (multiple tabs, and any concurrent agent/subagent can move a tab), and the
> screenshot tool otherwise grabs whatever tab is *focused*, not the one you navigated. Guard every row:
> 1. **One satellite tab, addressed by id.** Open a single dedicated tab for Pass C and record its tab/view
>    id (`browser_tabs`). **Always** navigate and screenshot **that id** — never the "active" tab.
> 2. **Re-read the URL and confirm it matches before screenshotting.** After navigating, read that tab's
>    current URL, parse the `@<lat>,<lng>` camera centre, and confirm it is within ~0.0005° (~50 m) of the
>    row's intended `<lat>,<lng>`. Only then take the screenshot.
> 3. **Mismatch → do not record a verdict.** If the URL shows a different place (a stray process moved the
>    tab, or the wrong tab was captured), re-select the satellite tab by id, re-navigate, and re-confirm. If
>    it still won't match, set `SATELLITE_VERDICT = not_checked`, leave the row `resolved_pending_qa` (or
>    `manual_review` with `REVIEW_REASON = tab_mismatch_retry`), and move on. **Never** write `pass`/`fail`
>    from a screenshot whose URL you did not confirm.
>
> This holds even when the screenshot tool grabs whatever tab is focused — a tab mix-up becomes a
> *detectable, recoverable* event (the URL won't match) instead of a silent wrong-coordinate.

**Optional precision — mark the exact point.** The camera URL centres the view but shows **no pin**, so by
default you're judging the building at the *frame centre*. To check the exact coordinate rather than the
centre, either **search the coordinate** (`https://www.google.com/maps/search/<lat>,<lng>` pins the
*literal* point — unlike `/maps/place/…` it does **not** snap to a nearby POI) and switch that tab to
satellite, or **right-click the frame centre → "What's here?"** to drop a pin and read its coordinate back.
Keep the `@<lat>,<lng>,150m/data=!3m1!1e3` camera URL as the primary (the URL guard validates it); use the
explicit pin when a row is borderline and you need to see precisely where the coordinate falls.

**The rooftop standard — what `pass` requires — depends on the activity class:**
- **Building-based activities** (office, education, bank/post office, retail/store, R&D, clinic, hotel, data
  centre, small warehouse, etc.): the pin must sit on the **roof of the building itself** — not its parking
  lot, access road, or courtyard. → `PRECISION_TIER = structure`.
- **Large-complex / capital-intensive activities that CONTAIN buildings** (airport, sea/air port, power
  plant, refinery, large warehouse / distribution terminal, factory/plant, smelter, cement/steel works,
  etc.): the pin must sit on the **roof of an identifiable building *inside the facility's premises*** — the
  terminal building (not the runway), a turbine / control / admin building (not the open switchyard or
  yard), the warehouse building roof (not the parking or access road). **Landing on the runway / open yard /
  parking / road is NOT a pass** — re-pin to an in-facility building roof. → `PRECISION_TIER = structure`
  (or `parcel` only if the complex genuinely has no resolvable single building and you can place just the
  site).
- **Activities with NO building** (mine, quarry, agricultural land/estate, solar farm, wind farm, reservoir,
  etc.): there is **no rooftop**. Place the **best representative point of the facility** (the pit/complex,
  the panel array, the field), confirmed by its **visual signature** on satellite (pit/tailings, panel rows,
  turbine rows, cultivated land). → `PRECISION_TIER = parcel` (or `locality`); **never** claim `structure`.
  This is the one class where "rooftop" is explicitly relaxed to "correct facility footprint."

For each candidate, judge:
- **pass** — the pin meets the rooftop standard for its activity class above: on the building roof
  (building-based), on an **in-facility building roof** (capital-intensive with buildings), or on the
  correct **facility footprint with the right visual signature** (no-building activities). Record
  `SATELLITE_VERDICT = pass` + a one-line note (say which building / signature you confirmed).
- **fail — wrong location** — farmland/water/empty lot, a town/admin centroid, visibly the wrong place, **or
  (for a building-based or building-containing activity) a pin on the runway / open yard / parking / access
  road instead of an in-facility building roof**. If the correct building/structure is visible nearby and
  identifiable, re-pin to it and re-check; otherwise demote to `manual_review` with `REVIEW_REASON =
  satellite_fail:<what you saw>`, and (if it looks like a centroid) route to Phase D. The coordinate has no
  value here.
- **fail — activity mismatch** — the pin sits on a *precise, real structure*, but the building's apparent
  type does **not** match `BUSINESS_ACTIVITY` (e.g. a "manufacturing" row landing on what looks residential,
  like the Inwido row). This is a *different* failure: the coordinate is structure-precise and may well be
  correct (a small plant in a converted building, an office HQ, an ambiguous-from-above roof) or the activity
  tag may be loose — so **retain the coordinate** at `PRECISION_TIER = structure`, set
  `SATELLITE_VERDICT = fail`, `BIZ_SATELLITE_MISMATCH = true`, and hold as `STATUS = manual_review`
  (`REVIEW_REASON = biz_activity_mismatch:<seen> vs <activity>`). It **cannot** be `resolved` (it failed the
  gate), but it is a far more useful row than a blank, and Phase D can adjudicate it. (Wrong-location fails
  do **not** set this flag.)
- **no imagery** — the satellite tiles do not render (solid black / loading placeholder, no terrain or
  structures). Retry once with a longer wait; if still blank, this is **not** a pass and **not** a fail —
  you cannot judge what isn't there. Record `SATELLITE_VERDICT = no_imagery` and set
  `STATUS = manual_review` with `REVIEW_REASON = satellite_no_imagery`. **Never** mark a row `resolved` off
  a tile you could not see. (A non-rendering tile is usually open water / very remote; real facilities over
  land render fine.)

Judge against the **expected structure type**, not just "a building nearby": a pin that is hundreds of
metres off lands on the *wrong* structure and must fail. (This is what separates a correct rooftop from a
near-miss — e.g. an unverified pin ~780 m from a retail store lands on housing and fails, while the true
store sits on a single-storey retail building with its car park.)

**Large / campus POIs — assign an honest tier, and re-pin if needed.** For a multi-building complex
(exhibition centre, port, industrial park, mall, university, large plant), the `!3d!4d` is a *label point*
for the whole place, not a rooftop — it can sit hundreds of metres from any specific building (e.g. NESCO's
entity coordinate is ~260 m from its own addressed Plus Code). At Pass C decide what the facility actually
is:
- **The facility is the whole campus** (the place itself is the asset) → keep `!3d!4d`, set
  `PRECISION_TIER = parcel`. Do not pass it off as structure-grade.
- **The facility is one identifiable building inside the campus** → **re-pin to that building's roof** and
  set `PRECISION_TIER = structure`. To read an exact rooftop coordinate, point at the building on satellite
  and right-click → "What's here?" (or click the bare rooftop): Google drops a point and writes its precise
  `lat,lng` into the card/URL. Record that coordinate with `COORD_SOURCE = satellite_pin`. (Re-pinning is a
  vision action — it needs the vision-capable Pass-C model.)

**Do the re-pin INLINE — do not defer a clearly-identifiable building to `manual_review`.** When the
failed pin is near a structure you can confidently match to the facility (distinctive shape, name/type
match, a single obvious building), perform the right-click → "What's here?" re-pin yourself in this same
pass and resolve the row — that is the expected behaviour, not an escalation. **Only** fall back to
`manual_review` (`REVIEW_REASON = repin_ambiguous`) when you genuinely cannot tell which structure is the
facility (several plausible candidates, or no confirmable match). Never guess a building to avoid the
fallback — the guard is: re-pin when unambiguous, defer when not.

Set `PRECISION_TIER` honestly on every row: `structure` only when the pin is on the target roof; `parcel`
for a campus/label point or addressed-parcel; `locality` for anything coarser.

This is the evaluator step that catches placement errors text cannot (your run's Chow Sang Sang
farmland and the 50 km Hangzhou Bay miss were caught only here). It applies to **all** regions —
Google satellite is WGS-84-aligned globally, so non-China rows are verified too.

**China — extra verification layer (the weakest-data region).** China data is the least reliable: Baidu
often CAPTCHAs even in a real browser, and Google's mainland-China POI points are sparse, frequently sit
tens-to-hundreds of metres off the actual roof, and are occasionally the *wrong* place for an obscure name.
So China rows get more than the standard satellite check:
0. **Native-script querying (at query time).** Baidu matches a **Chinese** query far better than a romanized
   one (Kakao likewise for **Korean**). Translate/transliterate the **geographic** parts (city / district /
   street — standard and safe); for the **entity** (company / facility) look up its **official registered
   native name** (the operator's own site, Baike, or the business registry) rather than literally translating
   it — a plausible-but-wrong translation makes the map confidently match the *wrong* place (the
   identity-vs-plausibility trap). **Skip translation if the source is already native.** Record the native
   string used per field in the `<COL>_NATIVE` columns (§5). This lifts match rate; the satellite gate (below)
   stays the backstop against a wrong match.
1. **Datum-plausibility (deterministic).** After `to_wgs84()` on a China reading, call
   `geo_convert.china_conversion_plausible(raw_lat, raw_lng, out_lat, out_lng)`. If `ran` is `False`
   (shift < 50 m) the GCJ-02/BD-09 → WGS-84 conversion did **not** actually run and the coordinate is offset
   garbage — redo it. Keep the pre-conversion reading in `COORD_RAW` ("lat,lng") so the validator can re-check.
2. **Cross-source identity check.** Satellite confirms the pin is on *a* building, not that it is the *right*
   one — and for an obscure Chinese name Google can return a plausible wrong building that would pass satellite.
   Corroborate identity with a second independent signal — Baidu (if reachable), the business-registry/Baike
   registered address, or the official company page — and require agreement within ~300 m. A China row backed
   by only one source is capped at `parcel`/`med` confidence and noted `single_source` until corroborated.
3. **Expect to re-pin.** Because the Google POI is so often off the roof (e.g. the Deji Plaza POI landed on the
   street ~50 m from the mall), treat the campus re-pin (above) as the norm for China, not the exception — do
   not accept an off-roof parcel pin as `resolved`.

**Gold-standard exemption (`GOLD_EXEMPTION`, default OFF).** Only when explicitly enabled: a row may skip
satellite *iff* it was a Google **named-POI exact match** (facility name ↔ POI name), place type building/
business, address confirmed, coordinate from the POI (not a list-centre). Such rows record
`SATELLITE_VERDICT = exempt_goldstandard`. Default behaviour verifies everything.

---

## §4.7 — Phase D: deep investigation of the residual (OPTIONAL)

Phase D is the marginal-value pass. It runs **only when the residual after Pass C is large enough to
justify the spend** (decide per file at the Pass-C out), and it is the one place the browser's **full**
capability is used. It does **not** loosen verification — every candidate it produces still flows through
the **same Pass C gate (§4)** before it can become `resolved`. D is creative about *finding*; it is not
allowed to lower the bar for *confirming*.

**Input — the typed residual.** D reads `<BASE>_results.jsonl` and works rows by *why* they're stuck, and
the failure type tells D what to do:
- `manual_review` from B (no confirmable match) → **find**: deeper search for the real location.
- `town_centroid` / `centroid_fallback` (§3.5) → **refine**: a coarse centroid that needs the real roof.
- `BIZ_SATELLITE_MISMATCH` (§4) → **adjudicate**: a precise pin whose type didn't match — confirm whether
  it really is the facility.
- `needs_operator_data` from B.1 (enrichment found no public *address*) → **re-attempt — do NOT skip these**.
  B.1 only tried address/POI text enrichment, but D has techniques that need **no street address**: the
  **landmark visual-signature sub-mode** (a port / mine / dam / plant / refinery resolvable from a district
  anchor with no address at all), **Street View signage**, and the **deep registry / HQ-trap rung**. Run
  those before re-confirming the label. `needs_operator_data` means "no public *address*," not "unfindable by
  any means" — re-mark it `needs_operator_data` only if D's address-independent toolkit *also* fails.

**Techniques (the additive capability over B):**
1. **Street View / road-view signage** — read the business name off the storefront/building to confirm
   identity. Region-aware: Google Street View globally; Kakao/Naver road-view for Korea; Baidu/Tencent for
   mainland China (Google has none there). This is D's most powerful tool and cracks the ambiguous-identity
   and activity-mismatch cases.
2. **Open web + image search** — beyond B's fixed rungs: news, local directories (Dianping / Naver Place),
   deeper operator-site pages, image search for the facility's appearance.
3. **Multi-signal disambiguation** — for ambiguous candidates, score each against several independent
   signals (phone, stated address, photos, registry, signage) and pick the one corroborated by the most.
4. **Cross-field verification** — match the facility's phone / postal code / building name against the
   candidate's listing.
5. **Operator site + business registry (the HQ-trap breaker).** When a row is stuck on a corporate/HQ
   address (the classic trap: a POI search snaps several distinct facilities to one head-office pin), go to
   the **operator's own site / store-/plant-locator** and a **business registry** for the legal entity, and
   separate the **registered (HQ) address from the operating-facility address** — the real site is usually
   NOT the HQ. This rung rescues brand/HQ-trap clusters that map search alone cannot. If, after it, the
   facility genuinely has no public building-level address (input is city-/port-/region-only and the
   operator publishes nothing), classify it **`needs_operator_data`** — an honest "needs an issuer-supplied
   address," distinct from `not_found`.

**Landmark-resolution sub-mode (capital-intensive, visually-distinctive facilities).** A large class of
facilities is identified by its *physical footprint*, not a street address — for these the address was
never the right key. When the facility is a **port, airport, marine/LNG terminal, mine, quarry, dam, hydro/
thermal/nuclear power plant, solar or wind farm, refinery, smelter, cement/steel works, large rail yard, or
reservoir**, resolve by visual signature instead of address:
1. Establish the **type** (from `BUSINESS_ACTIVITY`/`FACILITY_NAME`) and the most specific **place** you
   have (district / county / river / coast).
2. Find the **named landmark** via sources beyond Maps POI — OpenStreetMap, Wikipedia/Wikimapia, government
   or sector infrastructure registries (power-plant / port / mine / airport databases), the operator's
   project pages — to get a candidate location in that district.
3. **Confirm on satellite by signature** (this is the gate, not an address): center the satellite view on
   the candidate (zoom out to ~600 m–2 km to take in a large site), confirm the URL coordinate, then verify
   the **visual signature** matches the type — dam + reservoir + powerhouse for hydro; runways for an
   airport; cranes + quays + container yards for a port; headframes / pits / tailings for a mine; stacks +
   turbine hall for thermal; panel arrays for solar; turbine rows for wind. **Then apply the §4 rooftop
   standard for placement:** if the complex CONTAINS buildings (airport, port, power plant, refinery,
   warehouse/terminal, plant), pin the **roof of an in-facility building** — terminal, turbine/control/admin
   building, or warehouse roof — **not** the runway, switchyard, quay, or open yard (`PRECISION_TIER=
   structure`). Only for genuinely building-less facilities (mine, quarry, field, solar/wind farm, reservoir)
   is the representative footprint point the target (`PRECISION_TIER=parcel`; no roof expected). Record
   `COORD_SOURCE=satellite_pin`, `EVIDENCE_SOURCE=osm_wiki_registry`, and a `SATELLITE_NOTE` naming the
   signature and which building you pinned. **Three hard guards — ALL must hold, else leave `manual_review` `REVIEW_REASON=
   landmark_ambiguous`:** (a) the **type is confirmable** from the inputs; (b) the satellite **signature is
   unambiguous** for that type (a dam / runway / quay is — a generic shed is **not**; if you can't tell by
   eye, don't accept); (c) **uniqueness** — plausibly only one such facility of that type in the stated
   district (if several exist and you can't tell which is this issuer's, do not guess). A confirmed landmark
   row → `resolved_pending_qa` → the **same Pass C gate**.

**Cost controls (mandatory — D is the expensive pass):**
1. **Pre-D triage.** Skip only rows with **zero usable signal for *any* D technique** — no online footprint
   at all, no identifiable type *and* no place, broken/contradictory input. **Do not blanket-skip
   `needs_operator_data`:** a `needs_operator_data` row that has a resolvable *type + place* (→ landmark
   signature) or an un-mined `RELEVANT_URL` / registry is a valid D input, because D's landmark / Street
   View / registry techniques don't need the street address B.1 couldn't find. Triage out the genuinely
   zero-signal rows only. This is still the biggest saver — it just no longer discards recoverable
   address-less facilities.
2. **Per-row budget cap.** A fixed op/token ceiling per row; if D can't crack it within budget, leave it
   `manual_review` and move on. Bounds the worst case so no single row spirals.
3. **Street View selectively.** It's the costly technique and only helps where there's signage (urban/
   retail). Lead with cheaper open-search/image work; escalate to Street View only when needed; skip it for
   remote industrial (often no coverage anyway).
4. **Optional, per file.** D is not run on everything. After A→B→C, look at the residual size and resolved
   %, and decide whether D's incremental yield justifies the incremental spend on *this* file.

**Output.** A D candidate → `resolved_pending_qa` (then Pass C, exactly as Pass B candidates). What D
can't crack stays honestly flagged, now with sharper reasons: **`needs_operator_data`** (recoverable only
with an issuer-supplied address/coordinate — city/port/region-only input, nothing public), **`landmark_
ambiguous`** (capital-intensive type but a guard failed — usually >1 candidate in-district), or
`not_found`/`manual_review` as before. A `needs_operator_data` that **survives D** has now been through both
B.1's enrichment *and* D's address-independent techniques (landmark / Street View / registry) — genuinely
exhausted on public data, not merely un-enriched. **D shrinks the residual, it does not eliminate it**;
expect a partial yield, and the `needs_operator_data` list is itself a deliverable — hand it back to the data
owners. Then take the **out**: validate + assemble.

---

## §4.8 — Satellite-Direct mode (alternate entry; QA / precision-upgrade / landmark)

A standalone way to run **Pass C as the entry point** — go straight to satellite and read the rooftop
coordinate there — for the cases where that is the *right* tool. It is **not** a general replacement for
A→B: Pass C is a *verification* step and the satellite camera needs something to point at, so this mode
applies to two row types only:

1. **Rows that already carry a coordinate** (a prior API/geocode pass, or already-`resolved` rows being
   re-QA'd). Navigate to the existing coordinate, confirm or refute the pin (§4), and **upgrade precision**
   by right-clicking the actual roof → "What's here?" to pin the structure (`COORD_SOURCE=satellite_pin`,
   `PRECISION_TIER=structure`). This is the **coordinate-QA / precision-upgrade** use — the natural mode for
   "re-verify a batch of existing coordinates."
2. **Visually-distinctive facilities** (the §4.7 landmark list), anchoring on a coarse place (district) and
   resolving by **visual signature** — identical to the landmark-resolution sub-mode, with the same three
   guards.

**Where it does NOT work — fall back to A/B:** a **coordinate-less generic facility** (office, store,
small/unmarked warehouse) with no signature. Satellite has nothing to center on and no way to pick that
rooftop out by eye; forcing a pin there would be a guess. Such a row routes to Pass A/B to obtain an anchor
first — Satellite-Direct does not attempt it.

**Discipline is identical to §4 and §6:** claim one tab, the deterministic `…/@<lat>,<lng>,150m/data=!3m1!1e3`
URL, **re-read the tab URL to confirm the coordinate before the screenshot**, one screenshot, judge against
`BUSINESS_ACTIVITY`/`FACILITY_NAME`. The bar for `resolved` is unchanged — a confirmed structure on
satellite. China rows → Baidu/Tencent + datum conversion. This mode changes the *entry point*, never the
*confirmation standard*.

---

## §5 — Per-row record (`results.jsonl`) and output columns

One JSON object per `FACILITY_ID`, appended at each checkpoint. Same fields become columns in the
final workbook (the evidence/proof you asked for travels with the data):

```
{ "FACILITY_ID", "LATITUDE", "LONGITUDE",
  "COORD_SOURCE", "COORD_DATUM",            // address_on_maps | poi_constructed | baidu | kakao | plus_code | satellite_pin ; datum always WGS84
  "COORD_RAW",                               // CHINA only: raw "<lat>,<lng>" read off the map BEFORE datum conversion (audit)
  "PRECISION_TIER",                          // structure (building roof: standalone OR in-facility bldg) | parcel (facility site/complex, no single roof; incl. building-less mine/field/solar/wind) | locality (area centroid — not resolvable)
  "MATCH_CONFIDENCE",                        // high | med | low
  "RESOLUTION_QUERY",                        // the exact query/address that produced the pin
  "EVIDENCE_SOURCE",                         // address_on_maps | poi_constructed | relevant_url | web_search | filing | registry | operator_site | osm_wiki_registry
  "MATCH_PLACE_NAME", "MATCH_PLACE_ID",
  "LADDER_TRIED",                            // rungs attempted in Pass B / B.1, e.g. "url;native;registry;b1_enrich"
  "SATELLITE_VERDICT",                       // pass | fail | no_imagery | exempt_goldstandard | not_checked
  "SATELLITE_NOTE",
  "BIZ_SATELLITE_MISMATCH",                  // C: true = precise structure but type != BUSINESS_ACTIVITY (coordinate RETAINED, structure tier, manual_review)
  "STATUS",                                  // resolved | resolved_pending_qa | manual_review | not_found
  "REVIEW_REASON",                           // incl. town_centroid | centroid_fallback:<tier> | biz_activity_mismatch:... | satellite_fail:... | satellite_no_imagery | repin_ambiguous | needs_operator_data | landmark_ambiguous
  "IS_CENTROID_FALLBACK", "CENTROID_TIER",   // §3.5 clustering sweep (centroid_fallback.py): reuse across unrelated entities + tier (EXACT|R4|R3|BROAD)
  "SESSION_N",                               // which session last wrote this row
  "FACILITY_ADDRESS_NATIVE", "FACILITY_NAME_NATIVE", "CITY_NATIVE", "STATE_NATIVE", "ISSUER_NAME_NATIVE" }
                                             // native string actually used per field (CN→Chinese, KR→Korean); blank if source already native / non-CJK
```

Status is a state machine: `(new) → resolved_pending_qa → resolved` via Pass C, or `→ manual_review /
not_found` at any point with a reason. Only Pass C writes `resolved`.

---

## §6 — Running a pass: autonomous (Cursor) vs. session-handoff (Cowork / Claude chat)

How a pass *runs* depends on the environment's browser and context limits. The four passes, the resume
logic, and the checkpoint file are identical across environments; only whether one pass finishes in a
single autonomous loop or across handed-off sessions differs.

- **Resume (both environments):** before working, read `<BASE>_results.jsonl` and skip every
  `FACILITY_ID` already terminal for this pass. Re-running is always safe and idempotent (last-write-wins
  on `FACILITY_ID`).
- **Never silently degrade the browser path.** If the browser your environment is configured for becomes
  unavailable mid-run, do **not** quietly switch to a different, less-reliable mechanism that could
  misattribute a coordinate to the wrong row — retry the primary a bounded number of times, then **stop and
  report** which rows are done. A clean halt the operator can resume beats a silent path-switch that risks
  wrong pins. (Environment specifics: the runner file / `AGENTS.md`.)
- **Claim your browser tab first (both; every browser pass — A, B, C, D).** Your *first* browser action is
  to open **one** tab and read `browser_tabs` to record its id — that id is **your** working tab ("your
  browser") for the entire run. **Every** `navigate` and `screenshot` afterwards targets only that id;
  never act on a tab you didn't open, and never screenshot the merely-*focused* tab. The browser surface is
  shared (other tabs, and any concurrent agent/subagent can move one), so this claim is what keeps your
  actions on your own page. After each navigate, re-read that tab's URL and confirm it before trusting any
  screenshot (the §4 guard).
- **Checkpoint (both) — batch the append to conserve tool calls.** Buffer outcomes in memory and write
  them to `<BASE>_results.jsonl` in **one append per `CHECKPOINT_EVERY` rows (default 25)**, *not* per row.
  In Cursor each individual append is a tool call, and per-row appends burn the per-turn tool-call budget
  (below) far faster, triggering more "Continue" stops. The file is the only thing that must survive a
  crash; because re-running is idempotent, a kill costs at most one interval of *redone* work, never data
  loss. Appending never interrupts the run.

**Cursor — run the WHOLE pass autonomously, in one continuous loop (no handoff).** Composer drives a real
browser, so **do NOT stop to ask the user to "continue" on your own, and do NOT hand off to a next
session** — that model does not apply here. Emit a one-line progress update at a checkpoint if useful, but
proceed straight to the next rows. Recover the browser yourself on a stall/rate-limit
(`select_browser`/`switch_browser`) and resume.

> **Platform limit you cannot override (and how to live with it):** Cursor's *standard* Agent mode stops
> the agent after **~25 tool calls per interaction** and shows a **"Continue"** prompt — a hard runtime
> safeguard, **not** this skill and not a failure. On a long pass it *will* fire periodically (Pass C is
> ~2–3 tool calls/row, so ~8–12 rows per turn in standard mode). When it does: resuming is **idempotent** —
> re-sending "continue", or re-running the same trigger, makes you re-read the jsonl, skip terminal rows,
> and continue exactly where you left off, with no double-writes. To **minimise** these stops: (1) batch
> appends as above; (2) the user enables **MAX mode**, which raises the cap to **~200 tool calls/interaction**
> (≈8× fewer stops). Genuinely zero-touch execution over thousands of rows is **not** achievable in
> Cursor's single-agent model — the realistic target is *as few checkpoints as possible, each trivially
> resumed*, which the idempotent resume guarantees.

**Cowork / Claude chat — use the session + handoff structure.** The sandbox browser connector freezes
after ~12–15 consecutive ops (built-in waits do not reset it) and context is tighter, so a long pass is
split across sessions. Work a session's worth of rows, checkpoint, then write
`<BASE>_HANDOFF_n<SESSION_N>.md` (run `generate_handoff.py`) — counts by status, clusters done, blockers/
environment notes, KB entries appended, and what the next session should pick up. The next session resumes
from the jsonl (per **Resume** above) and continues. Here the handoff **is** the legitimate hand-back point.

- **Combine (both):** after the final pass, validate and assemble (§2, §10).

---

## §7 — KB protocol (append-only, deprecate-and-point)

Read only the region/topic-relevant section of `KB_PATH` per cluster (progressive disclosure — do not
load the whole KB per row). When you learn something durable (a working registry pattern, a new dead
tool, a region quirk):
- **Append** a dated, structured entry: `### <date> · <region/topic> · <short title>` then the learning.
- If it **supersedes** an existing entry, prepend to the *old* entry a line:
  `> ⚠️ SUPERSEDED <date> → see "<new title>" below.` and add a back-reference in the new entry. Never
  edit the old entry's body or delete it.
- On read, treat any entry marked SUPERSEDED as historical; use the latest.
- Note in the handoff which entries you appended/superseded. (Requires Filesystem **write** tools enabled.)

---

## §8 — Operating constraints (verified; plan around these)

- **Baidu Maps — environment-dependent.** In the **Claude/Cowork sandbox** Baidu is effectively unusable
  (search JSON is reCAPTCHA-gated, satellite tiles render black) → there, resolve China via native-language
  text search + registry, then confirm on Google satellite, and **do not spin retrying Baidu**. In a
  **real-browser runner (e.g. Cursor)** Baidu *is* usable for the China coordinate (read BD-09 → convert to
  WGS-84 via `geo_convert`), still validated on Google satellite. The runner file (`AGENTS.md` / Claude
  `README`) states which applies in your environment.
- **Amap (amap.com):** blocked by org policy. Do not use.
- **Google satellite over China is WGS-84-aligned** — the one China tool that works; use it as the
  authoritative pin check for datum-converted coordinates.
- **`/maps/search/<query>`**, never `/maps/place/<address>` (the latter redirects to Mumbai).
- **Read coordinates from the URL/Tab Context** (`!3d!4d`); the in-page href may be cookie-blocked.
- **`web_fetch` returns empty on SPA/client-rendered pages** — fall back to web search.
- **Browser pacing ≤4–5 ops/batch** where the connector is fragile; auto-recover via `select_browser`/`switch_browser` and resume before escalating. How a pass continues past a connector freeze is environment-specific (**§6**): autonomous loop in Cursor, session handoff in Cowork.
- See `KB_PATH` for the per-region technical detail (address formats, brand aliases, known clusters).

---

## §8.5 — Self-improvement loop (OPTIONAL, manually gated)

The skill can get better at *your* universe over time by learning from its own runs — but only the
**"how to find"** layer (the KB, `KNOWN_CENTROIDS`, query heuristics) may evolve. The **"how to verify"**
layer — the §0 contract and the Pass C satellite gate — is **frozen** and out of scope. Self-improvement
sharpens search; it never lowers the verification bar. This is parameter-free experiential learning
(reflect on the run's own trajectory → distil durable lessons), and it is **human-gated by construction**:
the loop only *proposes*; a person reviews and merges.

**The loop (run after a pass or a finished file, when it's worth it):**
1. **Mine (deterministic).** `python scripts/self_improve.py <RESULTS_JSONL or results/> --out PROPOSED_UPDATES.md`
   produces an outcome funnel, the top `REVIEW_REASON`s (where the ladder is weakest), a COORD_SOURCE
   reliability table (which sources pass/fail the satellite gate), Pass-B ladder effectiveness (which final
   rung reaches a candidate), a BIZ-mismatch tally, and **candidate centroid fingerprints** — coordinates
   that were centroid-flagged or reused across unrelated rows and are not already within 200 m of a known
   one, formatted as ready-to-paste `KNOWN_CENTROIDS` lines.
2. **Reflect (optional, agent).** Read the run + `PROPOSED_UPDATES.md` and append concrete, actionable
   prose lessons to its "Agent reflection" section — a newly seen trap, a query pattern that cracked a
   tricky issuer type, a regional quirk. Keep them specific; they are KB *candidates*, not rules.
3. **Gate + merge (human).** A person reviews `PROPOSED_UPDATES.md`. Confirmed centroid fingerprints get
   pasted into `geo_convert.KNOWN_CENTROIDS`; durable lessons get added to the KB per §7
   (append-only, deprecate-and-point); heuristic ideas may reorder the §3 ladder. **Nothing is applied
   automatically**, and a version bump records what changed.

**Hard limits (the same spirit as §0):** `self_improve.py` and any reflection step must **never** edit the
§0 contract, the satellite gate, `validate_results.py`, or `assemble_results.py`; never auto-write the KB,
`geo_convert`, or `KNOWN_CENTROIDS`; and never optimise a number the run also reports (no relaxing
standards to make "% resolved" look better). Keep proposals **selective** — a lesson worth keeping is one
that would have changed a real outcome, not noise from one or two rows. Prune the KB as models improve;
the minimal set that works is the goal.

## §9 — Throughput: route by cluster, split by cost

- **Triage then route by issuer/region.** One company's facility-list page or one registry pattern
  resolves a whole cluster at once — far cheaper than row-by-row (Sankyu, Jinbi, Shin Kong, REYSAS, etc.).
- **Split work by cost.** Pass A and the text rungs of Pass B are image-light → large batches / many rows
  per session. Pass C (satellite) is image-bound → budget ~1 screenshot/row, ~100 rows per session, and
  run it as its own sessions. This keeps the cheap bulk fast without ever weakening the satellite gate.
- Keep per-row narration to one terse line; let `results.jsonl` carry state, not the chat transcript.

---

## §10 — Quality gate (no degradation, measured not asserted)

`validate_results.py` enforces §0 on the assembled output (fails the build if any `resolved` row lacks
evidence, any processed row is blank, or any coordinate is out of its country bbox). Separately, after any
change to this skill, score it against the 100-row ground-truth set with `compare_to_gt.py` and require
**same-or-better** median, ≤250 m %, and false-`high` count before adopting the change. Quality is proven
by the eval, not assumed.

---

### Scripts
- `scripts/geo_convert.py` — datum conversion (GCJ-02/BD-09 → WGS-84), bbox/city validation, triage,
  Plus Code decode, and the live centroid helpers (`is_centroid_place_type`, `known_centroid_match`,
  `KNOWN_CENTROIDS`). Used by all passes.
- `scripts/query_builder.py` — Pass B: proposes ranked candidate queries per row from name/address/
  RELEVANT_URL/native-language/registry templates; writes `RESOLUTION_QUERY` candidates.
- `scripts/centroid_fallback.py` — §3.5 dataset-level centroid sweep (4-tier clustering + co-location
  safety valve + same-issuer-dupe); flags `IS_CENTROID_FALLBACK`/`CENTROID_TIER`. Run over a large input
  batch or the assembled output.
- `scripts/validate_results.py` — the §0 gate + evidence-column population/check.
- `scripts/assemble_results.py` — `results.jsonl` → `<BASE>_rooftop_geocoded.xlsx` (evidence columns,
  amber/red colouring).
- `scripts/generate_handoff.py` — writes `<BASE>_HANDOFF_n<N>.md` from `results.jsonl` + input.
- `scripts/self_improve.py` — §8.5 manually-gated reflection: mines a completed run's `results.jsonl`
  into `PROPOSED_UPDATES.md` (outcome funnel, top reasons, COORD_SOURCE reliability, ladder effectiveness,
  candidate centroid fingerprints). **Proposes only — never auto-applies; out of the verification path.**
- `scripts/split_for_lanes.py` — splits an input into `<BASE>_cn.csv` (mainland China, `COUNTRY_ISO3==CHN`
  exact) + issuer-balanced `<BASE>_w1.csv`/`_w2.csv` non-China halves for a region-routing parallel run.
- `scripts/merge_lanes.py` — recombines the per-lane `results.jsonl` files by `FACILITY_ID`, runs the §0
  validator, and assembles the final workbook in one step.
