# AGENTS.md — Rooftop Geocoder · Cursor Agent Panel runner (v0.6.23)

Cursor execution layer over the skill. **`SKILL.md` is authoritative** for per-row resolution logic — the
§0 CONTRACT, the A→B→B.1→C→(D) passes, the ladder, the evidence schema, the precision/confidence rules, and
the activity-class rooftop standard. This file adds only what's specific to running it from Cursor's Agent
Panel: `@Browser`, the regional maps (Baidu / Kakao) validated on Google, browser timeout/blocking handling,
cost/time efficiency, and the file/paths convention. **One file, one agent, one `results.jsonl`** — there is
no sharding or parallel-window machinery. Do not weaken any §0 gate.

## Read first
`SKILL.md`, `coord_kb.md` (region detail; read the relevant section per cluster), and `scripts/`
(`geo_convert`, `query_builder`, `validate_results`, `assemble_results`, `generate_handoff`). Follow the §0
CONTRACT exactly: **no row is `resolved` without a coordinate, a `RESOLUTION_QUERY`, an `EVIDENCE_SOURCE`,
and `SATELLITE_VERDICT = pass`.**

## Model routing (per phase)
- **Passes A, B, B.1, and combine → Composer 2.5** (fast, cheap, built for the browser/terminal agent loop;
  confirmed reading `!3d!4d` from the full URL on a clean Pass-A row). This is the bulk of the work, so
  routing it here is the main cost lever.
- **Pass C (satellite) → a vision-capable model (Claude Sonnet).** C requires interpreting a satellite image
  (is the pin on the right structure?); Composer is coding-specialized on a text base and its satellite
  vision is unverified — a non-vision model would silently rubber-stamp pins. Keep C on Sonnet **until** you
  run the one test: hand Composer a single satellite screenshot at a known site and confirm it judges the
  structure correctly. If it passes, you may move C to Composer too.
- Do not use **Auto**. Because Pass C is already its own session, switching the model for C is a clean
  per-phase swap, not a redesign.

## Browser
- **Claim one tab at the start and never leave it.** Your first browser action each run: open one tab, read
  `browser_tabs`, record its id — that is **your** tab for the whole pass. Every `navigate` and `screenshot`
  targets that id only; never screenshot the merely-focused tab, never touch a tab you didn't open. The
  browser surface is shared (other tabs can take focus), so this keeps you on your own page; after each
  navigate, re-read the tab's URL and confirm it before trusting a screenshot (the §4 guard turns any
  mix-up into a detectable retry, never a silent wrong coordinate).
- Drive maps with `@Browser`. **Read minimal text, not the whole DOM.** Get the coordinate from the
  **complete URL** (`!3d<lat>!4d<lng>` in the `data=` segment, after `@<viewport>,<zoom>` — not the
  truncated address bar, never the `@<viewport>` camera) and the place name from **`document.title`** (which
  also runs the identity / trap check). **Do not take a full-page snapshot by default** — the Maps DOM is
  the biggest per-row token cost; snapshot **only** to disambiguate a `/maps/search/` list. **Stop as soon
  as the URL gives the coordinate** (redirect to `/maps/place/…!3d!4d`). If the card shows only a Plus Code,
  decode it (`geo_convert`) → `COORD_SOURCE=plus_code`. No coordinate at all → `manual_review`, never
  `resolved_pending_qa`.
- **Satellite = the single screenshot, via a deterministic URL** (do NOT touch the Layers panel — that
  fumbling is the main token leak): navigate straight to
  `https://www.google.com/maps/@<lat>,<lng>,150m/data=!3m1!1e3`
  (`!3m1!1e3` forces satellite; `150m` ≈ rooftop zoom). Then take **one full-fidelity** screenshot to confirm
  the structure (never downscale it — it is the quality gate).

## Regional maps — native coordinate, Google verification
The coordinate **source** depends on region; the **verification** is always Google satellite (WGS-84-aligned).
- **Mainland China** (route by **`COUNTRY_ISO3` == `CHN` exact** — never `FACILITY_REGION` containing "China",
  as Taiwan's region is "Taiwan (Province of China)"; **HKG / MAC / TWN have their own ISO3 and are NOT routed
  here**, they take the Google path): coordinate from **Baidu Maps**, queried in **Chinese** (see
  native-script discipline below + SKILL.md §4). Baidu is **BD-09** → `geo_convert.to_wgs84(lat, lng, "BD09")`.
  Set `COORD_SOURCE=baidu`. Run this lane via **external Chrome over CDP** (next section), not the embedded
  browser — embedded Baidu CAPTCHAs.
- **Korea**: coordinate from **Kakao Maps**, queried in **Korean**. Kakao displays WGS-84 — no conversion. Set
  `COORD_SOURCE=kakao`. The embedded browser handles Kakao fine.
- **Everywhere else** (incl. **HKG / MAC / TWN**): Google Maps as in SKILL.md (`COORD_SOURCE=address_on_maps`
  / `poi_constructed`).
- **Native-script querying:** for China and Korea, build the query in the local script — translate/transliterate
  the **geographic** parts, but **look up the official registered native name** for the company/facility (do
  not blind-translate it), and skip translation if the source is already native (SKILL.md §4). Record the
  native string used per field in the `<COL>_NATIVE` columns.
- **Then, for every row regardless of source**, run **Pass C**: open the deterministic Google **satellite**
  URL at the (WGS-84) coordinate and confirm the pin sits on a structure matching the facility and its
  activity class (§4). A `SATELLITE_VERDICT=pass` is exactly how a Baidu/Kakao coordinate is *validated and
  marked against Google*. Only a satellite pass makes a row `resolved`.
- **If Baidu/Kakao is blocked** (CAPTCHA/timeout) for a row: fall back to Google with the native-language
  query + (China-only) registry rung, then satellite. Don't burn ops retrying a blocked native map.

## Browser lanes (parallel runs) — embedded discipline
A parallel run is **2 embedded lanes (non-China) + 1 CDP lane (mainland China)** (guide: "Parallel +
region-routing run"). The non-China lanes **must** use the **embedded** browser, never CDP — embedded is
clean and single-tab, whereas the CDP path has shown wrong-tab reads (a coordinate misattributed to the
wrong row). Rules:
- **Launch each lane's window with its own Cursor profile** so each gets its own embedded daemon socket:
  `cursor --profile lane1 <w1-folder>` and `cursor --profile lane2 <w2-folder>`. Cursor's embedded daemon
  binds a fixed socket, so without separate profiles a 2nd instance can hit `EACCES` and only one lane gets
  an embedded browser.
- **Sequence the launches:** bring up the two embedded lanes first and confirm each has a working embedded
  tab (`@Browser` returns a map) **before** starting the China/CDP Chrome — a CDP Chrome launching
  concurrently can starve the embedded slot.
- **Insist on embedded; never silently fall to CDP.** If a non-China lane can't get an embedded browser
  (`EACCES`), retry the embedded slot a few times; if it still fails, **STOP and report** ("embedded
  unavailable — N rows done, resume after freeing a slot"). Do **not** switch that lane to external Chrome:
  the CDP tab-confusion is a data-integrity risk, and a clean resumable halt beats wrong pins.

## China lane (Cursor) — external Chrome over CDP, launched directly
The embedded browser **CAPTCHAs on Baidu** and caps at ~2 instances on Windows (the bundled browse daemon
can't bind a 2nd/3rd Unix socket — `EACCES`). Run mainland-China rows in a **dedicated lane on external Chrome
driven over CDP**, and **go straight to CDP — do NOT attempt the embedded daemon first** (it only wastes ops
failing on the socket):
1. Launch Chrome once with a **fixed** debug port and its own profile, e.g.
   `chrome.exe --remote-debugging-port=9333 --user-data-dir="%TEMP%\rgc-cn-profile"` — deliberate and
   reproducible, not an agent-improvised recovery. Add `--no-first-run --no-default-browser-check` to that
   launch; if a managed-device "Sign in to Chrome" prompt appears, click **"Stay signed out"** once (a
   pre-seeded profile avoids it on later runs).
2. Drive it through the browse CLI over **`--ws`** (CDP) at that port.
3. **`&` in Baidu URLs splits inside Cursor's `browse.cmd` itself** (not just PowerShell), so quoting alone
   does not fix it — drive navigation by calling **node / the CDP `--ws` endpoint directly** (bypassing
   `browse.cmd`), or URL-encode `&` as `%26`, or use the Baidu search box instead of a query-string URL.
4. Query Baidu in **Chinese**; read BD-09 → `to_wgs84`; then the standard Google **satellite** check. If Baidu
   CAPTCHAs at volume, fall back to Google + GCJ-02→WGS-84 for that row and keep going. A **warm Chrome
   profile** (one that has browsed Baidu before) is less likely to CAPTCHA.
5. **Hard tab-discipline (the CDP path's main risk).** Claim **one** tab and reuse it for every row — never
   open a tab per row. **Re-read the tab URL with `eval` immediately before extracting** each row's
   coordinate; if it does not match the row you navigated for, **abort that row and retry** — never record a
   coordinate from a tab you cannot confirm (CDP navigation has landed on the wrong tab in testing).

This lane handles **only** mainland-China rows — a disjoint slice — so it never collides with the embedded
lanes. Use `scripts/split_for_lanes.py` to carve the input into `_cn` + `_w1`/`_w2` and `scripts/merge_lanes.py`
to recombine; see the guide's "Parallel + region-routing run" for the full 2-embedded-plus-1-China setup.

## Attributes to use in the query
Pass A uses `FACILITY_ADDRESS` first. For Pass B, `query_builder.py` builds ranked candidates from
`FACILITY_NAME` + `COMPANY_NAME`/`ISSUER_NAME` + city/region + brand-from-`RELEVANT_URL`, rendered into local
script for CJK rows. Use the company/issuer name to disambiguate same-named facilities. Pass B.1 (§3.6) goes
further for thin-input rows: read the `RELEVANT_URL` and web-search to synthesise a more specific
address/POI, then re-resolve.

## Browser timeout / blocking handling
- Pace **≤4–5 browser ops per batch**, brief wait between (the page/connector can stall on long runs).
  Batching is internal pacing — **you self-resume across batches; you never end your turn to ask the user to
  continue** (SKILL.md §6).
- **Timeout:** retry once and re-navigate; if still failing, mark the row `manual_review`
  (`REVIEW_REASON=browser_timeout`) and move on — never spin.
- **Google rate-limit / CAPTCHA:** pause ~60s, then **resume the loop yourself**; if persistent, checkpoint
  and continue on the remaining rows — do not hand control back. (Don't run several browsers from one IP at
  once; a single agent on one IP is the safe shape.)
- **Baidu CAPTCHA:** fall back to Google for that row (above) rather than retrying Baidu.

## Cost / time efficiency (no quality loss)
- Coordinate from the **URL text**, never a screenshot. **Exactly one screenshot per row** (the satellite check).
- **Direct satellite URL** — no Layers-panel fumbling (this alone removes most of the wasted tokens).
- Keep per-row narration to **one terse line**; let `results.jsonl` carry state, not the transcript.
- **Route by issuer** where rows cluster — one company-page/list resolves many rows.
- Satellite is the only image cost and it is mandatory — that is the quality floor; everything else is text.

## State / resume (single file)
- **Each phase runs FULLY AUTONOMOUSLY in Cursor, start to finish, in one continuous loop. There is NO
  session handoff here and NO stopping to ask the user to "continue" — the session/handoff model in
  SKILL.md §6 is for the Cowork / Claude-chat sandbox only, not Cursor.** Emit a one-line progress update at
  a checkpoint if useful, then proceed straight to the next rows without waiting. End the turn only when the
  pass is complete for every in-scope row, or on an unrecoverable failure (checkpoint first).
- **Tool-call cap (platform, not skill):** Cursor *standard* Agent mode stops after ~25 tool calls per
  interaction and shows "Continue" — this is NOT a handoff and NOT a failure; it is a hard runtime limit. It
  will fire periodically on long passes. **Buffer outcomes and append once per ~25 rows** (per-row appends
  burn the budget faster). When the cap fires, resuming is idempotent: re-running the trigger / "continue"
  skips terminal rows and continues with no double-writes. **MAX mode** raises the cap to ~200
  tool calls/interaction (≈8× fewer stops). Zero-touch over thousands of rows is not achievable in Cursor's
  single-agent model; the goal is fewest checkpoints, each trivially resumed.
- **Resume** from `<BASE>_results.jsonl` (skip terminal rows for the pass); append/checkpoint **every 25
  rows** — appending is the checkpoint, it does not pause the loop; carry `FACILITY_ID` programmatically
  (never by row position).
- `generate_handoff.py` may be run at the end of a pass as a *record* of what was done — it is not a stop
  point and never hands control back mid-pass.
- Final: `validate_results.py` (must pass the §0 gate), then `assemble_results.py` →
  `results/<BASE>_rooftop_geocoded.xlsx`.

## The chain (per SKILL.md; regional sourcing applied)
**A → B → B.1 → C → (out) → optional D → C again → (out).** End every pass by printing a NEXT STEPS block
(SKILL.md §2.1).
- **A** — existing `FACILITY_ADDRESS` → Google (or **Baidu** for CN / **Kakao** for KR) → reason to the pin
  → candidate (`resolved_pending_qa`) or `manual_review`. A `town_centroid` here is NOT terminal — it is a
  mandatory Pass B input.
- **B** — each `manual_review` → `query_builder` candidates (name + company + region + brand, native-rendered)
  → reason; then `RELEVANT_URL`/filing; then China-only registry → candidate or `manual_review`/`not_found`
  (record `LADDER_TRIED`). `town_centroid`/`centroid_fallback` rows from A are PRIMARY B inputs.
- **B.1** (§3.6) — for rows still `manual_review` (too thin to find the building): read `RELEVANT_URL` +
  web-search + synthesise the most specific address/POI, then re-resolve the Pass-A way. A more specific
  candidate → `resolved_pending_qa`; nothing more specific found → `manual_review`/`needs_operator_data`
  (a hand-off to D, not a dead end).
- **C** — every candidate → deterministic Google **satellite** URL → judge against the activity-class
  rooftop standard (§4): building roof / in-facility building roof / no-building footprint. `pass`=`resolved`;
  wrong-location (incl. runway/yard/parking of a building-containing facility) → re-pin or `manual_review`;
  this also validates Baidu/Kakao coordinates against Google. **Only C writes `resolved`.**
- **D** (SKILL.md §4.7, optional) — Street View / road-view signage + open web/image search + multi-signal
  disambiguation + the HQ-trap registry rung + the landmark visual-signature sub-mode, on the typed residual
  (find / adjudicate / refine), and it **re-attempts `needs_operator_data`** (D's techniques need no street
  address). Mandatory cost controls: pre-D triage (skip only zero-signal rows), per-row budget, selective
  Street View, run per-file. Every D candidate still clears the **same Pass C gate** — run C again on D's
  output before validate + assemble.

## Centroid routing, mismatch, and the two outs
- **Centroid check (every candidate, Pass A & B — SKILL.md §3.5), three layers:** (1)
  `geo_convert.is_centroid_place_type(...)`; (2) `geo_convert.known_centroid_match(lat,lng)`; (3)
  `scripts/centroid_fallback.py` as a dataset-level sweep over a large input / the assembled output. A flag →
  keep the coordinate, `STATUS=manual_review`, `REVIEW_REASON=town_centroid`/`centroid_fallback:<tier>`,
  **route to Pass B first** (then Phase D only for rows B can't resolve to a structure) — never promote a
  centroid. Pass C is the backstop.
- **Pass C `BIZ_SATELLITE_MISMATCH`:** if the pin is a precise structure but its type ≠ `BUSINESS_ACTIVITY`,
  set `BIZ_SATELLITE_MISMATCH=true`, **retain the coordinate** at `structure` tier, hold `manual_review`
  (adjudicate in D). Distinct from a wrong-location `satellite_fail` (coordinate discarded).
  `assemble_results.py` colours these amber; wrong-location/centroid rows red.
- **Two outs.** Take the out at the end of Pass C (validate + assemble; ship `resolved`, leave the residual
  flagged), and again after D→C. Run D only if the residual size justifies the spend.

## Satellite-Direct mode (§4.8, alternate entry)
For rows that already carry a coordinate (QA / precision-upgrade — right-click the roof) or are
visually-distinctive landmarks, you may enter at Pass C directly. Not a general A→B replacement —
coordinate-less generic rows still go through A/B.

## Self-improvement loop (optional, manually gated — SKILL.md §8.5)
After a finished pass/file, you may run `python scripts/self_improve.py <results.jsonl>` to emit
`PROPOSED_UPDATES.md` (outcome funnel, weakest ladder reasons, COORD_SOURCE reliability, ladder
effectiveness, candidate centroid fingerprints). It **only proposes** — a human reviews and merges into the
KB / `geo_convert.KNOWN_CENTROIDS`; nothing is auto-applied. The loop may evolve the "how to find" layer (KB,
fingerprints, query heuristics) ONLY; it must **never** touch the §0 contract, the Pass C satellite gate,
`validate_results.py`, or `assemble_results.py`, and never relax a metric it also reports. Cursor-native
option, still human-gated: durable conventions can be seeded into **Memories**, or stable heuristics captured
as a `.cursor/rules/*.mdc` via `/Generate Cursor Rules` — but prune aggressively, and route any rule change
through review + a version bump, never silent self-rewrite.
