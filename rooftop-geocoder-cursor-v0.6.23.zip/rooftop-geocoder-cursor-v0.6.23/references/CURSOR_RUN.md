# Rooftop Geocoder — running from Cursor's Agent Panel (v0.6.23)

Cursor removes Claude chat's two bottlenecks (no image cap, direct disk) and runs each pass **autonomously**.
**One input file → one `results.jsonl` → one workbook, single agent** — there is no sharding or parallel
machinery. The chain is `A → B → B.1 → C → (out) → optional D → C → (out)`, satellite-gated. `SKILL.md` is
authoritative for the per-row logic; this is just how to drive it from Cursor.

`BASE` = input filename without extension. Work from your workspace root (the folder with `AGENTS.md`).

## One-time setup
1. Unzip this package into a Cursor workspace — its root (with `AGENTS.md`) is what Cursor reads.
2. Enable Cursor's **`@Browser`** tooling and connect a browser that can **screenshot** (Pass C needs pixels).
3. In the Cursor terminal: `pip install pandas openpyxl eviltransform openlocationcode pycountry`.
4. Put `coord_kb.md` at the root; create `inputs/` and `results/`.
5. Model: **Composer 2.5** for A/B/B.1/combine; **Claude Sonnet** for Pass C (vision). Not Auto. Enable
   **MAX mode** to cut "Continue" stops.

## The run (single agent, one pass at a time)
Use the full, copy-paste trigger for each pass from the **operator guide, §11 (Runthrough)** — they're
filled and current. The flow:
```
inputs/<BASE>.csv
  → PASS A   → appends results/<BASE>_results.jsonl
  → PASS B   (the manual_review rows)
  → PASS B.1 (still-stuck, thin-input rows: read RELEVANT_URL + web-search → more specific query)
  → PASS C   (satellite gate — the only step that writes `resolved`)
  → validate + assemble   ← shippable here
  → (optional) PASS D  → then PASS C again on D's candidates → validate + assemble
```
Each pass runs to completion autonomously; if Cursor shows "Continue" at its tool-call cap, re-send — it's
idempotent (skips terminal rows). Every pass ends by printing a **NEXT STEPS** block telling you what to run
next (SKILL.md §2.1).

## Combine (after Pass C)
```
python scripts/validate_results.py results/<BASE>_results.jsonl          # §0 gate; must PASS (exit 0)
python scripts/assemble_results.py inputs/<BASE>.csv results/<BASE>_results.jsonl results/<BASE>_rooftop_geocoded.xlsx
```

## Notes
- State lives in the single append-only `results/<BASE>_results.jsonl`, keyed on `FACILITY_ID`,
  last-write-wins — so re-running any pass resumes cleanly (skip terminal rows).
- Watch the first ~5 rows of Pass A: confirm it reads the coordinate from the URL (not a viewport `@`), uses
  Baidu/Kakao for CN/KR, and that Pass C uses the direct satellite URL (no Layers fumbling).
- One IP: run a single browser agent at a time. Several concurrent browsers from one network trip Google's
  rate limits faster, with no real throughput gain.
- `generate_handoff.py` can record what a pass did, but in Cursor each pass runs start-to-finish — it is not
  a stop point.
