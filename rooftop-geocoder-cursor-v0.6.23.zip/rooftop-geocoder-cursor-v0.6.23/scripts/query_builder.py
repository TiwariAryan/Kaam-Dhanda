#!/usr/bin/env python3
"""
query_builder.py — Pass B query construction. For each unresolved (manual_review) row, build a
RANKED list of candidate search queries from all attributes, plus a region-aware registry template,
and flag rows that need native-language rendering (which the agent does in-context — a script can't
translate reliably here).

    python scripts/query_builder.py INPUT_PATH \
        [--results FS_DIR/results/<BASE>_results.jsonl] [--out queries.csv] [--only-status manual_review]

Output columns: FACILITY_ID, FACILITY_NAME, FACILITY_ADDRESS, FACILITY_REGION, RELEVANT_URL,
QUERY_CANDIDATES (numbered, ladder-ordered), RESOLUTION_QUERY (top candidate), NEEDS_NATIVE.

The ladder order (matches SKILL §3): name+address → URL/brand → registry template → name+city.
The agent then tries them top-down, renders NEEDS_NATIVE rows into hanzi/kanji/local script, and
records what it used in RESOLUTION_QUERY / LADDER_TRIED.
"""
import sys, os, re, json, argparse
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import geo_convert as gc
except Exception:
    gc = None

# Native-script regions need the agent to render queries into local script (NEEDS_NATIVE).
NATIVE_REGIONS = {"china", "hong kong", "taiwan", "macao", "japan", "korea"}
# Business-registry candidate is a CHINA-only exception (Chinese-language registries/Baike).
# The street address is already present in the input (extraction pipeline), so POI construction
# leads; the registry template is a lower-ranked fallback and only for Chinese-language records.
REGISTRY_TMPL = {
    "china": ("分公司", "地址"), "hong kong": ("分公司", "地址"),
    "taiwan": ("分公司", "地址"), "macao": ("分公司", "地址"),
}
CJK_RANGE = re.compile(r"[\u3000-\u9fff\uac00-\ud7af\uf900-\ufaff]")


def norm_region(s):
    if gc:
        try:
            return gc._normalize_region(s)
        except Exception:
            pass
    return re.sub(r"[^a-z ]", " ", str(s or "").lower()).strip()


def clean(s):
    s = str(s or "").strip()
    if not s or s.lower() in ("nan", "none"):
        return ""
    # split glued concatenations like "INC.Omaha" -> "INC. Omaha"; fix "&"-typos
    s = re.sub(r"([a-z])\.([A-Z])", r"\1. \2", s)
    s = re.sub(r"\s*&amp;\s*", " & ", s)
    if gc and hasattr(gc, "normalize_address"):
        try:
            s = gc.normalize_address(s) or s
        except Exception:
            pass
    return re.sub(r"\s+", " ", s).strip()


def brand_from_url(url):
    url = str(url or "")
    m = re.search(r"https?://(?:www\.)?([^/]+)", url)
    if not m:
        return ""
    host = m.group(1)
    parts = [p for p in host.split(".") if p not in ("com", "co", "net", "org", "www", "cn", "jp", "kr")]
    return parts[0] if parts else ""


def city_from_address(addr):
    # crude: last 1-2 comma fields often carry city/region; leave to agent if unclear
    parts = [p.strip() for p in str(addr or "").split(",") if p.strip()]
    return parts[-1] if parts else ""


def build(row):
    name = clean(row.get("FACILITY_NAME") or row.get("facility_name"))
    company = clean(row.get("COMPANY_NAME") or row.get("company_name")
                    or row.get("ISSUER_NAME") or row.get("issuer_name"))
    addr = clean(row.get("FACILITY_ADDRESS") or row.get("facility_address"))
    reg = clean(row.get("FACILITY_REGION") or row.get("facility_region"))
    url = row.get("RELEVANT_URL") or row.get("relevant_url")
    rk = norm_region(reg)
    already_native = bool(CJK_RANGE.search(name + " " + addr))
    needs_native = (rk in NATIVE_REGIONS) and not already_native

    cands = []
    # POI construction leads — the street address is already in the input from extraction.
    if name and addr:
        cands.append(f"{name} {addr}")
    # company/issuer name disambiguates same-named facilities and helps brand POIs
    if company and name and reg and company.lower() not in name.lower():
        cands.append(f"{company} {name} {reg}")
    if name and reg:
        cands.append(f"{name} {reg}")
    brand = brand_from_url(url)
    if brand and reg:
        cands.append(f"{brand} {name} {reg}".strip())
    city = city_from_address(addr) or reg
    if name and city:
        cands.append(f"{name} {city}")
    # business-registry template: CHINA-only exception, lower priority than POI construction.
    if rk in REGISTRY_TMPL and city:
        branch, addrw = REGISTRY_TMPL[rk]
        cands.append(f"{company or name} {city} {branch} {addrw}")
    if name:
        cands.append(name)
    # dedup preserving order
    seen, ranked = set(), []
    for c in cands:
        c = re.sub(r"\s+", " ", c).strip()
        if c and c.lower() not in seen:
            seen.add(c.lower()); ranked.append(c)
    return ranked, needs_native


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--results", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--only-status", default="manual_review")
    a = ap.parse_args()

    df = pd.read_excel(a.input) if a.input.lower().endswith((".xlsx", ".xls")) else pd.read_csv(a.input)
    idc = next((c for c in df.columns if c.lower() in ("facility_id", "row_id")), None)
    if not idc:
        raise SystemExit("input needs a facility_id / row_id column")

    keep = None
    if a.results and os.path.exists(a.results):
        st = {}
        with open(a.results) as f:
            for line in f:
                line = line.strip()
                if line:
                    r = json.loads(line); st[str(r.get("FACILITY_ID"))] = (r.get("STATUS") or "")
        keep = {k for k, s in st.items() if s == a.only_status}

    out = []
    for _, row in df.iterrows():
        fid = str(row[idc])
        if keep is not None and fid not in keep:
            continue
        ranked, needs_native = build(row)
        out.append({
            "FACILITY_ID": fid,
            "FACILITY_NAME": row.get("FACILITY_NAME") or row.get("facility_name"),
            "FACILITY_ADDRESS": row.get("FACILITY_ADDRESS") or row.get("facility_address"),
            "FACILITY_REGION": row.get("FACILITY_REGION") or row.get("facility_region"),
            "RELEVANT_URL": row.get("RELEVANT_URL") or row.get("relevant_url"),
            "QUERY_CANDIDATES": "  |  ".join(f"{i+1}) {c}" for i, c in enumerate(ranked)),
            "RESOLUTION_QUERY": ranked[0] if ranked else "",
            "NEEDS_NATIVE": needs_native,
        })

    res = pd.DataFrame(out)
    outpath = a.out or (os.path.splitext(a.input)[0] + "_queries.csv")
    res.to_csv(outpath, index=False)
    print(f"built {len(res)} candidate query sets -> {outpath}")
    print(f"  needing native-language rendering by the agent: {int(res['NEEDS_NATIVE'].sum()) if len(res) else 0}")


if __name__ == "__main__":
    main()
