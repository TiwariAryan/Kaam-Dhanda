#!/usr/bin/env python3
"""
generate_handoff.py — write a per-session handoff from the durable state.

    python3 generate_handoff.py INPUT RESULTS OUTDIR --base BASE --session-n N \
        [--notes "Baidu blocked; ..."] [--kb-appended "appended CN registry pattern for ..."]

Writes in OUTDIR (the Filesystem-MCP `results/` folder):
  * <BASE>_HANDOFF_n<N>.md — counts by status, remaining-by-region (cluster view), the resume
    pointer, what to do next, KB entries appended this session, and blockers.
  * <BASE>_remaining.csv   — the not-yet-terminal rows (next session's input chunk).

Keyed on FACILITY_ID (case-insensitive). "Terminal" = STATUS in resolved / manual_review /
not_found. resolved_pending_qa rows are shown separately (they still need Pass C).
"""
import sys, os, json, argparse
from datetime import datetime, timezone
import pandas as pd

DONE = {"resolved", "manual_review", "not_found"}


def rid(r):
    for k in ("FACILITY_ID", "facility_id", "ROW_ID", "row_id"):
        if k in r and r[k] is not None:
            return str(r[k]).strip()
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("results"); ap.add_argument("outdir")
    ap.add_argument("--base", required=True)
    ap.add_argument("--session-n", default="1")
    ap.add_argument("--notes", default="")
    ap.add_argument("--kb-appended", default="")
    a = ap.parse_args()

    df = pd.read_excel(a.input) if a.input.lower().endswith((".xlsx", ".xls")) else pd.read_csv(a.input)
    idc = next((c for c in df.columns if c.lower() in ("facility_id", "row_id")), None)
    if not idc:
        raise SystemExit("input needs a facility_id / row_id column")
    df[idc] = df[idc].astype(str)
    regc = next((c for c in df.columns if c.lower() in ("facility_region", "region", "country")), None)

    status = {}
    try:
        with open(a.results) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                r = json.loads(line)
                fid = rid(r)
                if fid and r.get("STATUS"):
                    status[fid] = r["STATUS"]
    except FileNotFoundError:
        pass

    df["_st"] = df[idc].map(status).fillna("")
    done = df["_st"].isin(DONE)
    pending = df["_st"] == "resolved_pending_qa"
    todo = df[~done & ~pending]

    os.makedirs(a.outdir, exist_ok=True)
    rem_path = os.path.join(a.outdir, f"{a.base}_remaining.csv")
    todo.drop(columns=["_st"]).to_csv(rem_path, index=False)

    sc = df["_st"].replace("", "(todo)").value_counts()
    L = [f"# {a.base} — HANDOFF (session {a.session_n})",
         f"_generated {datetime.now(timezone.utc).isoformat(timespec='seconds')}_", "",
         f"**Progress:** {int(done.sum())}/{len(df)} terminal · {int(pending.sum())} pending satellite QA "
         f"· {int((~done & ~pending).sum())} to do", "",
         "## Status counts", sc.to_string(), ""]
    if regc and len(todo):
        L += ["## Remaining by region (route by cluster)", todo[regc].value_counts().head(20).to_string(), ""]
    L += ["## Resume",
          f"- State (shared): `{a.base}_results.jsonl` — skip terminal FACILITY_IDs.",
          f"- Remaining chunk: `{a.base}_remaining.csv` ({len(todo)} rows).",
          "- Next: finish Pass A/B on to-do rows, then run Pass C (satellite) on the "
          "`resolved_pending_qa` rows before combine.", ""]
    if a.kb_appended:
        L += ["## KB entries appended this session", a.kb_appended, ""]
    if a.notes:
        L += ["## Blockers / notes", a.notes, ""]

    hp = os.path.join(a.outdir, f"{a.base}_HANDOFF_n{a.session_n}.md")
    with open(hp, "w") as f:
        f.write("\n".join(L) + "\n")
    print(f"wrote {hp}")
    print(f"wrote {rem_path}  ({len(todo)} remaining rows)")


if __name__ == "__main__":
    main()
