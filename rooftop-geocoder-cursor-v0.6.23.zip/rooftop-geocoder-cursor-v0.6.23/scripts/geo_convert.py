"""
geo_convert.py — deterministic coordinate-system conversion + sanity validation.

Why this exists
---------------
Coordinates read out of consumer maps are NOT all in the same datum:
  * Google / Bing (outside China)  -> WGS-84  (what we want; no conversion)
  * Google / Bing place data IN China, and all Baidu data -> offset systems:
        - GCJ-02 ("Mars"): China's mandated obfuscation of WGS-84
        - BD-09          : Baidu's extra offset layer on top of GCJ-02
    A point read in GCJ-02 or BD-09 and stored as WGS-84 is wrong by ~100-700 m.
  * Google SATELLITE imagery in China is WGS-84-aligned (unshifted), which is
    why the China workflow reads the final pin off the satellite layer.

MSCI target datum = WGS-84. Every coordinate we WRITE must be WGS-84.

The conversion math is the well-known public "eviltransform" algorithm
(pure arithmetic, no API). Forward (WGS->GCJ) is ~1-2 m; the reverse uses
Newton-style iteration to invert it to sub-metre.

All functions use (lng, lat) order internally to match the canonical algorithm,
but the public validate_* helpers and the convenience wrappers take (lat, lng)
because that is the order we store. Read the signatures.
"""

import math

X_PI = math.pi * 3000.0 / 180.0
A = 6378245.0                      # Krasovsky 1940 semi-major axis (GCJ-02 basis)
EE = 0.00669342162296594323        # eccentricity squared


def decode_plus_code(code, ref_lat, ref_lng):
    """
    Decode an Open Location Code (Plus Code) -> (lat, lng) WGS-84.
    Short codes (e.g. "27G8+J5", common in Saudi/Middle-East addresses) are
    recovered against a city-centroid reference. IMPORT GOTCHA learned in the
    100-row run: the functions live in the submodule, not the package root:
        import openlocationcode.openlocationcode as olc   # NOT `import openlocationcode`
        pip install openlocationcode
    Returns the cell centre (~14 m for a standard 8+2 code).
    """
    import openlocationcode.openlocationcode as olc
    code = str(code).strip()
    if olc.isShort(code):
        code = olc.recoverNearest(code, ref_lat, ref_lng)
    a = olc.decode(code)
    return a.latitudeCenter, a.longitudeCenter


# --- pre-run address triage / normalisation (route vague rows without browser calls) ---
import re as _re
_VAGUE = ("general location","approximately","acres","hectare","various location",
          "multiple location","to be confirmed","tbd","n/a")
_PLUS = _re.compile(r"[A-Z0-9]{4,6}\+[A-Z0-9]{2,3}", _re.I)
_POBOX = _re.compile(r"\b(p\.?\s*o\.?\s*box|post\s*office\s*box|gpo\s*box)\b", _re.I)

def normalize_address(addr):
    """Light, non-destructive cleanup: &->+ in plus codes, split 'No.9Word', collapse ws."""
    a = "" if addr is None else str(addr)
    a = _re.sub(r"([A-Z0-9]{4,6})&([A-Z0-9]{2,3})", r"\1+\2", a)   # XFVW&X2M -> XFVW+X2M
    a = _re.sub(r"(No\.?\s*\d+)([A-Za-z])", r"\1 \2", a)         # No.9Las -> No.9 Las
    return _re.sub(r"\s+", " ", a).strip()

def triage_address(addr):
    """Flag rows that can be routed WITHOUT browser calls.
    Returns {plus_code, po_box, vague, normalized}."""
    a = normalize_address(addr)
    pc = _PLUS.search(a)
    return {
        "plus_code": pc.group(0) if pc else None,
        "po_box": bool(_POBOX.search(a)),
        "vague": (not bool(_re.search(r"\d", a))) or any(t in a.lower() for t in _VAGUE),
        "normalized": a,
    }


# --------------------------------------------------------------------------- #
# China-bounds gate: outside mainland China there is no offset, return as-is.
# --------------------------------------------------------------------------- #
def _out_of_china(lng: float, lat: float) -> bool:
    return not (72.004 <= lng <= 137.8347 and 0.8293 <= lat <= 55.8271)


def _transform_lat(lng: float, lat: float) -> float:
    ret = (-100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat
           + 0.1 * lng * lat + 0.2 * math.sqrt(abs(lng)))
    ret += (20.0 * math.sin(6.0 * lng * math.pi) + 20.0 * math.sin(2.0 * lng * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(lat * math.pi) + 40.0 * math.sin(lat / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (160.0 * math.sin(lat / 12.0 * math.pi) + 320.0 * math.sin(lat * math.pi / 30.0)) * 2.0 / 3.0
    return ret


def _transform_lng(lng: float, lat: float) -> float:
    ret = (300.0 + lng + 2.0 * lat + 0.1 * lng * lng
           + 0.1 * lng * lat + 0.1 * math.sqrt(abs(lng)))
    ret += (20.0 * math.sin(6.0 * lng * math.pi) + 20.0 * math.sin(2.0 * lng * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(lng * math.pi) + 40.0 * math.sin(lng / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (150.0 * math.sin(lng / 12.0 * math.pi) + 300.0 * math.sin(lng / 30.0 * math.pi)) * 2.0 / 3.0
    return ret


# --------------------------------------------------------------------------- #
# Core transforms (lng, lat)
# --------------------------------------------------------------------------- #
def wgs84_to_gcj02(lng: float, lat: float):
    if _out_of_china(lng, lat):
        return lng, lat
    dlat = _transform_lat(lng - 105.0, lat - 35.0)
    dlng = _transform_lng(lng - 105.0, lat - 35.0)
    radlat = lat / 180.0 * math.pi
    magic = math.sin(radlat)
    magic = 1 - EE * magic * magic
    sqrtmagic = math.sqrt(magic)
    dlat = (dlat * 180.0) / ((A * (1 - EE)) / (magic * sqrtmagic) * math.pi)
    dlng = (dlng * 180.0) / (A / sqrtmagic * math.cos(radlat) * math.pi)
    return lng + dlng, lat + dlat


def gcj02_to_wgs84(lng: float, lat: float, eps: float = 1e-9, max_iter: int = 100):
    """Iterative inverse of wgs84_to_gcj02 -> sub-metre accuracy."""
    if _out_of_china(lng, lat):
        return lng, lat
    wlng, wlat = lng, lat
    for _ in range(max_iter):
        glng, glat = wgs84_to_gcj02(wlng, wlat)
        dlng, dlat = glng - lng, glat - lat
        if abs(dlng) < eps and abs(dlat) < eps:
            break
        wlng -= dlng
        wlat -= dlat
    return wlng, wlat


def gcj02_to_bd09(lng: float, lat: float):
    z = math.sqrt(lng * lng + lat * lat) + 0.00002 * math.sin(lat * X_PI)
    theta = math.atan2(lat, lng) + 0.000003 * math.cos(lng * X_PI)
    return z * math.cos(theta) + 0.0065, z * math.sin(theta) + 0.006


def bd09_to_gcj02(lng: float, lat: float):
    x, y = lng - 0.0065, lat - 0.006
    z = math.sqrt(x * x + y * y) - 0.00002 * math.sin(y * X_PI)
    theta = math.atan2(y, x) - 0.000003 * math.cos(x * X_PI)
    return z * math.cos(theta), z * math.sin(theta)


def bd09_to_wgs84(lng: float, lat: float):
    g_lng, g_lat = bd09_to_gcj02(lng, lat)
    return gcj02_to_wgs84(g_lng, g_lat)


def wgs84_to_bd09(lng: float, lat: float):
    g_lng, g_lat = wgs84_to_gcj02(lng, lat)
    return gcj02_to_bd09(g_lng, g_lat)


# --------------------------------------------------------------------------- #
# Public convenience wrappers (lat, lng) -> (lat, lng), the order we STORE.
# `source` tells us what datum the raw reading is in.
# --------------------------------------------------------------------------- #
def to_wgs84(lat: float, lng: float, source: str):
    """
    Normalise any reading to WGS-84.

    source:
      "wgs84"  -> Google/Bing outside China, or a Google-satellite pixel read. No-op.
      "gcj02"  -> Google/Bing PLACE data inside China (street/label layer).
      "bd09"   -> any Baidu reading.
    Returns (lat, lng) in WGS-84.

    CRITICAL: dispatch is by SOURCE (which map produced the reading), never by
    geography. The China bounds gate is a crude rectangle that also covers Korea,
    Japan, Taiwan and parts of SE Asia, so labelling a *Korean* or *Japanese*
    reading as gcj02/bd09 would wrongly shift it ~hundreds of metres. Korea/Japan
    have no offset -> their readings are always source="wgs84". Only ever pass
    gcj02/bd09 for readings that genuinely came from a Chinese map layer.
    """
    s = source.strip().lower()
    if s in ("wgs84", "wgs-84", "gps", "satellite"):
        return lat, lng
    if s in ("gcj02", "gcj-02", "mars"):
        lng2, lat2 = gcj02_to_wgs84(lng, lat)
        return lat2, lng2
    if s in ("bd09", "bd-09", "baidu"):
        lng2, lat2 = bd09_to_wgs84(lng, lat)
        return lat2, lng2
    raise ValueError(f"unknown coordinate source: {source!r} (use wgs84|gcj02|bd09)")


# --------------------------------------------------------------------------- #
# Sanity validation (Phase-4: cheap, deterministic, zero reasoning)
# --------------------------------------------------------------------------- #
def haversine_m(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """Great-circle distance in metres."""
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def china_conversion_plausible(raw_lat: float, raw_lng: float,
                               out_lat: float, out_lng: float,
                               lo_m: float = 50.0, hi_m: float = 2500.0) -> dict:
    """
    Guard against the 'forgot to convert' failure for China rows.

    A genuine BD-09/GCJ-02 -> WGS-84 conversion shifts a Chinese point by roughly
    a few hundred metres up to ~1.4 km. If raw≈output (shift below lo_m), the
    conversion almost certainly did NOT run and the written coordinate is offset
    garbage -> flag. An implausibly large shift (above hi_m) is also suspect.

    Returns {shift_m, ran (bool), plausible (bool)}. Call this ONLY for China-
    source rows, after to_wgs84(); for non-offset sources a ~0 shift is correct.
    """
    shift = haversine_m(raw_lat, raw_lng, out_lat, out_lng)
    return {
        "shift_m": round(shift, 1),
        "ran": shift >= lo_m,
        "plausible": lo_m <= shift <= hi_m,
    }


# Coarse, GENEROUS country bounding boxes (minlat, minlng, maxlat, maxlng) used
# only as a cheap "is this roughly in the right country" net. Keys are readable
# names; lookup normalises UN/ISO names ("Korea (the Republic of)",
# "Taiwan (Province of China)", "Côte d'Ivoire") so they match. Coarse by design:
# the real error-catching is the verification guards + the GT distance check.
# Extend freely. An unknown region returns None and the bbox check is skipped.
from geo_bbox import COUNTRY_BBOX  # comprehensive global table (normalized-variant keyed)
# Common aliases -> normalise to the same keys above.
_BBOX_ALIASES = {
    "south korea": "korea", "usa": "united states of america",
    "united states": "united states of america", "us": "united states of america",
    "uk": "united kingdom of great britain and northern ireland",
    "united kingdom": "united kingdom of great britain and northern ireland",
    "russia": "russian federation", "turkey": "turkiye", "vietnam": "viet nam",
}


def _normalize_region(s: str) -> str:
    """Lowercase, strip accents, drop parentheticals and standalone 'the'."""
    import unicodedata, re
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    s = s.lower()
    s = re.sub(r"\([^)]*\)", " ", s)     # remove (Province of China), (the), ...
    s = re.sub(r"[^a-z0-9 ]", " ", s)    # punctuation -> space
    s = re.sub(r"\bthe\b", " ", s)       # standalone 'the'
    s = re.sub(r"\s+", " ", s).strip()
    return s


_BBOX_NORM = {_normalize_region(k): v for k, v in COUNTRY_BBOX.items()}


def _bbox_for(region: str):
    if not region:
        return None
    key = _normalize_region(region)
    key = _normalize_region(_BBOX_ALIASES.get(key, key))
    return _BBOX_NORM.get(key)


def validate_point(lat: float, lng: float, region: str = "",
                   city_lat: float = None, city_lng: float = None,
                   city_radius_km: float = 60.0) -> dict:
    """
    Cheap deterministic checks. Returns a dict of flags; never raises on a
    'bad' point (it reports). The caller routes failures to manual_review.

      finite        : lat/lng are real numbers in valid global range
      in_country    : inside the region bbox (None if region not bounded)
      near_city     : within city_radius_km of a supplied city centroid (None if not supplied)
      city_dist_km  : distance to city centroid (None if not supplied)
      ok            : finite AND not explicitly failing any performed check
    """
    out = {"finite": False, "in_country": None, "near_city": None,
           "city_dist_km": None, "ok": False}

    try:
        lat = float(lat); lng = float(lng)
    except (TypeError, ValueError):
        return out
    if not (math.isfinite(lat) and math.isfinite(lng)):
        return out
    if not (-90.0 <= lat <= 90.0 and -180.0 <= lng <= 180.0):
        return out
    out["finite"] = True

    bbox = _bbox_for(region)
    if bbox:
        mnlat, mnlng, mxlat, mxlng = bbox
        out["in_country"] = (mnlat <= lat <= mxlat and mnlng <= lng <= mxlng)

    if city_lat is not None and city_lng is not None:
        d = haversine_m(lat, lng, city_lat, city_lng) / 1000.0
        out["city_dist_km"] = round(d, 3)
        out["near_city"] = (d <= city_radius_km)

    out["ok"] = (out["finite"]
                 and out["in_country"] is not False
                 and out["near_city"] is not False)
    return out


# --------------------------------------------------------------------------- #
# Self-test
# --------------------------------------------------------------------------- #

# ── Live, per-row centroid signals (Phase B layer-1) ──────────────────────────
# Complements check_centroid_fallback.py: that tool finds centroids by CLUSTERING
# across the dataset; these catch a SINGLE row at geocode time (the gap its own
# docs flag — single-record centroids need a known-centroid lookup or satellite).

# Curated known centroids / observed junk-geocode fingerprints. Extend freely.
# (lat, lng, label). Matched within KNOWN_CENTROID_RADIUS_M metres.
KNOWN_CENTROIDS = [
    (36.43822861, 127.8328705, "KR national centroid (observed junk fingerprint)"),
    (35.86166,    104.195397,  "CN geographic centroid"),
    (22.3511148,  78.6677428,  "IN geographic centroid"),
    (36.204824,   138.252924,  "JP geographic centroid"),
    (37.09024,   -95.712891,   "US geographic centroid"),
]
KNOWN_CENTROID_RADIUS_M = 150.0

def known_centroid_match(lat, lng, radius_m=KNOWN_CENTROID_RADIUS_M):
    """Return the label of a known centroid within radius_m of (lat,lng), else None."""
    for clat, clng, label in KNOWN_CENTROIDS:
        if haversine_m(lat, lng, clat, clng) <= radius_m:
            return label
    return None

# Google place-type taxonomy: area types => the coordinate is a centroid
# (location_type APPROXIMATE / GEOMETRIC_CENTER); building/POI types are rooftop.
_AREA_TYPES = {
    "locality", "sublocality", "sublocality_level_1", "neighborhood",
    "administrative_area_level_1", "administrative_area_level_2",
    "administrative_area_level_3", "administrative_area_level_4",
    "postal_code", "postal_town", "country", "colloquial_area",
    "route", "natural_feature", "political",
}
_BUILDING_TYPES = {
    "premise", "subpremise", "street_address", "point_of_interest",
    "establishment", "building", "store", "premise",
}

def is_centroid_place_type(types):
    """True if the matched place is an area/admin/postal entity and NOT a
    building/POI — i.e. its coordinate is a centroid. `types` may be a string
    (one type or comma/space separated) or a list of type tags."""
    if types is None:
        return False
    if isinstance(types, str):
        toks = [t.strip().lower() for t in types.replace(",", " ").split()]
    else:
        toks = [str(t).strip().lower() for t in types]
    toks = set(t for t in toks if t)
    if toks & _BUILDING_TYPES:          # any building/POI signal -> not a centroid
        return False
    return bool(toks & _AREA_TYPES)     # only area signals -> centroid


if __name__ == "__main__":
    print("=== round-trip accuracy (WGS84 -> BD09 -> WGS84) ===")
    # Beijing-area test point (WGS-84)
    for name, (lat, lng) in {
        "Beijing":   (39.90750, 116.39723),
        "Shanghai":  (31.23037, 121.47370),
        "Shenzhen":  (22.54330, 114.05786),
    }.items():
        bl, ba = wgs84_to_bd09(lng, lat)          # -> BD-09 (lng,lat)
        rlng, rlat = bd09_to_wgs84(bl, ba)        # back to WGS-84
        err_m = haversine_m(lat, lng, rlat, rlng)
        # also report the raw offset magnitude (how wrong BD-09 looks vs WGS-84)
        offset_m = haversine_m(lat, lng, ba, bl)
        print(f"  {name:9s} round-trip err = {err_m*100:6.2f} cm | "
              f"raw BD09-vs-WGS84 offset = {offset_m:6.1f} m")

    print("\n=== to_wgs84() dispatch ===")
    lat, lng = 39.90750, 116.39723
    bl, ba = wgs84_to_bd09(lng, lat)
    got_lat, got_lng = to_wgs84(ba, bl, source="bd09")
    print(f"  bd09 reading ({ba:.6f},{bl:.6f}) -> wgs84 ({got_lat:.6f},{got_lng:.6f}) "
          f"| err {haversine_m(lat,lng,got_lat,got_lng)*100:.2f} cm")
    print(f"  wgs84 passthrough: {to_wgs84(lat, lng, source='wgs84')}")
    # Korea reading: correct path is source="wgs84" -> true no-op
    print(f"  Seoul source=wgs84 (correct, no-op): "
          f"{to_wgs84(37.5665, 126.9780, source='wgs84')}")
    # GOTCHA: mislabelling the same Korea reading as gcj02 shifts it, because the
    # crude China gate covers Korea. This is why we dispatch by source, not place.
    bad_lat, bad_lng = to_wgs84(37.5665, 126.9780, source='gcj02')
    print(f"  Seoul source=gcj02 (WRONG label) shifts it "
          f"{haversine_m(37.5665,126.9780,bad_lat,bad_lng):.0f} m -> never do this")

    print("\n=== validate_point() ===")
    # KEPCO/Naju point from the pilot logs, region Korea
    print("  Naju KR:", validate_point(35.026293, 126.7844294,
                                       region="Korea (the Republic of)"))
    # an obviously-wrong point (Korea region, but coords in the ocean off Africa)
    print("  bad   :", validate_point(0.0, 0.0, region="Korea (the Republic of)"))
    # with a city centroid check (Seoul)
    print("  Gangnam vs Seoul centroid:",
          validate_point(37.5022855, 127.0406175, region="Korea (the Republic of)",
                         city_lat=37.5665, city_lng=126.9780))
