"""Flag centroid fallback cases after data collection.

Two independent checks:

1. CENTROID FALLBACK (multi-entity):
   Multiple unrelated entities share the same (or near-same) coordinates
   — the geocoder fell back to a city/region centroid.

2. SAME-ISSUER COORDINATE DUPLICATE:
   The same issuer has multiple assets at the exact same coordinate with
   different location names — the issuer reused one geocode for several
   distinct locations.

Uses the same 4-tier detection + co-location safety valve as the full
bare-soil classification pipeline, but runs standalone with no
dependencies beyond pandas.

Required input columns (minimum 5):
    ASSET_ID, ISSUER_ID, LOCATION_NAME, LATITUDE, LONGITUDE

Usage:
    python check_centroid_fallback.py data.xlsx
    python check_centroid_fallback.py data.csv --export flagged_assets.xlsx
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

# ── Thresholds (identical to flag_bare_soil.core.config) ──────────────────────

CENTROID_EXACT_MIN_ASSETS = 3
CENTROID_EXACT_MIN_NAMES = 3

CENTROID_R4_MIN_ASSETS = 5
CENTROID_R4_MIN_NAMES = 5
CENTROID_R4_LOOSE_MIN_ASSETS = 3
CENTROID_R4_LOOSE_MIN_NAMES = 3
CENTROID_R4_LOOSE_MIN_ISSUERS = 3

CENTROID_R3_MIN_ASSETS = 8
CENTROID_R3_MIN_NAMES = 8
CENTROID_R3_MIN_ISSUERS = 5

CENTROID_BROAD_MIN_ASSETS = 8
CENTROID_BROAD_MAX_UNIQUE_RATIO = 0.15

COLOCATED_MAX_ISSUERS = 2
COLOCATED_MAX_NAMES = 2
COLOCATED_MIN_ASSETS = 2

# Same-issuer duplicate: one issuer, same exact coord, 2+ different names
SAME_ISSUER_MIN_ASSETS = 2
SAME_ISSUER_MIN_NAMES = 2

REQUIRED_COLS = ["ASSET_ID", "ISSUER_ID", "LOCATION_NAME", "LATITUDE", "LONGITUDE"]

# ── Column aliasing for rooftop-geocoder schema ───────────────────────────────
# Maps this project's column names onto the detector's required names so the
# same file can be run over an assembled rooftop-geocoder workbook/CSV.
_ALIASES = {
    "ASSET_ID":      ["ASSET_ID", "FACILITY_ID", "ROW_ID"],
    "ISSUER_ID":     ["ISSUER_ID", "ISSUER_NAME", "COMPANY_NAME", "COMPANY"],
    "LOCATION_NAME": ["LOCATION_NAME", "FACILITY_NAME", "NAME", "MATCH_PLACE_NAME"],
    "LATITUDE":      ["LATITUDE", "LAT"],
    "LONGITUDE":     ["LONGITUDE", "LON", "LNG", "LONG"],
}

def _apply_aliases(df):
    cols = {c.upper(): c for c in df.columns}
    for canonical, candidates in _ALIASES.items():
        if canonical in df.columns:
            continue
        for cand in candidates:
            if cand in cols:
                df = df.rename(columns={cols[cand]: canonical})
                break
    return df



# ── File loading ──────────────────────────────────────────────────────────────

def load_file(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if p.suffix in {".xlsx", ".xlsm"}:
        df = pd.read_excel(p)
    elif p.suffix == ".csv":
        df = pd.read_csv(p)
    elif p.suffix in {".parquet", ".pq"}:
        df = pd.read_parquet(p)
    else:
        raise ValueError(f"Unsupported file type: {p.suffix}")

    df = _apply_aliases(df)
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df


# ── 4-tier centroid detection ─────────────────────────────────────────────────

def _agg_coords(df, lat_col="LATITUDE", lon_col="LONGITUDE"):
    return (
        df.groupby([lat_col, lon_col])
        .agg(
            n_assets=("ASSET_ID", "count"),
            n_names=("LOCATION_NAME", "nunique"),
            n_issuers=("ISSUER_ID", "nunique"),
        )
        .reset_index()
    )


def _detect_tier1_exact(df: pd.DataFrame) -> set[tuple[float, float]]:
    """Exact lat/lon: >= 3 assets AND >= 3 unique names."""
    stats = _agg_coords(df)
    hit = stats[
        (stats["n_assets"] >= CENTROID_EXACT_MIN_ASSETS)
        & (stats["n_names"] >= CENTROID_EXACT_MIN_NAMES)
    ]
    return set(zip(hit["LATITUDE"], hit["LONGITUDE"]))


def _detect_tier2_r4(df: pd.DataFrame) -> set[tuple[float, float]]:
    """4dp grid (~11 m): strict (5/5) OR loose (3/3/3-issuer)."""
    tmp = df.assign(
        _lat=df["LATITUDE"].round(4), _lon=df["LONGITUDE"].round(4),
    )
    stats = _agg_coords(tmp, "_lat", "_lon")
    strict = stats[
        (stats["n_assets"] >= CENTROID_R4_MIN_ASSETS)
        & (stats["n_names"] >= CENTROID_R4_MIN_NAMES)
    ]
    loose = stats[
        (stats["n_assets"] >= CENTROID_R4_LOOSE_MIN_ASSETS)
        & (stats["n_names"] >= CENTROID_R4_LOOSE_MIN_NAMES)
        & (stats["n_issuers"] >= CENTROID_R4_LOOSE_MIN_ISSUERS)
    ]
    combined = pd.concat([strict, loose]).drop_duplicates(subset=["_lat", "_lon"])
    return set(zip(combined["_lat"], combined["_lon"]))


def _detect_tier3_r3(df: pd.DataFrame) -> set[tuple[float, float]]:
    """3dp grid (~110 m): >= 8 assets, 8 names, 5 issuers."""
    tmp = df.assign(
        _lat=df["LATITUDE"].round(3), _lon=df["LONGITUDE"].round(3),
    )
    stats = _agg_coords(tmp, "_lat", "_lon")
    hit = stats[
        (stats["n_assets"] >= CENTROID_R3_MIN_ASSETS)
        & (stats["n_names"] >= CENTROID_R3_MIN_NAMES)
        & (stats["n_issuers"] >= CENTROID_R3_MIN_ISSUERS)
    ]
    return set(zip(hit["_lat"], hit["_lon"]))


def _detect_tier4_broad(df: pd.DataFrame) -> set[tuple[float, float]]:
    """0.01deg grid (~1 km): >= 8 assets with < 15% unique coords."""
    tmp = df.assign(
        _lat=df["LATITUDE"].round(2), _lon=df["LONGITUDE"].round(2),
    )
    stats = (
        tmp.groupby(["_lat", "_lon"])
        .agg(n_assets=("ASSET_ID", "count"), n_uniq=("LATITUDE", "nunique"))
        .reset_index()
    )
    stats["ratio"] = stats["n_uniq"] / stats["n_assets"]
    hit = stats[
        (stats["n_assets"] >= CENTROID_BROAD_MIN_ASSETS)
        & (stats["ratio"] < CENTROID_BROAD_MAX_UNIQUE_RATIO)
    ]
    return set(zip(hit["_lat"], hit["_lon"]))


def _detect_colocated(df: pd.DataFrame) -> set[tuple[float, float]]:
    """Same-building safety valve: <= 2 issuers AND <= 2 names at a coordinate."""
    stats = _agg_coords(df)
    hit = stats[
        (stats["n_assets"] >= COLOCATED_MIN_ASSETS)
        & (stats["n_issuers"] <= COLOCATED_MAX_ISSUERS)
        & (stats["n_names"] <= COLOCATED_MAX_NAMES)
    ]
    return set(zip(hit["LATITUDE"], hit["LONGITUDE"]))


# ── Same-issuer exact coordinate duplicate ────────────────────────────────────

def _detect_same_issuer_dupes(df: pd.DataFrame) -> set[tuple[str, float, float]]:
    """Flag (ISSUER_ID, lat, lon) triples where one issuer placed 2+ differently
    named assets at the exact same coordinate."""
    stats = (
        df.groupby(["ISSUER_ID", "LATITUDE", "LONGITUDE"])
        .agg(
            n_assets=("ASSET_ID", "count"),
            n_names=("LOCATION_NAME", "nunique"),
        )
        .reset_index()
    )
    hit = stats[
        (stats["n_assets"] >= SAME_ISSUER_MIN_ASSETS)
        & (stats["n_names"] >= SAME_ISSUER_MIN_NAMES)
    ]
    return set(zip(hit["ISSUER_ID"], hit["LATITUDE"], hit["LONGITUDE"]))


# ── Core: flag every row ──────────────────────────────────────────────────────

def flag_centroid_fallback(df: pd.DataFrame) -> pd.DataFrame:
    """Add IS_CENTROID_FALLBACK and IS_SAME_ISSUER_COORD_DUPE columns.

    IS_CENTROID_FALLBACK:
        True = geocoder likely fell back to a centroid (bad coordinate).
    IS_SAME_ISSUER_COORD_DUPE:
        True = same issuer has 2+ differently named assets at exact same coord.

    Returns a copy; the original is not modified.
    """
    df = df.copy()

    # ── Multi-entity centroid detection ──
    exact_set = _detect_tier1_exact(df)
    r4_set = _detect_tier2_r4(df)
    r3_set = _detect_tier3_r3(df)
    broad_set = _detect_tier4_broad(df)
    coloc_set = _detect_colocated(df)

    lat = df["LATITUDE"]
    lon = df["LONGITUDE"]
    lat_r4, lon_r4 = lat.round(4), lon.round(4)
    lat_r3, lon_r3 = lat.round(3), lon.round(3)
    lat_r2, lon_r2 = lat.round(2), lon.round(2)

    in_exact = list(zip(lat, lon))
    in_r4 = list(zip(lat_r4, lon_r4))
    in_r3 = list(zip(lat_r3, lon_r3))
    in_broad = list(zip(lat_r2, lon_r2))

    is_centroid = [
        (e in exact_set) or (r4 in r4_set) or (r3 in r3_set) or (b in broad_set)
        for e, r4, r3, b in zip(in_exact, in_r4, in_r3, in_broad)
    ]
    is_colocated = [(lat, lon) in coloc_set for lat, lon in in_exact]

    df["IS_CENTROID_FALLBACK"] = [
        cent and not coloc for cent, coloc in zip(is_centroid, is_colocated)
    ]

    tiers = []
    for e, r4, r3, b in zip(in_exact, in_r4, in_r3, in_broad):
        if e in exact_set:
            tiers.append("EXACT")
        elif r4 in r4_set:
            tiers.append("R4_~11m")
        elif r3 in r3_set:
            tiers.append("R3_~110m")
        elif b in broad_set:
            tiers.append("BROAD_~1km")
        else:
            tiers.append(None)
    df["CENTROID_TIER"] = tiers

    # ── Same-issuer coordinate duplicate ──
    issuer_dupe_set = _detect_same_issuer_dupes(df)
    df["IS_SAME_ISSUER_COORD_DUPE"] = [
        (iid, la, lo) in issuer_dupe_set
        for iid, la, lo in zip(df["ISSUER_ID"], df["LATITUDE"], df["LONGITUDE"])
    ]

    return df


# ── Report ────────────────────────────────────────────────────────────────────

def print_report(df: pd.DataFrame) -> None:
    total = len(df)
    n_centroid = df["IS_CENTROID_FALLBACK"].sum()
    n_issuer_dupe = df["IS_SAME_ISSUER_COORD_DUPE"].sum()
    n_either = ((df["IS_CENTROID_FALLBACK"]) | (df["IS_SAME_ISSUER_COORD_DUPE"])).sum()

    sep = "=" * 60

    # ── Section 1: Centroid Fallback ──
    print(f"\n{sep}")
    print("  1. CENTROID FALLBACK (multi-entity)")
    print(sep)
    print(f"  Total assets:      {total:>6,}")
    print(f"  Centroid fallback:  {n_centroid:>5,}  ({n_centroid/total*100:.1f}%)")

    if n_centroid > 0:
        fb = df[df["IS_CENTROID_FALLBACK"]]
        tier_counts = fb["CENTROID_TIER"].value_counts()
        print(f"\n  By detection tier:")
        for tier, count in tier_counts.items():
            print(f"    {tier:>12s}: {count:,}")

        print(f"\n  Top clusters:")
        top = (
            fb.groupby(["LATITUDE", "LONGITUDE"])
            .agg(
                n=("ASSET_ID", "count"),
                names=("LOCATION_NAME", "nunique"),
                issuers=("ISSUER_ID", "nunique"),
                sample=("LOCATION_NAME", "first"),
            )
            .sort_values("n", ascending=False)
            .head(10)
        )
        for (lat, lon), row in top.iterrows():
            print(f"    ({lat:>10.5f}, {lon:>11.5f}) "
                  f"→ {row['n']:>3} assets, {row['names']} names, "
                  f"{row['issuers']} issuers  e.g. {str(row['sample'])[:55]}")
    else:
        print(f"\n  No centroid fallback cases detected.")

    # ── Section 2: Same-Issuer Coordinate Duplicates ──
    print(f"\n{sep}")
    print("  2. SAME-ISSUER COORDINATE DUPLICATES")
    print(sep)
    print(f"  Flagged assets:    {n_issuer_dupe:>5,}  ({n_issuer_dupe/total*100:.1f}%)")

    if n_issuer_dupe > 0:
        sid = df[df["IS_SAME_ISSUER_COORD_DUPE"]]
        top_issuers = (
            sid.groupby(["ISSUER_ID", "LATITUDE", "LONGITUDE"])
            .agg(
                n=("ASSET_ID", "count"),
                names=("LOCATION_NAME", "nunique"),
                sample=("LOCATION_NAME", "first"),
            )
            .sort_values("n", ascending=False)
            .head(10)
            .reset_index()
        )
        print(f"\n  Top issuer-coordinate clusters:")
        for _, row in top_issuers.iterrows():
            print(f"    {str(row['ISSUER_ID']):>22s}  ({row['LATITUDE']:>9.5f}, {row['LONGITUDE']:>10.5f}) "
                  f"→ {row['n']:>3} assets, {row['names']} names  "
                  f"e.g. {str(row['sample'])[:45]}")
    else:
        print(f"\n  No same-issuer coordinate duplicates detected.")

    # ── Summary ──
    print(f"\n{sep}")
    print(f"  SUMMARY")
    print(sep)
    print(f"  Flagged by either check: {n_either:>5,}  ({n_either/total*100:.1f}%)")
    print(f"  Clean:                   {total - n_either:>5,}  ({(total - n_either)/total*100:.1f}%)")
    print(sep)


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Flag centroid fallback cases in collected asset data.",
    )
    parser.add_argument("input_file", help="Path to .xlsx / .csv / .parquet")
    parser.add_argument(
        "--export", metavar="FILE",
        help="Export full dataset with IS_CENTROID_FALLBACK column added",
    )
    args = parser.parse_args()

    df = load_file(args.input_file)
    print(f"Loaded {len(df):,} rows from {args.input_file}")

    df = flag_centroid_fallback(df)
    print_report(df)

    if args.export:
        out = Path(args.export)
        if out.suffix == ".csv":
            df.to_csv(out, index=False)
        else:
            df.to_excel(out, index=False)
        print(f"Exported {len(df):,} rows to {out}")
