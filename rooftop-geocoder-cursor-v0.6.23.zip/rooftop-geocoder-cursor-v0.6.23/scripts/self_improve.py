#!/usr/bin/env python3
"""
self_improve.py — manually-gated reflection over completed runs (SKILL.md §8.5).

Parameter-free experiential learning (Reflexion / ExpeL style): it distils durable, *actionable*
patterns from a run's OWN trajectory (`results.jsonl`) and writes a human-readable PROPOSED_UPDATES.md
plus ready-to-paste candidate fingerprints. It is human-gated **by construction**:

    * it ONLY PROPOSES — it never edits the KB, geo_convert, KNOWN_CENTROIDS, the §0 contract, or Pass C.
    * it improves the "how to find" layer only (KB / fingerprints / query heuristics); the "how to
      verify" layer (the satellite gate + contract) is frozen and out of scope.
    * a human reviews PROPOSED_UPDATES.md and merges whatever is worth keeping.

Usage:
    python self_improve.py RESULTS [--input INPUT.csv] [--out PROPOSED_UPDATES.md]
        RESULTS : a *_results*.jsonl file OR a results/ directory (merged, last-write-wins on FACILITY_ID)
"""
import sys, os, json, glob, argparse, math
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import geo_convert as gc
    KNOWN = list(getattr(gc, "KNOWN_CENTROIDS", []))
    hav = gc.haversine_m
except Exception:
    KNOWN = []
    def hav(a, b, c, d):
        R = 6371000.0; p = math.pi / 180
        return 2 * R * math.asin(math.sqrt(
            math.sin((c - a) * p / 2) ** 2 + math.cos(a * p) * math.cos(c * p) * math.sin((d - b) * p / 2) ** 2))


def load(path):
    files = sorted(glob.glob(os.path.join(path, "*_results*.jsonl"))) if os.path.isdir(path) else [path]
    by = {}
    for fp in files:
        with open(fp, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    r = json.loads(line); by[str(r.get("FACILITY_ID"))] = r
    return list(by.values())


def num(x):
    try: return float(x)
    except (TypeError, ValueError): return None


def near_known(lat, lng, r=200.0):
    return any(hav(lat, lng, clat, clng) <= r for clat, clng, _ in KNOWN)


def pct(a, b):
    return f"{(100.0 * a / b):.1f}%" if b else "—"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--input", default=None)            # accepted for symmetry; region read if present
    ap.add_argument("--out", default="PROPOSED_UPDATES.md")
    a = ap.parse_args()

    rows = load(a.results)
    n = len(rows)
    if not n:
        print("no rows"); sys.exit(0)

    status = Counter((r.get("STATUS") or "(blank)") for r in rows)
    reasons = Counter((r.get("REVIEW_REASON") or "").split(":")[0].strip()
                      for r in rows if (r.get("REVIEW_REASON") or "").strip())

    # COORD_SOURCE reliability against the satellite gate
    src = defaultdict(lambda: [0, 0])   # source -> [pass, fail]
    for r in rows:
        sv = (r.get("SATELLITE_VERDICT") or "").strip()
        s = (r.get("COORD_SOURCE") or "?").strip() or "?"
        if sv == "pass": src[s][0] += 1
        elif sv == "fail": src[s][1] += 1

    # Pass-B ladder: which final rung correlates with which outcome
    ladder = defaultdict(Counter)
    for r in rows:
        lt = (r.get("LADDER_TRIED") or "").strip()
        if lt:
            ladder[lt.split(";")[-1].strip() or "?"][(r.get("STATUS") or "?")] += 1

    # Candidate centroid fingerprints: coords explicitly centroid-flagged OR reused across >=3 unrelated
    # rows, that are NOT already within 200 m of a KNOWN_CENTROID. Proposed for review, never auto-added.
    by_coord = defaultdict(list)
    for r in rows:
        lat, lng = num(r.get("LATITUDE")), num(r.get("LONGITUDE"))
        if lat is not None and lng is not None:
            by_coord[(round(lat, 4), round(lng, 4))].append(r)
    cand = []
    for (lat, lng), rs in by_coord.items():
        flagged = any(str(r.get("IS_CENTROID_FALLBACK")).strip().lower() == "true"
                      or "centroid" in (r.get("REVIEW_REASON") or "").lower() for r in rs)
        issuers = {(r.get("ISSUER_ID") or r.get("COMPANY_NAME") or r.get("ISSUER_NAME") or "?") for r in rs}
        if (flagged or len(rs) >= 3) and not near_known(lat, lng):
            cand.append((lat, lng, len(rs), len(issuers), flagged))
    cand.sort(key=lambda x: (-x[2], -x[3]))

    # BIZ mismatch tally
    biz = sum(1 for r in rows if str(r.get("BIZ_SATELLITE_MISMATCH")).strip().lower() == "true")

    L = []
    L.append("# PROPOSED_UPDATES — manually-gated reflection (review before merging)\n")
    L.append(f"Source: `{a.results}`  ·  rows analysed: **{n}**\n")
    L.append("> This file only PROPOSES. Nothing here changes behaviour until a human merges it into the KB "
             "or `KNOWN_CENTROIDS`. The contract (§0) and the satellite gate (§4) are out of scope by design.\n")

    L.append("\n## 1. Outcome funnel\n")
    for k, c in status.most_common():
        L.append(f"- {k}: {c} ({pct(c, n)})")

    L.append("\n## 2. Where it's getting stuck (top REVIEW_REASONs)\n")
    if reasons:
        for k, c in reasons.most_common(12):
            L.append(f"- `{k}`: {c}")
        L.append("\n*Action: the dominant reasons point to the weakest part of the ladder — consider a "
                 "KB note or a query-heuristic tweak (never a contract/gate change).*")
    else:
        L.append("- (none)")

    L.append("\n## 3. COORD_SOURCE reliability (satellite pass vs fail)\n")
    L.append("| source | pass | fail | pass-rate |")
    L.append("|---|---|---|---|")
    for s, (p, f) in sorted(src.items(), key=lambda kv: -(kv[1][0] + kv[1][1])):
        L.append(f"| {s} | {p} | {f} | {pct(p, p + f)} |")
    L.append("\n*Action: a source with a low pass-rate is producing weak candidates — tighten how it's "
             "used in Pass A/B (still verified by Pass C either way).*")

    L.append("\n## 4. Pass-B ladder effectiveness (final rung → outcome)\n")
    if ladder:
        for rung, out in sorted(ladder.items(), key=lambda kv: -sum(kv[1].values())):
            tot = sum(out.values())
            res = out.get("resolved", 0) + out.get("resolved_pending_qa", 0)
            L.append(f"- `{rung}`: {tot} rows, {pct(res, tot)} reached a candidate "
                     f"({dict(out)})")
        L.append("\n*Action: rungs that rarely reach a candidate may be reordered or dropped; rungs that "
                 "reliably win are worth leading with for similar rows.*")
    else:
        L.append("- (no LADDER_TRIED recorded)")

    L.append(f"\n## 5. Activity mismatches\n- BIZ_SATELLITE_MISMATCH rows: {biz} "
             f"({pct(biz, n)}) — precise coords retained, awaiting adjudication.\n")

    L.append("\n## 6. Candidate centroid fingerprints (review, then paste into `geo_convert.KNOWN_CENTROIDS`)\n")
    if cand:
        L.append("These coordinates were centroid-flagged or reused across unrelated rows, and are NOT "
                 "already within 200 m of a known centroid. **Review each** (confirm it really is a "
                 "centroid, not a legitimately shared building) before pasting:\n")
        L.append("```python")
        for lat, lng, k, iss, flagged in cand[:25]:
            why = "explicit-flag" if flagged else f"reused {k}× across {iss} issuers"
            L.append(f'    ({lat}, {lng}, "auto-proposed: {why} — VERIFY"),')
        L.append("```")
        L.append("\n*Gate: paste only the ones you've confirmed. Promotion is never automatic.*")
    else:
        L.append("- none (no recurring/flagged coordinates beyond what's already known)")

    L.append("\n## 7. Agent reflection (optional, append-only)\n")
    L.append("If a person ran a reflection pass, durable prose lessons go here for human review — e.g. a "
             "newly observed trap, a query pattern that worked for a tricky issuer type, a region quirk. "
             "Keep them concrete and actionable; they are candidates for the KB, not auto-applied rules.\n")

    out = a.out
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print(f"wrote {out}  ({n} rows; {len(cand)} candidate fingerprints, {len(reasons)} distinct reasons)")
    print("REVIEW it and merge by hand — nothing is applied automatically.")


if __name__ == "__main__":
    main()
