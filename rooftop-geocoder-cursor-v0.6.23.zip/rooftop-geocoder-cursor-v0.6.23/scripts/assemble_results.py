#!/usr/bin/env python3
"""
assemble_results.py — merge geocoding results into the input file -> final workbook, any time.

    python3 assemble_results.py INPUT RESULTS OUTPUT

RESULTS may be a single `<BASE>_results.jsonl` OR a directory (all `*_results.jsonl` in it are
combined — for the case where sessions wrote separate shards instead of one shared file).

Keys on the stable FACILITY_ID (case-insensitive), so a partial deliverable can be produced at
any checkpoint and re-running can never misalign a coordinate to the wrong row. Carries the v0.5
evidence columns. Last record per FACILITY_ID wins (field-merged).
"""
import sys, os, json, glob
import pandas as pd

APPEND = ["COORD_SOURCE", "COORD_DATUM", "PRECISION_TIER", "MATCH_CONFIDENCE", "RESOLUTION_QUERY",
          "EVIDENCE_SOURCE", "MATCH_PLACE_NAME", "MATCH_PLACE_ID", "LADDER_TRIED",
          "SATELLITE_VERDICT", "SATELLITE_NOTE", "BIZ_SATELLITE_MISMATCH", "STATUS", "REVIEW_REASON",
          "IS_CENTROID_FALLBACK", "CENTROID_TIER", "SESSION_N",
          "FACILITY_ADDRESS_NATIVE", "FACILITY_NAME_NATIVE", "CITY_NATIVE", "STATE_NATIVE", "ISSUER_NAME_NATIVE"]


def rid(r):
    for k in ("FACILITY_ID", "facility_id", "ROW_ID", "row_id"):
        if k in r and r[k] is not None:
            return str(r[k]).strip()
    return ""


def cget(r, *keys):
    for k in keys:
        if k in r and r[k] is not None:
            return r[k]
    return None


def load_records(path):
    files = sorted(glob.glob(os.path.join(path, "*_results*.jsonl"))) if os.path.isdir(path) else [path]
    recs = {}
    for fp in files:
        with open(fp) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                r = json.loads(line)
                fid = rid(r)
                if fid:
                    recs.setdefault(fid, {}).update(r)
    return recs, files


def _truthy(x):
    return str(x).strip().lower() == "true"

def _colorize(out, df):
    """Amber = activity-mismatch (precise coord retained); Red = wrong-location fail or centroid."""
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import PatternFill
    except Exception:
        return
    amber = PatternFill("solid", fgColor="FFE08A")   # activity mismatch — coord retained
    red   = PatternFill("solid", fgColor="F4A6A6")   # wrong location / centroid — coord not trustworthy
    cols = list(df.columns)
    wb = load_workbook(out); ws = wb.active
    for i, (_, r) in enumerate(df.iterrows(), start=2):   # row 1 = header
        reason = ("" if pd.isna(r.get("REVIEW_REASON")) else str(r.get("REVIEW_REASON"))).lower()
        biz = _truthy(r.get("BIZ_SATELLITE_MISMATCH"))
        centroid = _truthy(r.get("IS_CENTROID_FALLBACK")) or "centroid" in reason
        wrong_loc = ("satellite_fail" in reason) or centroid
        fill = amber if biz else (red if wrong_loc else None)
        if fill:
            for c in range(1, len(cols) + 1):
                ws.cell(row=i, column=c).fill = fill
    wb.save(out)

def main():
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    inp, res, out = sys.argv[1], sys.argv[2], sys.argv[3]
    df = pd.read_excel(inp) if inp.lower().endswith((".xlsx", ".xls")) else pd.read_csv(inp)
    idc = next((c for c in df.columns if c.lower() in ("facility_id", "row_id")), None)
    if not idc:
        raise SystemExit("input has no facility_id / row_id column — cannot key safely")
    df[idc] = df[idc].astype(str)
    latc = next((c for c in df.columns if c.lower() == "latitude"), "latitude")
    lngc = next((c for c in df.columns if c.lower() == "longitude"), "longitude")
    for c in (latc, lngc):
        if c not in df.columns:
            df[c] = pd.NA
    for c in APPEND:
        if c not in df.columns:
            df[c] = pd.NA
    # the input may have typed these (e.g. numeric LATITUDE/LONGITUDE when rows already carry coords);
    # cast every write-target column to object so string values from results.jsonl assign cleanly
    for c in [latc, lngc] + APPEND:
        df[c] = df[c].astype(object)

    recs, files = load_records(res)
    n = 0
    for i, fid in df[idc].items():
        r = recs.get(str(fid))
        if not r:
            continue
        n += 1
        lat, lng = cget(r, "LATITUDE", "latitude"), cget(r, "LONGITUDE", "longitude")
        if lat is not None:
            df.at[i, latc] = lat
        if lng is not None:
            df.at[i, lngc] = lng
        for c in APPEND:
            val = cget(r, c)
            if val is not None:
                df.at[i, c] = val

    df.to_excel(out, index=False)
    _colorize(out, df)
    print(f"merged {n}/{len(df)} rows on {idc} from {len(files)} file(s) -> {out}")
    if "STATUS" in df.columns:
        print("STATUS counts:\n" + df["STATUS"].fillna("(todo)").value_counts().to_string())


if __name__ == "__main__":
    main()
