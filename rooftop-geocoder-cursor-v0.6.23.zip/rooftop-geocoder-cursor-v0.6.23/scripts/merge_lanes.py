"""Recombine the per-lane results after all phases into one workbook.

  python scripts/merge_lanes.py <input.csv|.xlsx> <output.xlsx> <results1.jsonl> <results2.jsonl> [results3 ...]

Field-merges every lane's results by FACILITY_ID (last-write-wins across files), writes a combined
`<input-base>_results.jsonl` next to the output, runs the §0 validator on it, then assembles the
workbook. The China lane and the non-China lanes are disjoint by construction, so the merge is just a
union; if the same FACILITY_ID ever appears twice, the later file wins (pass a more-complete lane last).

Dataset-level steps belong here, on the merged file — never per lane.
"""
import sys, os, json, subprocess


def main():
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    inp, out = sys.argv[1], sys.argv[2]
    result_files = sys.argv[3:]
    here = os.path.dirname(os.path.abspath(__file__))

    merged = {}
    n_lines = 0
    for fp in result_files:
        if not os.path.exists(fp):
            raise SystemExit(f"missing results file: {fp}")
        with open(fp, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                r = json.loads(line)
                fid = None
                for k in ("FACILITY_ID", "facility_id", "ROW_ID", "row_id"):
                    if r.get(k) is not None:
                        fid = str(r[k]).strip()
                        break
                if fid:
                    merged.setdefault(fid, {}).update(r)   # last write wins, field-merged
                    n_lines += 1

    base = os.path.splitext(os.path.basename(inp))[0]
    merged_path = os.path.join(os.path.dirname(os.path.abspath(out)), f"{base}_results.jsonl")
    with open(merged_path, "w", encoding="utf-8") as f:
        for fid, rec in merged.items():
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"merged {n_lines} lines from {len(result_files)} lanes → {len(merged)} unique FACILITY_IDs")
    print(f"  combined results: {merged_path}")

    # §0 validation gate (hard) on the merged file
    print("validating (§0 gate)…")
    v = subprocess.run([sys.executable, os.path.join(here, "validate_results.py"), merged_path])
    if v.returncode != 0:
        raise SystemExit("validation FAILED on the merged file — fix before assembling (see output above).")

    # assemble the final workbook
    print("assembling workbook…")
    subprocess.run([sys.executable, os.path.join(here, "assemble_results.py"), inp, merged_path, out], check=True)
    print(f"done → {out}")


if __name__ == "__main__":
    main()
