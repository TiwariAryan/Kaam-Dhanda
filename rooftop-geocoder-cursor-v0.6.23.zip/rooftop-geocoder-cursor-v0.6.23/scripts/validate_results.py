#!/usr/bin/env python3
"""
validate_results.py — enforce the §0 CONTRACT on a rooftop-geocoder results file.

    python scripts/validate_results.py FS_DIR/results/<BASE>_results.jsonl \
        [--input INPUT_PATH] [--report report.md] [--gold-exemption]

Exits 1 (blocking) if ANY of these hold, listing every offender:
  * a row marked STATUS=resolved lacks a coordinate, RESOLUTION_QUERY, EVIDENCE_SOURCE,
    or SATELLITE_VERDICT in {pass} (or {pass, exempt_goldstandard} when --gold-exemption);
  * a processed row has no STATUS, or a STATUS outside the allowed set;
  * a non-resolved row has no REVIEW_REASON;
  * a row with coordinates falls outside its country bbox (needs --input for FACILITY_REGION).

This is the gate that makes "I skipped satellite to save budget" structurally impossible:
such a row simply cannot be `resolved`.
"""
import sys, os, json, argparse
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import geo_convert as gc
except Exception:
    gc = None

TERMINAL = {"resolved", "manual_review", "not_found"}
ALLOWED = TERMINAL | {"resolved_pending_qa"}
SAT_OK = {"pass"}


def load_jsonl(path):
    import glob
    files = sorted(glob.glob(os.path.join(path, "*_results*.jsonl"))) if os.path.isdir(path) else [path]
    by_id = {}
    for fp in files:
        with open(fp) as f:
            for line in f:
                line = line.strip()
                if line:
                    r = json.loads(line)
                    by_id[str(r.get("FACILITY_ID"))] = r   # last write wins per FACILITY_ID
    return list(by_id.values())


def num(x):
    try:
        v = float(x)
        return v if v == v else None  # NaN guard
    except (TypeError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--input", default=None)
    ap.add_argument("--report", default=None)
    ap.add_argument("--gold-exemption", action="store_true")
    a = ap.parse_args()

    sat_ok = SAT_OK | ({"exempt_goldstandard"} if a.gold_exemption else set())
    recs = load_jsonl(a.results)

    region = {}
    if a.input:
        df = pd.read_excel(a.input) if a.input.lower().endswith((".xlsx", ".xls")) else pd.read_csv(a.input)
        idc = next((c for c in df.columns if c.lower() in ("facility_id", "row_id")), None)
        rc = next((c for c in df.columns if c.lower() in ("facility_region", "region", "country")), None)
        if idc and rc:
            region = {str(k): v for k, v in zip(df[idc], df[rc])}

    v = {"resolved_no_coord": [], "resolved_no_query": [], "resolved_no_source": [],
         "resolved_no_satellite": [], "pending_no_coord": [], "bad_status": [], "no_reason": [],
         "out_of_bbox": [], "china_conversion_suspect": [],
         "resolved_but_biz_mismatch": [], "biz_mismatch": [], "centroid": []}

    n_resolved = n_review = n_nf = n_pending = 0
    for r in recs:
        fid = str(r.get("FACILITY_ID"))
        st = (r.get("STATUS") or "").strip()
        lat, lng = num(r.get("LATITUDE")), num(r.get("LONGITUDE"))
        if str(r.get("BIZ_SATELLITE_MISMATCH")).strip().lower() == "true":
            v["biz_mismatch"].append(fid)
        if str(r.get("IS_CENTROID_FALLBACK")).strip().lower() == "true" or "centroid" in (r.get("REVIEW_REASON") or "").lower():
            v["centroid"].append(fid)

        if st not in ALLOWED:
            v["bad_status"].append((fid, st or "(blank)")); continue
        n_resolved += st == "resolved"; n_review += st == "manual_review"
        n_nf += st == "not_found"; n_pending += st == "resolved_pending_qa"

        if st == "resolved":
            if lat is None or lng is None: v["resolved_no_coord"].append(fid)
            if not (r.get("RESOLUTION_QUERY") or "").strip(): v["resolved_no_query"].append(fid)
            if not (r.get("EVIDENCE_SOURCE") or "").strip(): v["resolved_no_source"].append(fid)
            if (r.get("SATELLITE_VERDICT") or "").strip() not in sat_ok:
                v["resolved_no_satellite"].append(fid)
            if str(r.get("BIZ_SATELLITE_MISMATCH")).strip().lower() == "true":
                v["resolved_but_biz_mismatch"].append(fid)
        elif st in ("manual_review", "not_found"):
            if not (r.get("REVIEW_REASON") or "").strip():
                v["no_reason"].append((fid, st))
        elif st == "resolved_pending_qa":
            # a pending row is a coordinate awaiting satellite check; no coordinate => it should be manual_review
            if lat is None or lng is None:
                v["pending_no_coord"].append(fid)

        # bbox sanity check (soft) — any row carrying a coordinate
        if lat is not None and lng is not None and gc and fid in region:
            try:
                res = gc.validate_point(lat, lng, region[fid])
                if res.get("in_country") is False:   # None = region not bounded -> skip
                    v["out_of_bbox"].append((fid, region[fid], round(lat, 5), round(lng, 5)))
            except Exception:
                pass

        # China datum check (soft) — COORD_RAW present means a China reading was converted; verify it ran
        raw = (r.get("COORD_RAW") or "").strip()
        if raw and lat is not None and lng is not None and gc:
            try:
                rlat, rlng = [float(x) for x in raw.replace(" ", "").split(",")[:2]]
                chk = gc.china_conversion_plausible(rlat, rlng, lat, lng)
                if not chk["ran"]:   # shift < 50 m => GCJ/BD-09 -> WGS-84 conversion almost certainly skipped
                    v["china_conversion_suspect"].append((fid, f"shift={chk['shift_m']}m"))
            except Exception:
                pass

    HARD = ["resolved_no_coord", "resolved_no_query", "resolved_no_source",
            "resolved_no_satellite", "pending_no_coord", "bad_status", "no_reason",
            "resolved_but_biz_mismatch"]
    SOFT = ["out_of_bbox", "china_conversion_suspect", "biz_mismatch", "centroid"]
    n_hard = sum(len(v[k]) for k in HARD)
    n_soft = sum(len(v[k]) for k in SOFT)
    lines = []
    lines.append("# rooftop-geocoder — validation report")
    lines.append(f"\nrecords: {len(recs)}  |  resolved={n_resolved} pending_qa={n_pending} "
                 f"manual_review={n_review} not_found={n_nf}")
    lines.append(f"gold-exemption: {'ON' if a.gold_exemption else 'OFF'}")
    labels = {
        "resolved_no_coord": "resolved without a coordinate",
        "resolved_no_query": "resolved without RESOLUTION_QUERY",
        "resolved_no_source": "resolved without EVIDENCE_SOURCE",
        "resolved_no_satellite": "resolved without SATELLITE_VERDICT=pass",
        "pending_no_coord": "resolved_pending_qa without a coordinate (should be manual_review)",
        "bad_status": "blank / disallowed STATUS",
        "no_reason": "non-resolved without REVIEW_REASON",
        "out_of_bbox": "coordinate outside country bbox (review)",
        "resolved_but_biz_mismatch": "resolved row flagged BIZ_SATELLITE_MISMATCH (a mismatch cannot be resolved)",
        "biz_mismatch": "activity-mismatch rows — precise coordinate retained, held for adjudication (review)",
        "centroid": "centroid-flagged rows — coordinate retained, route to Phase D (review)",
        "china_conversion_suspect": "China COORD_RAW≈output — GCJ/BD-09→WGS-84 conversion may not have run (review)",
    }
    lines.append(f"\n## HARD contract violations (block the build): {n_hard}\n")
    for k in HARD:
        items = v[k]
        lines.append(f"- **{labels[k]}**: {len(items)}")
        for it in items[:25]:
            lines.append(f"    - {it}")
        if len(items) > 25:
            lines.append(f"    - … +{len(items)-25} more")
    lines.append(f"\n## SOFT warnings (flag for review, do not block): {n_soft}\n")
    for k in SOFT:
        items = v[k]
        lines.append(f"- **{labels[k]}**: {len(items)}")
        for it in items[:25]:
            lines.append(f"    - {it}")
        if len(items) > 25:
            lines.append(f"    - … +{len(items)-25} more")

    if n_pending:
        lines.append(f"\n> note: {n_pending} rows are `resolved_pending_qa` — Pass C (satellite) "
                     f"has not run on them yet; they are not counted as resolved.")

    report = "\n".join(lines)
    print(report)
    if a.report:
        with open(a.report, "w") as f:
            f.write(report + "\n")
        print(f"\nwrote {a.report}")

    if n_hard:
        print(f"\nVALIDATION FAILED — {n_hard} hard violation(s). Output is not contract-clean.")
        sys.exit(1)
    msg = "VALIDATION PASSED — every resolved row carries full evidence."
    if n_soft:
        msg += f" ({n_soft} soft bbox warning(s) to review.)"
    print("\n" + msg)


if __name__ == "__main__":
    main()
