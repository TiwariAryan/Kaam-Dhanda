"""Split an input file into region-routed lanes for a parallel run.

Produces, in --out-dir (default: alongside the input):
  <BASE>_cn.csv   mainland China ONLY  (COUNTRY_ISO3 == 'CHN', EXACT match)
  <BASE>_w1.csv   non-China, issuer-balanced half 1
  <BASE>_w2.csv   non-China, issuer-balanced half 2   (more halves with --lanes N)

Then MANUALLY move each file into the matching skill-folder copy's inputs/ and run the phases there.
After all phases, recombine with scripts/merge_lanes.py.

IMPORTANT — the China filter is EXACT on COUNTRY_ISO3 == 'CHN'. Do NOT filter by
FACILITY_REGION containing "China": Taiwan's upstream legal region is "Taiwan (Province of
China)" (ISO3 = TWN) and would be wrongly swept into the Baidu lane. HKG / MAC / TWN all have
their own ISO3 values and correctly stay in the non-China lanes.

Non-China rows are split so that **all rows of one issuer land in the same lane** (greedy balance
by ISSUER_ID/ISSUER_NAME) — this preserves the issuer-clustering win (one company page resolves
many rows in a single lane).

Usage:
  python scripts/split_for_lanes.py <input.csv|.xlsx> [--out-dir DIR] [--cn-iso3 CHN] [--lanes 2]
"""
import sys, os, argparse
import pandas as pd


def _col(df, *names):
    low = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--cn-iso3", default="CHN", help="exact COUNTRY_ISO3 value for mainland China")
    ap.add_argument("--lanes", type=int, default=2, help="number of non-China lanes")
    a = ap.parse_args()

    base = os.path.splitext(os.path.basename(a.input))[0]
    out = a.out_dir or os.path.dirname(os.path.abspath(a.input))
    os.makedirs(out, exist_ok=True)
    df = pd.read_excel(a.input) if a.input.lower().endswith((".xlsx", ".xls")) else pd.read_csv(a.input)

    isoc = _col(df, "COUNTRY_ISO3", "country_iso3", "iso3")
    if not isoc:
        raise SystemExit("input has no COUNTRY_ISO3 column — cannot route China safely; aborting.")

    iso = df[isoc].astype(str).str.strip().str.upper()
    cn_mask = iso.eq(a.cn_iso3.upper())          # EXACT — never 'contains China'
    cn = df[cn_mask]
    rest = df[~cn_mask].reset_index(drop=True)

    # issuer-balanced split of the non-China rows: keep each issuer together
    issc = _col(rest, "ISSUER_ID", "ISSUER_NAME", "COMPANY_NAME")
    lanes = [[] for _ in range(a.lanes)]
    sizes = [0] * a.lanes
    if issc:
        groups = sorted(rest.groupby(rest[issc].astype(str)), key=lambda kv: -len(kv[1]))
        for _, g in groups:
            i = sizes.index(min(sizes))          # assign to the currently-smallest lane
            lanes[i].append(g)
            sizes[i] += len(g)
        lane_dfs = [pd.concat(p).sort_index() if p else rest.iloc[0:0] for p in lanes]
    else:                                        # no issuer column → plain contiguous halves
        n = len(rest)
        edges = [round(n * k / a.lanes) for k in range(a.lanes + 1)]
        lane_dfs = [rest.iloc[edges[k]:edges[k + 1]] for k in range(a.lanes)]

    cn_path = os.path.join(out, f"{base}_cn.csv")
    cn.to_csv(cn_path, index=False)
    print(f"  {base}_cn.csv   {len(cn):5d} rows  (mainland China, ISO3=={a.cn_iso3.upper()})")
    for k, ldf in enumerate(lane_dfs, 1):
        p = os.path.join(out, f"{base}_w{k}.csv")
        ldf.to_csv(p, index=False)
        nis = ldf[issc].astype(str).nunique() if issc else "n/a"
        print(f"  {base}_w{k}.csv   {len(ldf):5d} rows  ({nis} issuers)")

    total = len(cn) + sum(len(x) for x in lane_dfs)
    assert total == len(df), f"row count mismatch: {total} != {len(df)}"
    # also report what would have been mis-routed by a naive contains filter, as a sanity note
    regc = _col(df, "FACILITY_REGION")
    if regc is not None:
        naive = df[regc].astype(str).str.contains("china", case=False, na=False) & ~cn_mask
        if int(naive.sum()):
            print(f"  note: {int(naive.sum())} non-mainland rows contain 'China' in FACILITY_REGION "
                  f"(e.g. Taiwan) and were correctly kept OUT of the China lane.")
    print(f"  total {total} rows split into 1 China + {a.lanes} non-China lanes → {out}")


if __name__ == "__main__":
    main()
