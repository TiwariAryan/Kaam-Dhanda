"""
Krung Thai Bank — Export Script
Combines domestic branches + overseas offices -> XLSX + CSV
"""
import sys, json, re, csv
from pathlib import Path
from bs4 import BeautifulSoup
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

sys.stdout.reconfigure(encoding='utf-8')

COLUMNS = [
    'FACILITY_NAME', 'FACILITY_ADDRESS', 'CITY', 'STATE',
    'POSTAL_CODE', 'FACILITY_REGION', 'LATITUDE', 'LONGITUDE',
    'FACILITY_CONTACT_NUMBER', 'RELEVANT_URL', 'BUSINESS_ACTIVITY'
]

OUT_DIR = Path('krung_thai_bank_output')
OUT_DIR.mkdir(exist_ok=True)

ISSUER = "Krung Thai Bank Public Company Limited"


# ── Parse domestic branches from raw JSON ───────────────────────────────────

def load_domestic():
    with open(OUT_DIR / 'ktb_raw.json', encoding='utf-8') as f:
        raw = json.load(f)
    
    records = []
    for r in raw:
        rec = {
            'FACILITY_NAME': r.get('FACILITY_NAME', '').strip(),
            'FACILITY_ADDRESS': r.get('FACILITY_ADDRESS', '').strip(),
            'CITY': r.get('CITY', '').strip(),
            'STATE': r.get('STATE', '').strip(),
            'POSTAL_CODE': r.get('POSTAL_CODE', '').strip(),
            'FACILITY_REGION': 'Thailand',
            'LATITUDE': r.get('LATITUDE') or '',
            'LONGITUDE': r.get('LONGITUDE') or '',
            'FACILITY_CONTACT_NUMBER': r.get('FACILITY_CONTACT_NUMBER', '').strip(),
            'RELEVANT_URL': r.get('RELEVANT_URL', '').strip(),
            'BUSINESS_ACTIVITY': 'Banking',
        }
        records.append(rec)
    return records


# ── Parse foreign branch page HTML ───────────────────────────────────────────

COUNTRY_MAP = {
    "The People's Republic of China": "China",
    "India": "India",
    "Singapore": "Singapore",
    "Cambodia": "Cambodia",
    "People's Democratic Republic of Laos": "Laos",
    "Myanmar": "Myanmar",
    "The United Kingdom": "United Kingdom",
    "Cayman Islands": "Cayman Islands",
    "United States of America": "United States of America",
    "Japan": "Japan",
    "Hong Kong": "Hong Kong",
    "Vietnam": "Vietnam",
    "Viet Nam": "Vietnam",
}


def is_country_header(line: str) -> str | None:
    """Return standardized country name if line is a country header, else None."""
    for raw, std in COUNTRY_MAP.items():
        if raw in line and len(line) < 80:
            return std
    return None


def is_phone(line: str) -> bool:
    return (line.startswith('+') or
            re.match(r'^\d{1,4}[-\s]', line) is not None or
            re.match(r'^0-\d', line) is not None)


def is_email(line: str) -> bool:
    return bool('@' in line and '.' in line.split('@')[-1] and ' ' not in line)


SKIP_LINES = {
    'Oversea Offices', 'Overseas Offices', 'Thailand Offices',
    'International Banking Activities', 'See the details',
}

ACTIVITY_FRAGMENTS = {
    'Lending', 'Deposit', 'Remittance', 'Trade Finance', 'Foreign Exchange',
    'Offering financial enquiry services', 'coordinating with Krungthai Group',
}

BRANCH_KEYWORDS = ['Branch', 'Representative', 'Sub-Branch', 'Office']

CLOSED_INDICATORS = ['has ceased', 'ceased to be', 'is no longer', 'unclaimed']


def parse_foreign_branches():
    """
    Hardcoded overseas offices from https://krungthai.com/en/contact-us/foreign-branch
    (as of 2026-03-24). Mumbai Branch is excluded (ceased operations per RBI notification).
    """
    FOREIGN_SOURCE_URL = 'https://krungthai.com/en/contact-us/foreign-branch'
    
    return [
        {
            'FACILITY_NAME': 'Kunming Branch',
            'FACILITY_ADDRESS': '19th Floor Shuncheng East Building, No.11 Dongfeng Road (West), Kunming, Yunnan, China 650032',
            'CITY': 'Kunming',
            'STATE': 'Yunnan',
            'POSTAL_CODE': '650032',
            'FACILITY_REGION': 'China',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+86 (871) 6313-8370',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Singapore Branch',
            'FACILITY_ADDRESS': '65 Chulia Street #32-05/07, OCBC Centre, Singapore 049513',
            'CITY': 'Singapore',
            'STATE': 'Singapore',
            'POSTAL_CODE': '049513',
            'FACILITY_REGION': 'Singapore',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+65 6533-6691',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Phnom Penh Branch',
            'FACILITY_ADDRESS': 'N 149, 215 Road, Sangkat Phsar Depo 1, Khan Toulkok, Phnom Penh, Cambodia',
            'CITY': 'Phnom Penh',
            'STATE': '',
            'POSTAL_CODE': '',
            'FACILITY_REGION': 'Cambodia',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+855 (23) 882-959',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Siem Reap Province Sub-Branch',
            'FACILITY_ADDRESS': '10-11, Sivatha Road, Mondol 2 Khum Svay Dangkom Siem Reap District, Siem Reap Province, Cambodia',
            'CITY': 'Siem Reap',
            'STATE': 'Siem Reap',
            'POSTAL_CODE': '',
            'FACILITY_REGION': 'Cambodia',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+855 (63) 964-758',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Vientiane Branch',
            'FACILITY_ADDRESS': '80 Lanexang Road, B.Xiengngeuanthong M.Chanthabouly, Vientiane, Laos',
            'CITY': 'Vientiane',
            'STATE': 'Vientiane Prefecture',
            'POSTAL_CODE': '',
            'FACILITY_REGION': "Lao People's Democratic Republic",
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+(856-21) 213-480',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Yangon Representative Office',
            'FACILITY_ADDRESS': 'CentrePoint Tower, 7th Floor, No. 65 Corner of Sule Pagoda Road and Merchant Street, Kyauktada Township, Yangon, Myanmar',
            'CITY': 'Yangon',
            'STATE': 'Yangon',
            'POSTAL_CODE': '',
            'FACILITY_REGION': 'Myanmar',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '+95 1 243186',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
        {
            'FACILITY_NAME': 'Cayman Branch',
            'FACILITY_ADDRESS': '190 Elgin Avenue, Grand Cayman KY1-9005, Cayman Islands',
            'CITY': 'Grand Cayman',
            'STATE': '',
            'POSTAL_CODE': 'KY1-9005',
            'FACILITY_REGION': 'Cayman Islands',
            'LATITUDE': '',
            'LONGITUDE': '',
            'FACILITY_CONTACT_NUMBER': '0-2208-3792',
            'RELEVANT_URL': FOREIGN_SOURCE_URL,
            'BUSINESS_ACTIVITY': 'Banking; International Banking',
        },
    ]


# ── Export ───────────────────────────────────────────────────────────────────

def export_xlsx(records: list, path: Path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "KTB Locations"
    
    header_font = Font(bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='003087', end_color='003087', fill_type='solid')
    
    ws.append(COLUMNS)
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    for rec in records:
        row = [rec.get(col, '') for col in COLUMNS]
        ws.append(row)
    
    # Auto-fit columns
    for col in ws.columns:
        max_len = max((len(str(cell.value or '')) for cell in col), default=0)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 60)
    
    wb.save(path)
    print(f"Saved XLSX: {path}")


def export_csv(records: list, path: Path):
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(records)
    print(f"Saved CSV: {path}")


def quality_report(records: list):
    total = len(records)
    print(f"\n{'='*60}")
    print(f"QUALITY REPORT — {ISSUER}")
    print(f"{'='*60}")
    print(f"Total records: {total}")
    for col in COLUMNS:
        filled = sum(1 for r in records if r.get(col) not in (None, '', 0))
        pct = 100 * filled // total if total else 0
        bar = '█' * (pct // 5) + '░' * (20 - pct // 5)
        print(f"  {col:<35} {bar} {filled}/{total} ({pct}%)")


def main():
    print(f"Loading domestic branches...")
    domestic = load_domestic()
    print(f"  Loaded {len(domestic)} domestic records")
    
    print(f"\nParsing foreign branches...")
    foreign = parse_foreign_branches()
    print(f"  Parsed {len(foreign)} overseas records:")
    for r in foreign:
        print(f"    - {r['FACILITY_NAME']} [{r['FACILITY_REGION']}]")
    
    all_records = domestic + foreign
    print(f"\nTotal records: {len(all_records)}")
    
    quality_report(all_records)
    
    # Print sample
    print("\nSample records:")
    for r in all_records[:3]:
        print(f"  {r['FACILITY_NAME']} | {r['CITY']}, {r['STATE']} | {r['POSTAL_CODE']} | lat={r['LATITUDE']}")
    
    # Export
    xlsx_path = OUT_DIR / f"krung_thai_bank_final.xlsx"
    csv_path = OUT_DIR / f"krung_thai_bank_final.csv"
    
    export_xlsx(all_records, xlsx_path)
    export_csv(all_records, csv_path)
    
    # Save combined JSON
    json_path = OUT_DIR / 'krung_thai_bank_full.json'
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2, default=str)
    print(f"Saved JSON: {json_path}")
    
    print(f"\n{'='*60}")
    print(f"EXTRACTION COMPLETE")
    print(f"  Domestic branches: {len(domestic)}")
    print(f"  Overseas offices: {len(foreign)}")
    print(f"  Total: {len(all_records)}")
    print(f"  XLSX: {xlsx_path}")
    print(f"  CSV: {csv_path}")


if __name__ == '__main__':
    main()
