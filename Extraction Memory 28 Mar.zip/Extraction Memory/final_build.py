"""
Final comprehensive extraction and CSV builder for Continental AG facilities.
Uses LLM-like structured manual mapping for accuracy.
"""
import json
import csv
import re
import sys
import io
import unicodedata
import requests
import warnings
import time
import openpyxl

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
warnings.filterwarnings('ignore')

# ===== MANUALLY CURATED FACILITY LIST =====
# Based on thorough analysis of all country pages from continental-industry.com
# Each entry is a confirmed real facility (not a contact person)

FACILITIES = [
    # === BRAZIL ===
    {
        "facility_name_native": "Continental do Brasil - Itapevi",
        "facility_name": "Continental do Brasil - Itapevi Plant",
        "address_native": "Rodovia Presidente Castelo Branco, 2.555, KM 32, Itapevi - SP",
        "address": "Rodovia Presidente Castelo Branco, 2.555, KM 32, Itapevi - SP",
        "city": "Itapevi", "state": "SP", "postal_code": "", "country": "Brazil",
        "phone": "", "activity": "Advanced Dynamics Solutions, Surface Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - Ponta Grossa",
        "facility_name": "Continental do Brasil - Ponta Grossa Plant",
        "address_native": "Avenida Continental, 2.777, Distrito Industrial Prefeito Cyro Martins, Ponta Grossa - PR",
        "address": "Avenida Continental, 2.777, Distrito Industrial Prefeito Cyro Martins, Ponta Grossa - PR",
        "city": "Ponta Grossa", "state": "PR", "postal_code": "", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - Belo Horizonte (Main Office)",
        "facility_name": "Continental do Brasil - Belo Horizonte Office",
        "address_native": "Av. Barão Homem de Melo, 4494, Estoril, Belo Horizonte, MG, 30494-270",
        "address": "Av. Barao Homem de Melo, 4494, Estoril, Belo Horizonte, MG, 30494-270",
        "city": "Belo Horizonte", "state": "MG", "postal_code": "30494-270", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - Ouro Preto",
        "facility_name": "Continental do Brasil - Ouro Preto Service Center",
        "address_native": "Polo Industrial de Antônio Pereira, 10, Distrito de Antônio Pereira, Ouro Preto, MG, 35400-000",
        "address": "Polo Industrial de Antonio Pereira, 10, Distrito de Antonio Pereira, Ouro Preto, MG, 35400-000",
        "city": "Ouro Preto", "state": "MG", "postal_code": "35400-000", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - Carajás",
        "facility_name": "Continental do Brasil - Carajas Service Center",
        "address_native": "Rua 04, Quadra 43, Lote 16, 198, Cidade Nova, Parauapebas - PA",
        "address": "Rua 04, Quadra 43, Lote 16, 198, Cidade Nova, Parauapebas - PA",
        "city": "Parauapebas", "state": "PA", "postal_code": "", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - São Luis",
        "facility_name": "Continental do Brasil - Sao Luis Service Center",
        "address_native": "Avenida Engenheiro Emiliano Macieira, 2.000, Pedrinhas, São Luis - MA",
        "address": "Avenida Engenheiro Emiliano Macieira, 2.000, Pedrinhas, Sao Luis - MA",
        "city": "Sao Luis", "state": "MA", "postal_code": "", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    {
        "facility_name_native": "Continental do Brasil - Anchieta",
        "facility_name": "Continental do Brasil - Anchieta Service Center",
        "address_native": "Rodovia do Sol, S/N, Ponta de UBU, Anchieta - ES",
        "address": "Rodovia do Sol, S/N, Ponta de UBU, Anchieta - ES",
        "city": "Anchieta", "state": "ES", "postal_code": "", "country": "Brazil",
        "phone": "", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/brazil",
    },
    # === CHILE ===
    {
        "facility_name_native": "ContiTech Chile S.A.",
        "facility_name": "ContiTech Chile S.A.",
        "address_native": "Camino Lo Ruiz N° 4470, Renca, Santiago, Chile",
        "address": "Camino Lo Ruiz No. 4470, Renca, Santiago, Chile",
        "city": "Santiago", "state": "Renca", "postal_code": "", "country": "Chile",
        "phone": "", "activity": "Conveying Solutions Sales & Service",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/chile",
    },
    {
        "facility_name_native": "ContiTech Chile S.A. - Perú Office",
        "facility_name": "ContiTech Chile S.A. - Peru Office",
        "address_native": "Av. El Derby N° 055, Edificio Cronos, Torre 1 - Piso 7, Santiago de Surco, Lima, Perú",
        "address": "Av. El Derby No. 055, Edificio Cronos, Torre 1 - Piso 7, Santiago de Surco, Lima, Peru",
        "city": "Lima", "state": "Santiago de Surco", "postal_code": "", "country": "Peru",
        "phone": "", "activity": "Conveying Solutions Sales Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/chile",
    },
    # === NORTH AMERICA ===
    {
        "facility_name_native": "ContiTech USA, Inc.",
        "facility_name": "ContiTech USA, Inc.",
        "address_native": "703 S. Cleveland-Massillon Rd, Fairlawn, OH 44333, USA",
        "address": "703 S. Cleveland-Massillon Rd, Fairlawn, OH 44333, USA",
        "city": "Fairlawn", "state": "OH", "postal_code": "44333", "country": "United States of America (the)",
        "phone": "", "activity": "Industrial Solutions Americas Headquarters",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "O'Sullivan Films",
        "facility_name": "O'Sullivan Films",
        "address_native": "1944 Valley Avenue, Winchester VA 22601",
        "address": "1944 Valley Avenue, Winchester, VA 22601",
        "city": "Winchester", "state": "VA", "postal_code": "22601", "country": "United States of America (the)",
        "phone": "", "activity": "Surface Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Alabama Service Center",
        "facility_name": "ContiTech USA - Alabama Service Center",
        "address_native": "917 Industrial Park Circle, Bessemer, AL 35022",
        "address": "917 Industrial Park Circle, Bessemer, AL 35022",
        "city": "Bessemer", "state": "AL", "postal_code": "35022", "country": "United States of America (the)",
        "phone": "(205) 426-3754", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Arizona Service Center",
        "facility_name": "ContiTech USA - Arizona Service Center",
        "address_native": "3375 S. Winchester Road, Apache Junction, AZ 85119",
        "address": "3375 S. Winchester Road, Apache Junction, AZ 85119",
        "city": "Apache Junction", "state": "AZ", "postal_code": "85119", "country": "United States of America (the)",
        "phone": "(330) 690-3172", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Colorado Service Center",
        "facility_name": "ContiTech USA - Colorado Service Center",
        "address_native": "2240 Railroad Avenue, Grand Junction, CO 81505",
        "address": "2240 Railroad Avenue, Grand Junction, CO 81505",
        "city": "Grand Junction", "state": "CO", "postal_code": "81505", "country": "United States of America (the)",
        "phone": "", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Georgia Service Center",
        "facility_name": "ContiTech USA - Georgia Service Center",
        "address_native": "608 Riverside Parkway, Austell, GA 30168",
        "address": "608 Riverside Parkway, Austell, GA 30168",
        "city": "Austell", "state": "GA", "postal_code": "30168", "country": "United States of America (the)",
        "phone": "(404) 346-3060", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Montana Service Center",
        "facility_name": "ContiTech USA - Montana Service Center",
        "address_native": "1518 W Laura Lee Lane, Laurel, MT 59044",
        "address": "1518 W Laura Lee Lane, Laurel, MT 59044",
        "city": "Laurel", "state": "MT", "postal_code": "59044", "country": "United States of America (the)",
        "phone": "+1 (307) 299-7116", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Virginia Service Center",
        "facility_name": "ContiTech USA - Virginia Service Center",
        "address_native": "347 Gratton Road, Tazewell, VA 24651",
        "address": "347 Gratton Road, Tazewell, VA 24651",
        "city": "Tazewell", "state": "VA", "postal_code": "24651", "country": "United States of America (the)",
        "phone": "(276) 988-9641", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - West Virginia Charleston",
        "facility_name": "ContiTech USA - West Virginia Charleston Service Center",
        "address_native": "1458 Reunion Road, Elkview, WV 25071",
        "address": "1458 Reunion Road, Elkview, WV 25071",
        "city": "Elkview", "state": "WV", "postal_code": "25071", "country": "United States of America (the)",
        "phone": "(304) 965-9055", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - West Virginia Logan",
        "facility_name": "ContiTech USA - West Virginia Logan Service Center",
        "address_native": "1375A Holden Road, Cora, WV 25641",
        "address": "1375A Holden Road, Cora, WV 25641",
        "city": "Cora", "state": "WV", "postal_code": "25641", "country": "United States of America (the)",
        "phone": "(304) 239-2590", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - West Virginia Wheeling",
        "facility_name": "ContiTech USA - West Virginia Wheeling Service Center",
        "address_native": "123 Peninsula Street, Wheeling, WV 26003",
        "address": "123 Peninsula Street, Wheeling, WV 26003",
        "city": "Wheeling", "state": "WV", "postal_code": "26003", "country": "United States of America (the)",
        "phone": "(304) 233-0860", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    {
        "facility_name_native": "ContiTech USA - Wyoming Service Center",
        "facility_name": "ContiTech USA - Wyoming Service Center",
        "address_native": "1471 Garman Court, Gillette, WY 82716",
        "address": "1471 Garman Court, Gillette, WY 82716",
        "city": "Gillette", "state": "WY", "postal_code": "82716", "country": "United States of America (the)",
        "phone": "(307) 682-7855", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/americas/usa",
    },
    # === AUSTRIA ===
    {
        "facility_name_native": "ContiTech Kautschuk- und Kunststoffvertriebsgesellschaft m.b.H.",
        "facility_name": "ContiTech Kautschuk- und Kunststoffvertriebsgesellschaft m.b.H.",
        "address_native": "Industriezentrum NÖ Süd, Straße 15, Objekt 77, Eingang 5, 2355 Wiener Neudorf, Austria",
        "address": "Industriezentrum NOe Sued, Strasse 15, Objekt 77, Eingang 5, 2355 Wiener Neudorf, Austria",
        "city": "Wiener Neudorf", "state": "", "postal_code": "2355", "country": "Austria",
        "phone": "", "activity": "Rubber & Plastics Sales Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/austria",
    },
    # === BELGIUM ===
    {
        "facility_name_native": "ContiTech Belgium BVBA",
        "facility_name": "ContiTech Belgium BVBA",
        "address_native": "Hermeslaan 1 B, B-1831 Diegem, Belgium",
        "address": "Hermeslaan 1 B, B-1831 Diegem, Belgium",
        "city": "Diegem", "state": "", "postal_code": "1831", "country": "Belgium",
        "phone": "+32 (0)3 20674 20", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/benelux",
    },
    # === FINLAND (6 locations) ===
    {
        "facility_name_native": "ContiTech Finland Oy - Pirkkala",
        "facility_name": "ContiTech Finland Oy - Pirkkala",
        "address_native": "Ruutanakorventie 4, 33960 Pirkkala, Suomi",
        "address": "Ruutanakorventie 4, 33960 Pirkkala, Finland",
        "city": "Pirkkala", "state": "", "postal_code": "33960", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    {
        "facility_name_native": "ContiTech Finland Oy - Harjavalta",
        "facility_name": "ContiTech Finland Oy - Harjavalta",
        "address_native": "Lyytikänkatu 24, 29200 Harjavalta, Suomi",
        "address": "Lyytikankatu 24, 29200 Harjavalta, Finland",
        "city": "Harjavalta", "state": "", "postal_code": "29200", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    {
        "facility_name_native": "ContiTech Finland Oy - Kouvola",
        "facility_name": "ContiTech Finland Oy - Kouvola",
        "address_native": "Reijulankatu 12, 45130 Kouvola, Suomi",
        "address": "Reijulankatu 12, 45130 Kouvola, Finland",
        "city": "Kouvola", "state": "", "postal_code": "45130", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    {
        "facility_name_native": "ContiTech Finland Oy - Kello",
        "facility_name": "ContiTech Finland Oy - Kello",
        "address_native": "Höyläämötie 2, 90820 Kello, Suomi",
        "address": "Hoylaamotie 2, 90820 Kello, Finland",
        "city": "Kello", "state": "", "postal_code": "90820", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    {
        "facility_name_native": "ContiTech Finland Oy - Pieksämäki",
        "facility_name": "ContiTech Finland Oy - Pieksamaki",
        "address_native": "Helmintie 2, 76150 Pieksämäki, Suomi",
        "address": "Helmintie 2, 76150 Pieksamaki, Finland",
        "city": "Pieksamaki", "state": "", "postal_code": "76150", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    {
        "facility_name_native": "ContiTech Finland Oy - Seinäjoki",
        "facility_name": "ContiTech Finland Oy - Seinajoki",
        "address_native": "Tuottajantie 59, 60100 Seinäjoki, Suomi",
        "address": "Tuottajantie 59, 60100 Seinajoki, Finland",
        "city": "Seinajoki", "state": "", "postal_code": "60100", "country": "Finland",
        "phone": "", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/finland",
    },
    # === FRANCE (7 locations) ===
    {
        "facility_name_native": "ContiTech France SNC - Gennevilliers",
        "facility_name": "ContiTech France SNC - Gennevilliers",
        "address_native": "3 Rue Fulgence Bienvenue, 92631 Gennevilliers, France",
        "address": "3 Rue Fulgence Bienvenue, 92631 Gennevilliers, France",
        "city": "Gennevilliers", "state": "", "postal_code": "92631", "country": "France",
        "phone": "", "activity": "Sales & Service Headquarters France",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "ContiTech France SNC - Le Chambon-Feugerolles",
        "facility_name": "ContiTech France SNC - Le Chambon-Feugerolles",
        "address_native": "Z.I. de la Silardière, 42500 Le Chambon-Feugerolles, France",
        "address": "Z.I. de la Silardiere, 42500 Le Chambon-Feugerolles, France",
        "city": "Le Chambon-Feugerolles", "state": "", "postal_code": "42500", "country": "France",
        "phone": "", "activity": "Industrial Solutions Manufacturing Plant",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "ContiTech Anoflex S.A.S.",
        "facility_name": "ContiTech Anoflex S.A.S.",
        "address_native": "2-12, avenue Barthélémy Thimonnier, 69300 Caluire, France",
        "address": "2-12, avenue Barthelemy Thimonnier, 69300 Caluire, France",
        "city": "Caluire", "state": "", "postal_code": "69300", "country": "France",
        "phone": "", "activity": "Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "ContiTech Vibration Control France S.A.S.",
        "facility_name": "ContiTech Vibration Control France S.A.S.",
        "address_native": "5 rue Adrienne Bolland, 42160 Andrézieux, France",
        "address": "5 rue Adrienne Bolland, 42160 Andrezieux, France",
        "city": "Andrezieux", "state": "", "postal_code": "42160", "country": "France",
        "phone": "", "activity": "Vibration Control Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "ContiTech France SNC - Neuilly-Plaisance",
        "facility_name": "ContiTech France SNC - Neuilly-Plaisance",
        "address_native": "2 Rue Vincent Van Gogh, 93360 Neuilly-Plaisance, France",
        "address": "2 Rue Vincent Van Gogh, 93360 Neuilly-Plaisance, France",
        "city": "Neuilly-Plaisance", "state": "", "postal_code": "93360", "country": "France",
        "phone": "", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "ContiTech AVS France SAS",
        "facility_name": "ContiTech AVS France SAS",
        "address_native": "24, Rue Nicolas-Joseph Cugnot, 35043 Rennes Cedex, France",
        "address": "24, Rue Nicolas-Joseph Cugnot, 35043 Rennes Cedex, France",
        "city": "Rennes", "state": "", "postal_code": "35043", "country": "France",
        "phone": "", "activity": "Anti-Vibration Systems Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    {
        "facility_name_native": "Merlett France S.A.R.L.",
        "facility_name": "Merlett France S.A.R.L.",
        "address_native": "Z.I de Domène, Rue du Moirond, 38420 Domene, France",
        "address": "Z.I de Domene, Rue du Moirond, 38420 Domene, France",
        "city": "Domene", "state": "", "postal_code": "38420", "country": "France",
        "phone": "", "activity": "Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/france",
    },
    # === HUNGARY (4 locations) ===
    {
        "facility_name_native": "ContiTech Hungary - Makó telephely",
        "facility_name": "ContiTech Hungary - Mako Plant",
        "address_native": "6900 Makó, Rákosi út 3, Hungary",
        "address": "Rakosi ut 3, 6900 Mako, Hungary",
        "city": "Mako", "state": "", "postal_code": "6900", "country": "Hungary",
        "phone": "", "activity": "Rubber Products Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/hungary",
    },
    {
        "facility_name_native": "ContiTech Fluid Automotive Hungária Kft.",
        "facility_name": "ContiTech Fluid Automotive Hungaria Kft.",
        "address_native": "2600 Vác, Külső Rádi út 0290/1, Hungary",
        "address": "Kulso Radi ut 0290/1, 2600 Vac, Hungary",
        "city": "Vac", "state": "", "postal_code": "2600", "country": "Hungary",
        "phone": "", "activity": "Fluid Automotive Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/hungary",
    },
    {
        "facility_name_native": "ContiTech Hungary Ltd. - Nyíregyháza",
        "facility_name": "ContiTech Hungary Ltd. - Nyiregyhaza Plant",
        "address_native": "4400 Nyíregyháza, Derkovits út 137, Hungary",
        "address": "Derkovits ut 137, 4400 Nyiregyhaza, Hungary",
        "city": "Nyiregyhaza", "state": "", "postal_code": "4400", "country": "Hungary",
        "phone": "", "activity": "Industrial Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/hungary",
    },
    {
        "facility_name_native": "ContiTech Rubber Industrial Kft. - Szeged",
        "facility_name": "ContiTech Rubber Industrial Kft. - Szeged Plant",
        "address_native": "6728 Szeged, Budapesti út 10, Hungary",
        "address": "Budapesti ut 10, 6728 Szeged, Hungary",
        "city": "Szeged", "state": "", "postal_code": "6728", "country": "Hungary",
        "phone": "", "activity": "Conveying Solutions, Fluid Technology Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/hungary",
    },
    # === POLAND (2 locations) ===
    {
        "facility_name_native": "CT Polska Sp. z o.o.",
        "facility_name": "CT Polska Sp. z o.o.",
        "address_native": "ul. Główna 10, 55-010 Św. Katarzyna, Polska",
        "address": "ul. Glowna 10, 55-010 Sw. Katarzyna, Poland",
        "city": "Sw. Katarzyna", "state": "", "postal_code": "55-010", "country": "Poland",
        "phone": "", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/poland",
    },
    {
        "facility_name_native": "MERLETT Polska Sp. z o.o.",
        "facility_name": "MERLETT Polska Sp. z o.o.",
        "address_native": "ul. Św. Mikołaja 1, 68-080 Swadzim k. Poznania, Polska",
        "address": "ul. Sw. Mikolaja 1, 68-080 Swadzim k. Poznania, Poland",
        "city": "Swadzim", "state": "", "postal_code": "68-080", "country": "Poland",
        "phone": "", "activity": "Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/poland",
    },
    # === ROMANIA (3 plants) ===
    {
        "facility_name_native": "ContiTech Fluid Automotive România S.R.L.",
        "facility_name": "ContiTech Fluid Automotive Romania S.R.L.",
        "address_native": "Str. Mihai Viteazul, nr. 125, 445100 Carei, Satu Mare, Romania",
        "address": "Str. Mihai Viteazul, nr. 125, 445100 Carei, Satu Mare, Romania",
        "city": "Carei", "state": "Satu Mare", "postal_code": "445100", "country": "Romania",
        "phone": "", "activity": "Mobile Fluid Systems Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/romania",
    },
    {
        "facility_name_native": "ContiTech România S.R.L.",
        "facility_name": "ContiTech Romania S.R.L.",
        "address_native": "Str. Rudolf Otto, nr. 4, 300522 Timișoara, Timiș, Romania",
        "address": "Str. Rudolf Otto, nr. 4, 300522 Timisoara, Timis, Romania",
        "city": "Timisoara", "state": "Timis", "postal_code": "300522", "country": "Romania",
        "phone": "", "activity": "Original Equipment Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/romania",
    },
    {
        "facility_name_native": "ContiTech Thermopol România S.R.L.",
        "facility_name": "ContiTech Thermopol Romania S.R.L.",
        "address_native": "D.N. 79, KM 37, 315101 Nădab, Arad, Romania",
        "address": "D.N. 79, KM 37, 315101 Nadab, Arad, Romania",
        "city": "Nadab", "state": "Arad", "postal_code": "315101", "country": "Romania",
        "phone": "", "activity": "Thermoplastics Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/romania",
    },
    # === SLOVENIA ===
    {
        "facility_name_native": "ContiTech Slovenija, d.o.o.",
        "facility_name": "ContiTech Slovenija, d.o.o.",
        "address_native": "Škofjeleška cesta 6, 4000 Kranj, Slovenija",
        "address": "Skofjeleska cesta 6, 4000 Kranj, Slovenia",
        "city": "Kranj", "state": "", "postal_code": "4000", "country": "Slovenia",
        "phone": "+386 4 207 80 00", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/slovenia",
    },
    # === SOUTH AFRICA ===
    {
        "facility_name_native": "ContiTech Africa (Pty.) Ltd.",
        "facility_name": "ContiTech Africa (Pty.) Ltd.",
        "address_native": "126 Algoa Road, Uitenhage, EC 6229, South Africa",
        "address": "126 Algoa Road, Uitenhage, EC 6229, South Africa",
        "city": "Uitenhage", "state": "EC", "postal_code": "6229", "country": "South Africa",
        "phone": "", "activity": "Conveyor Belt Manufacturing Plant",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/south-africa",
    },
    {
        "facility_name_native": "ContiTech South Africa (Pty) Ltd. - Johannesburg",
        "facility_name": "ContiTech South Africa (Pty) Ltd. - Johannesburg Sales Office",
        "address_native": "36 Houer Road, City Deep, Johannesburg, 2197, South Africa",
        "address": "36 Houer Road, City Deep, Johannesburg, 2197, South Africa",
        "city": "Johannesburg", "state": "", "postal_code": "2197", "country": "South Africa",
        "phone": "+27 (0)11 248 9444", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/south-africa",
    },
    # === SPAIN ===
    {
        "facility_name_native": "Continental Iberia Sales and Services, S.A.",
        "facility_name": "Continental Iberia Sales and Services, S.A.",
        "address_native": "Cityparc-Ronda de Dalt, Ctra. de L'Hospitalet 147, E-08940 Cornellà (Barcelona), España",
        "address": "Cityparc-Ronda de Dalt, Ctra. de L'Hospitalet 147, E-08940 Cornella (Barcelona), Spain",
        "city": "Cornella", "state": "Barcelona", "postal_code": "08940", "country": "Spain",
        "phone": "+34 934 800 400", "activity": "Sales & Service Headquarters Iberia",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/spainportugal",
    },
    {
        "facility_name_native": "Continental, Benecke-Kaliko S.A.U.",
        "facility_name": "Continental, Benecke-Kaliko S.A.U.",
        "address_native": "Polígono Landaben, Calle A, 26, E-31012 Pamplona (Navarra), España",
        "address": "Poligono Landaben, Calle A, 26, E-31012 Pamplona (Navarra), Spain",
        "city": "Pamplona", "state": "Navarra", "postal_code": "31012", "country": "Spain",
        "phone": "+34 948 286 622", "activity": "Surface Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/spainportugal",
    },
    # === SWEDEN (8 locations) ===
    {
        "facility_name_native": "ContiTech Scandinavia AB - Head Office",
        "facility_name": "ContiTech Scandinavia AB - Head Office",
        "address_native": "Finlandsgatan 18, 164 74 Kista, Sweden",
        "address": "Finlandsgatan 18, 164 74 Kista, Sweden",
        "city": "Kista", "state": "", "postal_code": "164 74", "country": "Sweden",
        "phone": "+46 (0)8 444 13 30", "activity": "Conveying Solutions Headquarters Scandinavia",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Gällivare",
        "facility_name": "ContiTech Scandinavia - Gallivare Service Branch",
        "address_native": "Vuoskojärvivägen 19, 982 38 Gällivare, Sweden",
        "address": "Vuoskojarvisvagen 19, 982 38 Gallivare, Sweden",
        "city": "Gallivare", "state": "", "postal_code": "982 38", "country": "Sweden",
        "phone": "+46 (0) 97 016 900", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Kiruna",
        "facility_name": "ContiTech Scandinavia - Kiruna Service Branch",
        "address_native": "Kirunavaara\u0308gen 1, 98 186 Kiruna, Sweden",
        "address": "Kirunavaravagen 1, 98 186 Kiruna, Sweden",
        "city": "Kiruna", "state": "", "postal_code": "98 186", "country": "Sweden",
        "phone": "+46 (0) 98 061 860", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Mora",
        "facility_name": "ContiTech Scandinavia - Mora Service Branch",
        "address_native": "Brudtallsvägen 14, 792 32 Mora, Sweden",
        "address": "Brudtallsvagen 14, 792 32 Mora, Sweden",
        "city": "Mora", "state": "", "postal_code": "792 32", "country": "Sweden",
        "phone": "+46 (0) 54 86 08 10", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Karlstad",
        "facility_name": "ContiTech Scandinavia - Karlstad Service Branch",
        "address_native": "Blekegatan 8, 652 21 Karlstad, Sweden",
        "address": "Blekegatan 8, 652 21 Karlstad, Sweden",
        "city": "Karlstad", "state": "", "postal_code": "652 21", "country": "Sweden",
        "phone": "+46 (0) 54 86 08 10", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Örebro",
        "facility_name": "ContiTech Scandinavia - Orebro Service Branch",
        "address_native": "Skomaskinsgatan 6, 702 27 Örebro, Sweden",
        "address": "Skomaskinsgatan 6, 702 27 Orebro, Sweden",
        "city": "Orebro", "state": "", "postal_code": "702 27", "country": "Sweden",
        "phone": "+46 (0) 19 277 14 31", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Stockholm",
        "facility_name": "ContiTech Scandinavia - Stockholm Service Branch",
        "address_native": "Jägerhorns väg 6, 141 75 Kungens Kurva, Sweden",
        "address": "Jagerhorns vag 6, 141 75 Kungens Kurva, Sweden",
        "city": "Kungens Kurva", "state": "", "postal_code": "141 75", "country": "Sweden",
        "phone": "+46 (0) 54 86 08 10", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    {
        "facility_name_native": "ContiTech Scandinavia - Växjö",
        "facility_name": "ContiTech Scandinavia - Vaxjo Service Branch",
        "address_native": "Bävervägen 5, 352 45 Växjö, Sweden",
        "address": "Bavervagen 5, 352 45 Vaxjo, Sweden",
        "city": "Vaxjo", "state": "", "postal_code": "352 45", "country": "Sweden",
        "phone": "+46 (0) 47 074 29 33", "activity": "Conveying Solutions Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/sweden",
    },
    # === SWITZERLAND ===
    {
        "facility_name_native": "Continental Suisse S.A.",
        "facility_name": "Continental Suisse S.A.",
        "address_native": "Lerzenstrasse 19A, 8953 Dietikon, Schweiz",
        "address": "Lerzenstrasse 19A, 8953 Dietikon, Switzerland",
        "city": "Dietikon", "state": "", "postal_code": "8953", "country": "Switzerland",
        "phone": "", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/switzerland",
    },
    # === TÜRKIYE ===
    {
        "facility_name_native": "ContiTech Lastik Sanayi ve Ticaret A.Ş.",
        "facility_name": "ContiTech Lastik Sanayi ve Ticaret A.S.",
        "address_native": "Minareliçavuşosb Mahallesi, N. 114 Sokak No. 10, 16145 Nilüfer-Bursa, Türkiye",
        "address": "Minarelicavusosb Mahallesi, N. 114 Sokak No. 10, 16145 Nilufer-Bursa, Turkiye",
        "city": "Bursa", "state": "Nilufer", "postal_code": "16145", "country": "T\u00fcrkiye",
        "phone": "", "activity": "Rubber Manufacturing Plant",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/turkey",
    },
    # === UNITED KINGDOM (3 locations) ===
    {
        "facility_name_native": "Dunlop Oil & Marine Ltd. - Grimsby",
        "facility_name": "Dunlop Oil & Marine Ltd. - Grimsby Plant",
        "address_native": "Moody Lane, Pyewipe, Grimsby, DN31 2SY, United Kingdom",
        "address": "Moody Lane, Pyewipe, Grimsby, DN31 2SY, United Kingdom",
        "city": "Grimsby", "state": "", "postal_code": "DN31 2SY", "country": "United Kingdom of Great Britain and Northern Ireland (the)",
        "phone": "", "activity": "Oil & Marine Hose Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/united-kingdom",
    },
    {
        "facility_name_native": "Dunlop Oil & Marine Ltd. - Blyth",
        "facility_name": "Dunlop Oil & Marine Ltd. - Blyth Office",
        "address_native": "Blyth Workspace, Quay Road, Blyth, Northumberland, NE24 3AF, United Kingdom",
        "address": "Blyth Workspace, Quay Road, Blyth, Northumberland, NE24 3AF, United Kingdom",
        "city": "Blyth", "state": "Northumberland", "postal_code": "NE24 3AF", "country": "United Kingdom of Great Britain and Northern Ireland (the)",
        "phone": "", "activity": "Oil & Marine Sales Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/united-kingdom",
    },
    {
        "facility_name_native": "ContiTech United Kingdom Ltd.",
        "facility_name": "ContiTech United Kingdom Ltd.",
        "address_native": "Unit 2, Castle Mound Way, Central Park, CV23 0WB Rugby, United Kingdom",
        "address": "Unit 2, Castle Mound Way, Central Park, CV23 0WB Rugby, United Kingdom",
        "city": "Rugby", "state": "", "postal_code": "CV23 0WB", "country": "United Kingdom of Great Britain and Northern Ireland (the)",
        "phone": "", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/emea/united-kingdom",
    },
    # === AUSTRALIA (10 locations) ===
    {
        "facility_name_native": "Vulcanite Pty Ltd.",
        "facility_name": "Vulcanite Pty Ltd.",
        "address_native": "Block N Unit 1 Commercial Drive, 391 Park Road, Regents Park, NSW 2143, Australia",
        "address": "Block N Unit 1 Commercial Drive, 391 Park Road, Regents Park, NSW 2143, Australia",
        "city": "Regents Park", "state": "NSW", "postal_code": "2143", "country": "Australia",
        "phone": "+61 (02) 8889 3999", "activity": "Rubber Products Distribution",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Bayswater HQ",
        "facility_name": "ContiTech Australia Pty Ltd. - Bayswater Headquarters",
        "address_native": "7 Dunlop Court, Bayswater VIC 3153, Australia",
        "address": "7 Dunlop Court, Bayswater, VIC 3153, Australia",
        "city": "Bayswater", "state": "VIC", "postal_code": "3153", "country": "Australia",
        "phone": "+61 (03) 9721 0600", "activity": "Headquarters & Production Facility",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Perth",
        "facility_name": "ContiTech Australia Pty Ltd. - Perth Distribution",
        "address_native": "50 Triumph Ave, Wangara WA 6065, Australia",
        "address": "50 Triumph Ave, Wangara, WA 6065, Australia",
        "city": "Wangara", "state": "WA", "postal_code": "6065", "country": "Australia",
        "phone": "", "activity": "Sales & Distribution Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Sydney",
        "facility_name": "ContiTech Australia Pty Ltd. - Sydney Sales Office",
        "address_native": "Block N, Unit N1, Commercial Drive, 391 Park Road, Regents Park NSW 2143, Australia",
        "address": "Block N, Unit N1, Commercial Drive, 391 Park Road, Regents Park, NSW 2143, Australia",
        "city": "Regents Park", "state": "NSW", "postal_code": "2143", "country": "Australia",
        "phone": "", "activity": "Sales Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Newcastle",
        "facility_name": "ContiTech Australia Pty Ltd. - Newcastle Service Branch",
        "address_native": "Unit 10, 19 Balook Drive, Beresfield NSW 2322, Australia",
        "address": "Unit 10, 19 Balook Drive, Beresfield, NSW 2322, Australia",
        "city": "Beresfield", "state": "NSW", "postal_code": "2322", "country": "Australia",
        "phone": "+61 (02) 4966 3493", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Mackay",
        "facility_name": "ContiTech Australia Pty Ltd. - Mackay Service Branch",
        "address_native": "45 Gateway Drive, Paget QLD 4740, Australia",
        "address": "45 Gateway Drive, Paget, QLD 4740, Australia",
        "city": "Paget", "state": "QLD", "postal_code": "4740", "country": "Australia",
        "phone": "+61 (07) 4841 9800", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Karratha",
        "facility_name": "ContiTech Australia Pty Ltd. - Karratha Service Branch",
        "address_native": "40 Exploration Drive, Gap Ridge (Karratha) WA 6714, Australia",
        "address": "40 Exploration Drive, Gap Ridge (Karratha), WA 6714, Australia",
        "city": "Karratha", "state": "WA", "postal_code": "6714", "country": "Australia",
        "phone": "+61 (08) 9186 0500", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    {
        "facility_name_native": "ContiTech Australia Pty Ltd. - Nhulunbuy",
        "facility_name": "ContiTech Australia Pty Ltd. - Nhulunbuy Service Branch",
        "address_native": "Melville Bay Road, Nhulunbuy NT 0880, Australia",
        "address": "Melville Bay Road, Nhulunbuy, NT 0880, Australia",
        "city": "Nhulunbuy", "state": "NT", "postal_code": "0880", "country": "Australia",
        "phone": "+61 (07) 4841 9800", "activity": "Conveyor Belt Service Center",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/australia",
    },
    # === CHINA (8 locations) ===
    {
        "facility_name_native": "康迪泰克技术（中国）有限公司",
        "facility_name": "ContiTech Technology (China) Co., Ltd. - Shanghai HQ",
        "address_native": "上海市杨浦区昆明路518号, 宝钢广场A座20楼",
        "address": "518 Kunming Road, Yangpu District, Shanghai, 20th Floor Tower A Baosteel Plaza",
        "city": "Shanghai", "state": "Yangpu", "postal_code": "", "country": "China",
        "phone": "86-021-6080-2500", "activity": "Regional Headquarters APAC",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "康迪泰克（上海）橡塑技术有限公司",
        "facility_name": "ContiTech (Shanghai) Rubber & Plastics Technology Co., Ltd.",
        "address_native": "上海市宝山区, 崑崎路1086、1088号3幢一号",
        "address": "1086/1088 Kunqi Road, Building 3, Unit 1, Baoshan District, Shanghai",
        "city": "Shanghai", "state": "Baoshan", "postal_code": "", "country": "China",
        "phone": "86-021-6921-4907", "activity": "Rubber & Plastics Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "康迪泰克（中国）橡塑技术有限公司 - 常熟",
        "facility_name": "ContiTech (China) Rubber & Plastics Technology Co., Ltd. - Changshu",
        "address_native": "江苏省常熟市, 高新技术产业开发区乘鹤路60号",
        "address": "60 Chenghe Road, High-tech Industrial Development Zone, Changshu, Jiangsu Province",
        "city": "Changshu", "state": "Jiangsu", "postal_code": "", "country": "China",
        "phone": "86-0512-5235-2859", "activity": "Rubber & Plastics Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "康迪泰克传动系统（宁波）有限公司",
        "facility_name": "ContiTech Power Transmission (Ningbo) Co., Ltd.",
        "address_native": "浙江宁波秦工业区工业园区秦工路",
        "address": "Qin Industrial Park, Ningbo, Zhejiang Province",
        "city": "Ningbo", "state": "Zhejiang", "postal_code": "", "country": "China",
        "phone": "86-0574-6555-2357", "activity": "Power Transmission Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "赛兰特液压流体配管技术（张家港）有限公司",
        "facility_name": "Sealant Hydraulic Fluid Piping Technology (Zhangjiagang) Co., Ltd.",
        "address_native": "江苏省张家港市凤凰镇, 金沟河阳路8号",
        "address": "8 Jingou Heyang Road, Fenghuang Town, Zhangjiagang, Jiangsu Province",
        "city": "Zhangjiagang", "state": "Jiangsu", "postal_code": "", "country": "China",
        "phone": "86-0512-5837-6001", "activity": "Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "赛兰特液压电气流体配管技术（常州）有限公司",
        "facility_name": "Sealant Hydraulic Electric Fluid Piping Technology (Changzhou) Co., Ltd.",
        "address_native": "江苏省常州市武进高新区, 武进西大道108号",
        "address": "108 Wujin West Avenue, Wujin High-tech Zone, Changzhou, Jiangsu Province",
        "city": "Changzhou", "state": "Jiangsu", "postal_code": "", "country": "China",
        "phone": "86-0519-6981-1002", "activity": "Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "山东康迪泰克工程橡胶有限公司",
        "facility_name": "Shandong ContiTech Engineering Rubber Co., Ltd.",
        "address_native": "山东省兖州市, 勘用工业园区",
        "address": "Kanyong Industrial Park, Yanzhou, Shandong Province",
        "city": "Yanzhou", "state": "Shandong", "postal_code": "", "country": "China",
        "phone": "86-0537-3898-331", "activity": "Engineering Rubber Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    {
        "facility_name_native": "山西青岛胶管有限公司",
        "facility_name": "Shanxi Qingdao Hose Co., Ltd.",
        "address_native": "山西省长治市城区黄碾191号",
        "address": "191 Huangnian, Chengqu, Changzhi, Shanxi Province",
        "city": "Changzhi", "state": "Shanxi", "postal_code": "", "country": "China",
        "phone": "86-0355-2085-924", "activity": "Hose Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/china",
    },
    # === INDIA (5 locations) ===
    {
        "facility_name_native": "Continental Surface Solutions India Pvt. Ltd.",
        "facility_name": "Continental Surface Solutions India Pvt. Ltd.",
        "address_native": "B17, MIDC Khandala Phase 2, Village Kesurdi, Tal. Khandala, Dist. Satara, India - 412802",
        "address": "B17, MIDC Khandala Phase 2, Village Kesurdi, Tal. Khandala, Dist. Satara, India 412802",
        "city": "Khandala", "state": "Maharashtra", "postal_code": "412802", "country": "India",
        "phone": "+91 2169 22 8600", "activity": "Surface Solutions Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/india",
    },
    {
        "facility_name_native": "ContiTech India Pvt. Ltd.",
        "facility_name": "ContiTech India Pvt. Ltd. - Sonepat Plant",
        "address_native": "Village Badkhalsa 131029, District Sonepat, Haryana, India",
        "address": "Village Badkhalsa, District Sonepat, Haryana, India 131029",
        "city": "Sonepat", "state": "Haryana", "postal_code": "131029", "country": "India",
        "phone": "+91 130 2216210", "activity": "Power Transmission, Fluid Handling Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/india",
    },
    {
        "facility_name_native": "Phoenix Conveyor Belt India (P) Ltd.",
        "facility_name": "Phoenix Conveyor Belt India (P) Ltd.",
        "address_native": "P.O.Muragacha Road, Gayeshpur, Kalyani, Nadia, West Bengal, India, 741234",
        "address": "P.O. Muragacha Road, Gayeshpur, Kalyani, Nadia, West Bengal, India 741234",
        "city": "Kalyani", "state": "West Bengal", "postal_code": "741234", "country": "India",
        "phone": "", "activity": "Conveyor Belt Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/india",
    },
    {
        "facility_name_native": "ContiTech India - New Delhi Branch",
        "facility_name": "ContiTech India - New Delhi Branch Office",
        "address_native": "DSM-232, 2nd Floor, DLF Tower, Moti Nagar, Shivaji Marg, New Delhi-110015",
        "address": "DSM-232, 2nd Floor, DLF Tower, Moti Nagar, Shivaji Marg, New Delhi 110015",
        "city": "New Delhi", "state": "Delhi", "postal_code": "110015", "country": "India",
        "phone": "+91 11 45701690", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/india",
    },
    {
        "facility_name_native": "ContiTech India - Bangalore Branch",
        "facility_name": "ContiTech India - Bangalore Branch Office",
        "address_native": "Ground Floor Sattva-South Avenue, Plot No.33, 33A, 33B, Survey Nos. 20 & 23, Veerasandra Industrial Area, Electronic City Phase II, Off Hosur Road, Bangalore 560100",
        "address": "Ground Floor Sattva-South Avenue, Plot No.33, Electronic City Phase II, Off Hosur Road, Bangalore 560100",
        "city": "Bangalore", "state": "Karnataka", "postal_code": "560100", "country": "India",
        "phone": "", "activity": "Sales & Service Office",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/india",
    },
    # === KOREA (4 locations) ===
    {
        "facility_name_native": "충청남도 천안시 ContiTech Korea",
        "facility_name": "ContiTech Korea - Cheonan Plant",
        "address_native": "충청남도 천안시 서북구, 성거읍 5산열 2호 114, 31245",
        "address": "114, 2nd Row, 5th Alley, Seongeo-eup, Seobuk-gu, Cheonan, Chungcheongnam-do 31245",
        "city": "Cheonan", "state": "Chungcheongnam-do", "postal_code": "31245", "country": "Korea (the Republic of)",
        "phone": "", "activity": "Rubber Products Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/korea",
    },
    {
        "facility_name_native": "전북도 전주시 ContiTech Korea",
        "facility_name": "ContiTech Korea - Jeonju Plant",
        "address_native": "전북도 전주시, 덕유로 1길 14, 561-840",
        "address": "14 Deogyu-ro 1-gil, Jeonju, Jeollabuk-do 561-840",
        "city": "Jeonju", "state": "Jeollabuk-do", "postal_code": "561-840", "country": "Korea (the Republic of)",
        "phone": "", "activity": "Rubber Products Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/korea",
    },
    {
        "facility_name_native": "충청남도 천안시 서북구 ContiTech Korea",
        "facility_name": "ContiTech Korea - Cheonan Seobuk Plant",
        "address_native": "충청남도 천안시 서북구, 임산읍 임산리 100, 331-816",
        "address": "100 Imsan-ri, Imsan-eup, Seobuk-gu, Cheonan, Chungcheongnam-do 331-816",
        "city": "Cheonan", "state": "Chungcheongnam-do", "postal_code": "331-816", "country": "Korea (the Republic of)",
        "phone": "", "activity": "Rubber Products Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/korea",
    },
    {
        "facility_name_native": "ContiTech Power Transmission Korea Co., Ltd.",
        "facility_name": "ContiTech Power Transmission Korea Co., Ltd.",
        "address_native": "경상남도 양산시 양산동 137-52",
        "address": "137-52 Yangsan-dong, Yangsan, Gyeongsangnam-do",
        "city": "Yangsan", "state": "Gyeongsangnam-do", "postal_code": "", "country": "Korea (the Republic of)",
        "phone": "", "activity": "Power Transmission Manufacturing",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/korea",
    },
    # === SINGAPORE ===
    {
        "facility_name_native": "ContiTech Singapore Pte. Ltd.",
        "facility_name": "ContiTech Singapore Pte. Ltd.",
        "address_native": "3 Fraser Street, Singapore 189352",
        "address": "3 Fraser Street, Singapore 189352",
        "city": "Singapore", "state": "", "postal_code": "189352", "country": "Singapore",
        "phone": "", "activity": "Sales & Service Office APAC",
        "url": "https://www.continental-industry.com/global/en/about-us/business-area/apac/singapore",
    },
]

# Map ACTIVITY_AT_SOURCE to BUSINESS_ACTIVITY
def map_to_business_activity(activity):
    activity_lower = activity.lower()
    if 'manufacturing' in activity_lower or 'plant' in activity_lower or 'production' in activity_lower:
        return 'Manufacturing'
    if 'headquarter' in activity_lower or 'hq' in activity_lower or 'head office' in activity_lower:
        return 'Office'
    if 'sales' in activity_lower or 'service' in activity_lower or 'office' in activity_lower or 'branch' in activity_lower:
        return 'Office'
    if 'distribution' in activity_lower or 'warehouse' in activity_lower:
        return 'Warehouse'
    if 'research' in activity_lower or 'r&d' in activity_lower or 'development' in activity_lower:
        return 'Research & Development'
    return 'Manufacturing'

# ===== BUILD RECORDS AND GEOCODE =====
BING_API_KEY = 'yGyflKQJyJ3lNV3yKcYP~FSPEyZhJWuaj1EsG7Ajmkg~AkM_12vG3agHCBs6OD3BxSGIJ38YadqKG687egd-7Mvzp4qrkNnMMvbal7v3xIYw'
BING_API_URL = 'http://dev.virtualearth.net/REST/v1/Locations'

def geocode_bing(query):
    params = {'q': query, 'key': BING_API_KEY, 'maxResults': 1}
    try:
        r = requests.get(BING_API_URL, params=params, timeout=10)
        data = r.json()
        resources = data.get('resourceSets', [{}])[0].get('resources', [])
        if resources:
            point = resources[0].get('point', {}).get('coordinates', [])
            if len(point) == 2:
                return round(point[0], 8), round(point[1], 8)
    except:
        pass
    return None, None

records = []
for fac in FACILITIES:
    biz_act = map_to_business_activity(fac['activity'])
    
    # Check if native differs from English
    native_name = fac['facility_name_native'] if fac['facility_name_native'] != fac['facility_name'] else ''
    native_addr = fac['address_native'] if fac['address_native'] != fac['address'] else ''
    
    records.append({
        'ISSUER_ID': 'IID000000002148934',
        'ISSUER_NAME': 'Continental Aktiengesellschaft',
        'FACILITY_NAME': fac['facility_name'],
        'FACILITY_ADDRESS': fac['address'],
        'CITY': fac['city'],
        'STATE': fac['state'],
        'POSTAL_CODE': fac['postal_code'],
        'FACILITY_REGION': fac['country'],
        'LATITUDE': '',
        'LONGITUDE': '',
        'FACILITY_CONTACT_NUMBER': fac.get('phone', ''),
        'RELEVANT_URL': fac['url'],
        'ACTIVITY_AT_SOURCE': fac['activity'],
        'BUSINESS_ACTIVITY': biz_act,
        'FACILITY_NAME_NATIVE': native_name,
        'FACILITY_ADDRESS_NATIVE': native_addr,
        'coord_source': '',
    })

print(f"Total facilities: {len(records)}")

# Geocode all
print("\nGeocoding with Bing API...")
for i, rec in enumerate(records):
    geocode_query = f"{rec['FACILITY_ADDRESS']}"
    lat, lng = geocode_bing(geocode_query)
    if lat and lng:
        rec['LATITUDE'] = str(lat)
        rec['LONGITUDE'] = str(lng)
        rec['coord_source'] = 'bing'
        print(f"  [{i+1}/{len(records)}] OK: {rec['FACILITY_NAME'][:50]} -> ({lat}, {lng})")
    else:
        # Try shorter query
        short_query = f"{rec['CITY']}, {rec['FACILITY_REGION']}"
        lat, lng = geocode_bing(short_query)
        if lat and lng:
            rec['LATITUDE'] = str(lat)
            rec['LONGITUDE'] = str(lng)
            rec['coord_source'] = 'bing'
            print(f"  [{i+1}/{len(records)}] OK (city): {rec['FACILITY_NAME'][:50]} -> ({lat}, {lng})")
        else:
            print(f"  [{i+1}/{len(records)}] FAILED: {rec['FACILITY_NAME'][:50]}")
    time.sleep(0.25)

# Write CSV
OUTPUT_DIR = r'C:\Users\tiwaary\OneDrive - MSCI Office 365\WORLD Re-work\Re-collection'
OUTPUT_FILE = f'{OUTPUT_DIR}\\IID000000002148934_Continental_Aktiengesellschaft.csv'

fieldnames = [
    'ISSUER_ID', 'ISSUER_NAME', 'FACILITY_NAME', 'FACILITY_ADDRESS',
    'CITY', 'STATE', 'POSTAL_CODE', 'FACILITY_REGION',
    'LATITUDE', 'LONGITUDE', 'FACILITY_CONTACT_NUMBER',
    'RELEVANT_URL', 'ACTIVITY_AT_SOURCE', 'BUSINESS_ACTIVITY',
    'FACILITY_NAME_NATIVE', 'FACILITY_ADDRESS_NATIVE', 'coord_source'
]

with open(OUTPUT_FILE, 'w', newline='', encoding='utf-8-sig') as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(records)

print(f"\nCSV written to: {OUTPUT_FILE}")
print(f"Total records: {len(records)}")

# Summary
countries = {}
for r in records:
    c = r['FACILITY_REGION']
    countries[c] = countries.get(c, 0) + 1

geocoded = sum(1 for r in records if r['LATITUDE'])
print(f"\nGeocoded: {geocoded}/{len(records)}")
print("\nFacilities by country:")
for c, count in sorted(countries.items(), key=lambda x: -x[1]):
    print(f"  {c}: {count}")
