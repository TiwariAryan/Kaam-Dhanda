"""
Krung Thai Bank Public Company Limited — Branch Scraper
Source: https://krungthai.com/en/contact-us/ktb-location
Strategy: Playwright browser session -> POST /en/contact-us/getservicelocationresult
          per province, servicePointType 1 (branches) & 4 (business offices)
Usage: python ktb_scraper.py
"""
import asyncio
import json
import re
import time
from pathlib import Path
from playwright.async_api import async_playwright

BASE_URL = "https://krungthai.com"
LOCATION_URL = f"{BASE_URL}/en/contact-us/ktb-location"
API_URL = "/en/contact-us/getservicelocationresult"
DISTRICT_API_URL = "/en/contact-us/getdistinctbyprovinceid"

# Service point types to extract (exclude ATMs)
# 1 = Branches / Branch Code / Service Points
# 2 = Exchange Booths
# 4 = Business Office Center and Others
SERVICE_TYPES = [1, 4]  # Focus on non-ATM branches first

OUTPUT_DIR = Path("krung_thai_bank_output")

def clean_address(addr_html: str) -> str:
    """Remove HTML tags and clean address string."""
    # Remove HTML tags
    clean = re.sub(r'<[^>]+>', ' ', addr_html)
    # Collapse whitespace
    clean = re.sub(r'\s+', ' ', clean).strip()
    # Remove trailing commas
    clean = clean.rstrip(', ').strip()
    return clean


def parse_branch_code(branch_code_str: str) -> str:
    """Extract numeric branch code from '(Branch Code 955)'"""
    m = re.search(r'\d+', branch_code_str or '')
    return m.group(0) if m else ''


def extract_address_parts(addr_html: str):
    """
    Try to split address into street, subdistrict, district, province, postal.
    KTB format: "street, subdistrict, <br/> district, province, postal, "
    """
    clean = clean_address(addr_html)
    # Remove the remark portion if present
    if 'Remark :' in clean:
        clean = clean[:clean.index('Remark :')].strip().rstrip(',').strip()
    parts = [p.strip() for p in clean.split(',') if p.strip()]
    return parts, clean


def parse_record(item: dict, service_type: int) -> dict:
    """Convert a raw API item into our standard schema."""
    addr_html = item.get('Address', '')
    parts, full_address = extract_address_parts(addr_html)
    
    # Try to extract city/province from address parts
    # KTB structure: "street addr, subdistrict, district, Province, PostalCode"
    # Usually last numeric-ish part is postal code, before that is province
    city = ''
    state = ''
    postal_code = ''
    
    if len(parts) >= 2:
        # Postal code is usually last (5-digit number)
        for i in range(len(parts) - 1, -1, -1):
            if re.match(r'^\d{4,6}$', parts[i].strip()):
                postal_code = parts[i].strip()
                # Province is before postal code
                if i > 0:
                    state = parts[i-1].strip()
                    city = state  # For Thailand, province = city level
                break
    
    # Latitude / Longitude
    lat_str = item.get('STR_SERVICE_POINT_MAP_X', '').strip()
    lon_str = item.get('STR_SERVICE_POINT_MAP_Y', '').strip()
    
    try:
        lat = float(lat_str) if lat_str else None
        lon = float(lon_str) if lon_str else None
    except ValueError:
        lat = lon = None
    
    # Phone number (first non-fax number)
    phones = item.get('lstConnectPhone', []) or []
    phone = ''
    for ph in phones:
        if not ph.get('isFax', False) and ph.get('Title'):
            phone = ph['Title']
            break
    
    # Google Maps URL
    relevant_url = ''
    if lat and lon:
        relevant_url = f"https://maps.google.com/maps?q={lat},{lon}"
    
    # Business activity
    activity_map = {
        1: 'Banking',
        2: 'Foreign Exchange',
        4: 'Banking',
    }
    activity = activity_map.get(service_type, 'Banking')
    
    return {
        'FACILITY_NAME': item.get('Branch', '').strip(),
        'BRANCH_CODE': parse_branch_code(item.get('BranchCode', '')),
        'FACILITY_ADDRESS': full_address,
        'CITY': city,
        'STATE': state,
        'POSTAL_CODE': postal_code,
        'FACILITY_REGION': 'Thailand',
        'LATITUDE': lat,
        'LONGITUDE': lon,
        'FACILITY_CONTACT_NUMBER': phone,
        'RELEVANT_URL': relevant_url,
        'BUSINESS_ACTIVITY': activity,
        'SERVICE_TYPE': service_type,
        'OPERATION_TIME': item.get('OperationTime', '').strip(),
        '_id': item.get('INT_SERVICE_POINT_MAIN_ID'),
    }


async def fetch_province_branches(page, province_id: int, service_type: int) -> list:
    """
    Call the API for a specific province + service type.
    Uses page.evaluate() so it runs in the browser's session context.
    """
    try:
        result = await page.evaluate("""
            async ({apiUrl, provinceId, serviceType}) => {
                try {
                    const formData = new URLSearchParams();
                    formData.append('servicePointType', serviceType.toString());
                    formData.append('provinceId', provinceId.toString());
                    formData.append('distinctId', '');
                    formData.append('operTime', '');
                    formData.append('strKeyword', '');
                    formData.append('strBranchCode', '');
                    
                    const r = await fetch(apiUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'RequestVerificationToken': (typeof headers !== 'undefined') ? headers['RequestVerificationToken'] : '',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: formData.toString()
                    });
                    const data = await r.json();
                    return {ok: true, items: data.ListItems || [], total: data.TotalItems || 0, error: null};
                } catch (e) {
                    return {ok: false, items: [], total: 0, error: e.toString()};
                }
            }
        """, {'apiUrl': API_URL, 'provinceId': province_id, 'serviceType': service_type})
        return result
    except Exception as e:
        return {'ok': False, 'items': [], 'total': 0, 'error': str(e)}


async def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    
    print("=" * 70)
    print("KRUNG THAI BANK — Branch Extractor")
    print("=" * 70)
    
    all_records = []
    seen_ids = set()
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, channel='msedge')
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        )
        page = await context.new_page()
        
        print(f"Loading {LOCATION_URL}...")
        await page.goto(LOCATION_URL, timeout=30000, wait_until='networkidle')
        await asyncio.sleep(2)
        
        # Get all provinces
        provinces = await page.evaluate("""
            () => {
                const sel = document.getElementById('selectval3');
                if (!sel) return [];
                return Array.from(sel.options)
                    .filter(o => o.value !== '0')
                    .map(o => ({id: parseInt(o.value), name: o.text}));
            }
        """)
        print(f"Found {len(provinces)} provinces")
        
        # Also get all-province call (no province filter) for completeness
        # Try service types
        for service_type in SERVICE_TYPES:
            type_name = {1: 'Branches/Service Points', 2: 'Exchange Booths', 4: 'Business Offices'}.get(service_type, str(service_type))
            print(f"\n{'='*60}")
            print(f"Service Type {service_type}: {type_name}")
            print(f"{'='*60}")
            
            type_count = 0
            for i, prov in enumerate(provinces):
                prov_id = prov['id']
                prov_name = prov['name']
                
                result = await fetch_province_branches(page, prov_id, service_type)
                
                if not result['ok']:
                    print(f"  [{i+1}/{len(provinces)}] {prov_name} (ID={prov_id}): ERROR - {result.get('error', 'Unknown')}")
                    continue
                
                items = result.get('items', [])
                new_count = 0
                for item in items:
                    uid = item.get('INT_SERVICE_POINT_MAIN_ID')
                    if uid and uid not in seen_ids:
                        seen_ids.add(uid)
                        record = parse_record(item, service_type)
                        all_records.append(record)
                        new_count += 1
                
                type_count += new_count
                total = result.get('total', len(items))
                print(f"  [{i+1}/{len(provinces)}] {prov_name}: {total} found, {new_count} new (total so far: {len(all_records)})")
                
                await asyncio.sleep(0.2)  # Brief pause
            
            print(f"\nService type {service_type} total new records: {type_count}")
        
        await browser.close()
    
    # Save raw JSON
    raw_path = OUTPUT_DIR / "ktb_raw.json"
    with open(raw_path, 'w', encoding='utf-8') as f:
        json.dump(all_records, f, ensure_ascii=False, indent=2, default=str)
    print(f"\nSaved {len(all_records)} records to {raw_path}")
    
    # Quality report
    has_lat = sum(1 for r in all_records if r.get('LATITUDE'))
    has_addr = sum(1 for r in all_records if r.get('FACILITY_ADDRESS'))
    has_phone = sum(1 for r in all_records if r.get('FACILITY_CONTACT_NUMBER'))
    print(f"\nQuality:")
    print(f"  Total records: {len(all_records)}")
    print(f"  Has latitude: {has_lat}/{len(all_records)} ({100*has_lat//max(1,len(all_records))}%)")
    print(f"  Has address: {has_addr}/{len(all_records)}")
    print(f"  Has phone: {has_phone}/{len(all_records)}")
    
    return all_records


if __name__ == "__main__":
    asyncio.run(main())
