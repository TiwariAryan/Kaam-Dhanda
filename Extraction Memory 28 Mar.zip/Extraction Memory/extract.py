"""
BAJAJ FINANCE LIMITED — Branch Extractor
=========================================
Sources:
  1. Bajaj Housing Finance (BHFL) — static JSON (94 branches w/ lat/lng)
     https://www.bajajhousingfinance.in/branch-locator
     Data: https://www.bajajhousingfinance.in/documents/37350/7953389/bhfl-map-locations.json

  2. Bajaj Allianz Life — sitemap XML.gz → branch /Home pages → LD+JSON
     https://branch.bajajallianzlife.com/
     Sitemap: 451 city-level XML.gz files

Browser-required sources (not covered by this script, see NOTES in Memory folder):
  - bajajfinserv.in/branch-locator → MapMyIndia SPA, requires session token
  - bajajgeneralinsurance.com/branch-locator → AEM Sling authenticated endpoints

Usage:
  python -m issuers.bajaj_finance.extract [--bhfl-only] [--allianz-only] [--sample N]

"""
import asyncio
import argparse
import gzip
import json
import re
import sys
from pathlib import Path

import httpx

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from issuers.common import (
    log, COLUMNS, quality_report, print_sample,
    save_json, export_xlsx, archive_scripts,
)

ISSUER     = "BAJAJ FINANCE LIMITED"
BASE_URL   = "Multiple — see sources"
OUT        = "bajaj_finance_output"
ISSUER_DIR = Path(__file__).parent

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-IN,en;q=0.9",
    "Accept": "*/*",
}

# ─────────────────────────────────────────────────────────────────────────────
# SOURCE 1: Bajaj Housing Finance — static JSON
# ─────────────────────────────────────────────────────────────────────────────
BHFL_JSON_URL = "https://www.bajajhousingfinance.in/documents/37350/7953389/bhfl-map-locations.json"

def _clean_address(parts):
    """Join non-empty address parts with comma."""
    return ", ".join(p.strip() for p in parts if p and p.strip())


def _parse_bhfl_branch(raw):
    """Convert raw BHFL JSON record → standard column dict."""
    pos = raw.get("position", {})
    lat = pos.get("lat", "")
    lng = pos.get("lng", "")

    name = raw.get("branch_name") or raw.get("name") or raw.get("business_name", "")
    city = raw.get("city", "")
    state = raw.get("state", "")
    postal = str(raw.get("postal", "")).strip()
    phone = raw.get("primary_phone", "") or ""
    add_phones = raw.get("additional_phones", [])
    if add_phones:
        phone = phone or (add_phones[0] if add_phones else "")

    # Use detailed_address (clean) over formatted_address (has business name prefix)
    detailed = raw.get("detailed_address", "")
    formatted = raw.get("formatted_address", "")
    address = detailed or formatted

    # Place ID → Google Maps URL
    place_id = raw.get("place_id", "")
    gmap_url = f"https://www.google.com/maps/place/?q=place_id:{place_id}" if place_id else BHFL_JSON_URL

    # Service branch type from servicename field
    service_type = (raw.get("servicename") or "").strip(" -")

    return {
        "FACILITY_NAME":            name,
        "FACILITY_ADDRESS":         address,
        "CITY":                     city,
        "STATE":                    state,
        "POSTAL_CODE":              postal,
        "FACILITY_REGION":          "India",
        "LATITUDE":                 str(lat) if lat else "",
        "LONGITUDE":                str(lng) if lng else "",
        "FACILITY_CONTACT_NUMBER":  phone,
        "RELEVANT_URL":             gmap_url,
        "BUSINESS_ACTIVITY":        f"Housing Finance{' — ' + service_type if service_type else ''}",
    }


async def extract_bhfl(client: httpx.AsyncClient) -> list[dict]:
    log("\n--- SOURCE 1: Bajaj Housing Finance ---")
    log(f"  URL: {BHFL_JSON_URL}")
    r = await client.get(
        BHFL_JSON_URL,
        headers={**HEADERS, "Referer": "https://www.bajajhousingfinance.in/branch-locator"},
    )
    r.raise_for_status()
    raw_list = r.json()
    log(f"  Raw records: {len(raw_list)}")

    records = [_parse_bhfl_branch(b) for b in raw_list]
    log(f"  Parsed records: {len(records)}")
    return records


# ─────────────────────────────────────────────────────────────────────────────
# SOURCE 2: Bajaj Allianz Life Insurance — Sitemap → Branch HTML → LD+JSON
# ─────────────────────────────────────────────────────────────────────────────
ALLIANZ_SITEMAP_URL = "https://branch.bajajallianzlife.com/sitemap.xml"
ALLIANZ_REF         = "https://branch.bajajallianzlife.com/"
ALLIANZ_BRANCH_BASE = "https://branch.bajajlifeinsurance.com"


STATE_NAME_MAP = {
    "andhra_pradesh": "Andhra Pradesh", "arunachal_pradesh": "Arunachal Pradesh",
    "assam": "Assam", "bihar": "Bihar", "chandigarh": "Chandigarh",
    "chhattisgarh": "Chhattisgarh", "delhi": "Delhi", "goa": "Goa",
    "gujarat": "Gujarat", "haryana": "Haryana", "himachal_pradesh": "Himachal Pradesh",
    "jharkhand": "Jharkhand", "jammu_kashmir": "Jammu & Kashmir",
    "karnataka": "Karnataka", "kerala": "Kerala", "ladakh": "Ladakh",
    "madhya_pradesh": "Madhya Pradesh", "maharashtra": "Maharashtra",
    "manipur": "Manipur", "meghalaya": "Meghalaya", "mizoram": "Mizoram",
    "nagaland": "Nagaland", "odisha": "Odisha", "puducherry": "Puducherry",
    "punjab": "Punjab", "rajasthan": "Rajasthan", "sikkim": "Sikkim",
    "tamil_nadu": "Tamil Nadu", "telangana": "Telangana", "tripura": "Tripura",
    "uttar_pradesh": "Uttar Pradesh", "uttarakhand": "Uttarakhand",
    "west_bengal": "West Bengal",
}


def _parse_allianz_branch(html: str, url: str, state_slug: str = "", city_slug: str = "") -> dict | None:
    """Extract branch data from a Bajaj Allianz Life /Home page via LD+JSON."""
    ld_jsons = re.findall(
        r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>',
        html, re.DOTALL | re.I
    )

    # Derive state name from sitemap path slug (most reliable)
    state_from_sitemap = STATE_NAME_MAP.get(state_slug.lower(), state_slug.replace("_", " ").title())
    city_from_sitemap  = city_slug.replace("_", " ").title()

    for ld_raw in ld_jsons:
        try:
            ld = json.loads(ld_raw)
        except json.JSONDecodeError:
            continue

        items = ld if isinstance(ld, list) else [ld]
        for item in items:
            if item.get("@type") != "LocalBusiness":
                continue

            addresses = item.get("address", [])
            if isinstance(addresses, dict):
                addresses = [addresses]

            for addr in addresses:
                if addr.get("@type") != "PostalAddress":
                    continue

                street   = addr.get("streetAddress", "")
                locality = addr.get("addressLocality", "")   # neighborhood
                region   = addr.get("addressRegion", "")     # city in Indian LD+JSON
                postal   = addr.get("postalCode", "")
                country  = addr.get("addressCountry", "India")
                phones   = addr.get("telephone", [])
                if isinstance(phones, str):
                    phones = [phones]
                phone = phones[0] if phones else ""

                # addressRegion = city (in Indian LD+JSON conventions)
                # Use sitemap city as CITY, sitemap state as STATE
                city  = city_from_sitemap or region
                state = state_from_sitemap

                full_address = _clean_address([street, locality, region, postal])

                name = item.get("name", "Bajaj Life Insurance")
                return {
                    "FACILITY_NAME":           name,
                    "FACILITY_ADDRESS":        full_address,
                    "CITY":                    city,
                    "STATE":                   state,
                    "POSTAL_CODE":             postal,
                    "FACILITY_REGION":         "India",
                    "LATITUDE":                "",
                    "LONGITUDE":               "",
                    "FACILITY_CONTACT_NUMBER": phone,
                    "RELEVANT_URL":            url,
                    "BUSINESS_ACTIVITY":       "Life Insurance",
                }
    return None


async def extract_allianz(
    client: httpx.AsyncClient,
    sample: int = 0,
    concurrency: int = 10,
) -> list[dict]:
    log("\n--- SOURCE 2: Bajaj Allianz Life Insurance ---")
    log(f"  Sitemap: {ALLIANZ_SITEMAP_URL}")

    # Step 1: Fetch main sitemap → get all city XML.gz URLs
    r = await client.get(ALLIANZ_SITEMAP_URL, headers=HEADERS)
    r.raise_for_status()
    city_gz_urls = re.findall(r'<loc>(https?://[^<]+\.xml\.gz)</loc>', r.text)
    log(f"  City sitemap files: {len(city_gz_urls)}")

    if sample:
        city_gz_urls = city_gz_urls[:max(1, sample // 5)]
        log(f"  (Sample mode: using {len(city_gz_urls)} city files)")

    # Step 2: Fetch each XML.gz → collect unique /Home branch URLs with state/city context
    # gz_url format: .../119541/{state_slug}/{city_slug}.xml.gz
    branch_home_entries = []  # list of (url, state_slug, city_slug)
    seen_slugs = set()

    sem = asyncio.Semaphore(concurrency)

    async def fetch_city_gz(gz_url: str):
        # Extract state/city from URL path
        parts = gz_url.rstrip("/").split("/")
        city_gz_name = parts[-1].replace(".xml.gz", "")   # e.g. "bardhaman"
        state_slug   = parts[-2] if len(parts) >= 2 else ""  # e.g. "west_bengal"

        async with sem:
            try:
                r = await client.get(gz_url, headers={**HEADERS, "Referer": ALLIANZ_REF})
                if r.status_code != 200:
                    return []
                decompressed = gzip.decompress(r.content).decode("utf-8")
                locs = re.findall(r'<loc>(https?://[^<]+)</loc>', decompressed)
                home_locs = [l for l in locs if l.endswith("/Home")]
                return [(l, state_slug, city_gz_name) for l in home_locs]
            except Exception as e:
                log(f"  [WARN] Failed to fetch {gz_url}: {e}")
                return []

    tasks = [asyncio.create_task(fetch_city_gz(gz)) for gz in city_gz_urls]
    for i, t in enumerate(asyncio.as_completed(tasks), 1):
        entries = await t
        for url, state_slug, city_slug in entries:
            slug = url.split("/")[-2]
            if slug not in seen_slugs:
                seen_slugs.add(slug)
                branch_home_entries.append((url, state_slug, city_slug))
        if i % 50 == 0:
            log(f"  Progress: {i}/{len(city_gz_urls)} city files, {len(branch_home_entries)} unique branches so far")

    log(f"  Total unique branch /Home URLs: {len(branch_home_entries)}")

    if sample and len(branch_home_entries) > sample:
        branch_home_entries = branch_home_entries[:sample]
        log(f"  (Sample mode: capped at {sample} branches)")

    # Step 3: Fetch each /Home page and parse LD+JSON
    records = []
    failed = 0

    async def fetch_branch_page(url: str, state_slug: str, city_slug: str):
        async with sem:
            try:
                r = await client.get(url, headers={**HEADERS, "Referer": ALLIANZ_REF})
                if r.status_code != 200:
                    return None
                return _parse_allianz_branch(r.text, url, state_slug, city_slug)
            except Exception as e:
                return None

    branch_tasks = [asyncio.create_task(fetch_branch_page(u, ss, cs)) for u, ss, cs in branch_home_entries]
    for i, t in enumerate(asyncio.as_completed(branch_tasks), 1):
        rec = await t
        if rec:
            records.append(rec)
        else:
            failed += 1
        if i % 100 == 0:
            log(f"  Progress: {i}/{len(branch_home_entries)} pages, {len(records)} records, {failed} failed")

    log(f"  Done: {len(records)} records, {failed} failed")
    return records


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
async def main(bhfl_only: bool, allianz_only: bool, sample: int):
    log("=" * 70)
    log(f"{ISSUER} EXTRACTOR")
    log("=" * 70)
    log("Sources: BHFL (static JSON) + Bajaj Allianz Life (sitemap crawl)")

    all_records = []

    async with httpx.AsyncClient(verify=False, timeout=60, follow_redirects=True) as client:
        if not allianz_only:
            bhfl_records = await extract_bhfl(client)
            all_records.extend(bhfl_records)
            log(f"\n  [BHFL total: {len(bhfl_records)} records]")

        if not bhfl_only:
            allianz_records = await extract_allianz(client, sample=sample, concurrency=8)
            all_records.extend(allianz_records)
            log(f"\n  [Allianz Life total: {len(allianz_records)} records]")

    log(f"\n{'='*70}")
    log(f"COMBINED TOTAL: {len(all_records)} records")
    log(f"{'='*70}")

    quality_report(all_records)
    print_sample(all_records, n=5)

    jp = save_json(all_records, OUT, ISSUER, BASE_URL)
    export_xlsx(jp)

    archive_scripts(ISSUER_DIR, [Path(__file__)])
    log("\nDone!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bajaj Finance branch extractor")
    parser.add_argument("--bhfl-only", action="store_true", help="Only extract BHFL branches")
    parser.add_argument("--allianz-only", action="store_true", help="Only extract Allianz Life branches")
    parser.add_argument("--sample", type=int, default=0, help="Sample N Allianz Life branches (0=all)")
    args = parser.parse_args()
    asyncio.run(main(args.bhfl_only, args.allianz_only, args.sample))
