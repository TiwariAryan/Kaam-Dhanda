# Extraction Approach Document
## Last Updated: 2026-03-19

## Overview
This document captures approaches, learnings, and best practices for extracting facility/location data from company websites. It serves as a knowledge base to optimize future extractions.

---

## General Extraction Pipeline

### Phase 1: URL Reconnaissance
1. **Fetch the raw HTML** of the provided URL(s) using `requests` (lightweight, fast)
2. **Analyze page structure** - check if data is:
   - Static HTML (ideal - parse with BeautifulSoup)
   - Dynamic/JS-rendered (need Playwright/Selenium)
   - API-loaded (find the API endpoint - best case)
3. **Identify technology stack**: AEM, WordPress, React, Angular, etc.
4. **Look for API endpoints** in:
   - `<script>` tags (inline data, API URLs)
   - Network requests (use Playwright's request interception)
   - GraphQL endpoints
   - JSON data files referenced in HTML

### Phase 2: Data Discovery
1. **Check for structured data APIs** first:
   - `/api/locations`, `/forms/*.json`, GraphQL endpoints
   - Google Maps embed with API key + map ID
   - Data attributes on HTML elements
2. **Fall back to HTML parsing** if no API:
   - Look for accordion sections, tabs, cards
   - Parse `<h5>` + `<p>` patterns (name + address)
   - Handle `<br>` tags as address line separators
3. **Country-specific pages**: Many companies organize locations by country/region with separate pages

### Phase 3: Data Extraction
1. Parse each facility into structured fields
2. Handle multi-language content (translate/transliterate)
3. Map to standardized schemas (ISSUER_ID, FACILITY_NAME, etc.)

### Phase 4: Post-Processing
1. Clean addresses (remove `#` characters, normalize whitespace)
2. Transliterate foreign characters to ASCII
3. Map countries to standardized names
4. Map business activities to standardized list
5. Geocode missing coordinates with Bing Maps API
6. Validate and export to CSV

---

## Site-Specific Approaches

### Adobe Experience Manager (AEM) Sites
**Example**: continental-industry.com

**Key Characteristics**:
- Pages are very small HTML shells (~3-5KB) that load content via JS
- Content is stored in `/content/dam/` fragments
- APIs use GraphQL at paths like `/graphql/execute.json/{project}/{query}`
- Data is organized via tags (e.g., `contitech:media-assets/locations`)
- Cookie consent banners (ConsentManager) block content rendering
- Google Maps integration with embedded API keys and map IDs
- Country-specific pages at paths like `/about-us/business-area/{region}/{country}`

**What Worked**:
- Fetching raw HTML of country pages - addresses are embedded directly in accordion sections
- Pattern: `<div class="accordion single">` → `<h5>Facility Name</h5>` → `<p>Address<br>Line2<br>Country</p>`
- The `/forms/countries.json` endpoint gives a list of all countries with URLs
- GraphQL endpoint gives media assets (photos) with location names in titles

**What Did NOT Work**:
- Trying to render the page with Playwright and click "See more" - cookie consent banner blocks all clicks
- Trying to access the Google Maps widget via vendor consent - blocks in headless mode
- The media assets page (`/press/media-assets/locations`) only has photos, not facility data

**Best Approach for AEM**:
1. Fetch the raw HTML source (not rendered)
2. Parse embedded content from accordion/tab sections
3. Use BeautifulSoup to extract `<h5>`+`<p>` pairs
4. Different countries use different content structures (h4 vs h5, different languages)
5. Manual curation may be needed for accuracy with CJK languages

### Handling Cookie Consent Banners
- ConsentManager (`cmpbox`) intercepts all click events
- **Solution**: Use `page.evaluate('document.getElementById("cmpbox")?.remove()')` to remove the banner DOM element
- Some sites require accepting cookies to load map widgets - in headless mode this often fails
- Better to find the underlying API/data source than to try rendering the map

### Multi-Language Content
**Chinese (CJK)**:
- Company names and addresses are in Chinese characters
- Need manual transliteration mapping for company names (e.g., 康迪泰克 = ContiTech)
- Bing Geocoder can sometimes handle Chinese addresses directly
- Keep native language in separate columns (FACILITY_NAME_NATIVE, FACILITY_ADDRESS_NATIVE)

**Korean**:
- Similar to Chinese - Korean addresses use Korean script
- City/province names need romanization (충청남도 = Chungcheongnam-do)
- Postal codes may be embedded with Korean text

**European Languages (German, French, Spanish, Portuguese, Finnish, Swedish, etc.)**:
- Use Unicode normalization + character mapping for transliteration
- Replace: ä→ae, ö→oe, ü→ue, ß→ss, ñ→n, ç→c, etc.
- Keep the diacritical versions in native columns

---

## Geocoding

### Bing Maps API
- **URL**: `http://dev.virtualearth.net/REST/v1/Locations`
- **Params**: `q` (query string), `key` (API key), `maxResults`
- **Rate limiting**: 0.25-0.3 second delay between requests
- **Fallback strategy**: If full address fails, try city + country
- **Success rate**: ~98% with well-structured addresses
- **Failures**: Very long addresses, addresses with too much non-address text, some CJK addresses

### Best Practices
1. Always try the full address first
2. If that fails, try `{city}, {state}, {country}`
3. If that fails, try just `{city}, {country}`
4. Remove phone numbers, email addresses, and directions from the geocoding query
5. For CJK addresses, the English transliterated version often geocodes better

---

## Business Activity Mapping

### Approach
1. Examine facility name and description for keywords
2. Map to standardized business activity list
3. Common ContiTech/Continental mappings:
   - Manufacturing plant → "Manufacturing"
   - Sales/Service office → "Office"
   - Distribution center → "Warehouse"
   - Headquarters → "Office"
   - Service center/branch → "Office"
   - R&D facility → "Research & Development"

---

## Country Name Standardization

### Source
- Use the `countryname_iso3_SP.xlsx` file for standard names
- Common mappings needed:
  - "USA" → "United States of America (the)"
  - "UK" → "United Kingdom of Great Britain and Northern Ireland (the)"
  - "South Korea" → "Korea (the Republic of)"
  - "Suomi" → Finland, "Schweiz" → Switzerland, "Polska" → Poland, etc.

---

## Filtering Contact Persons from Facility Data

### Problem
Company location pages mix facility addresses with contact person details in the same HTML structure.

### Solution - Person Indicators
Look for these patterns to exclude non-facility entries:
- Titles: "Herr ", "Frau ", "Mr.", "Ms.", "Mrs.", "Dr."
- Roles: "Head of", "Manager", "Director", "Sales", "Analyst", "Supervisor"
- Foreign equivalents: "Gerente", "Jefe", "Gestora", "Engenheiro"
- Contact-only entries: "E-Mail", "Correo electrónico"

### Validation
- A real facility must have a numeric component in its address (house number, postal code)
- Address should be at least 15 characters
- Must have at least 2 address components when split by commas

---

## Tools & Dependencies

### Python Libraries
- `requests` - HTTP requests
- `beautifulsoup4` - HTML parsing
- `playwright` - Browser automation (for JS-rendered pages)
- `openpyxl` - Excel file reading
- `csv` - CSV output
- `unicodedata` - Unicode normalization

### APIs
- Bing Maps Geocoding API
- (Optional) Firecrawl API for complex JS rendering

---

## Lessons Learned

1. **Always check raw HTML first** - many AEM/CMS sites embed data in the static HTML even though they render it with JS
2. **Cookie consent is the #1 blocker** for headless browser scraping - find alternatives
3. **Country-specific pages** often have more detailed data than the main locations page
4. **API endpoints** (JSON/GraphQL) are always preferred over HTML scraping
5. **Manual curation** may be needed for CJK languages - automated transliteration is unreliable
6. **The page title says "locations" but it might be a media gallery** - always verify what kind of data the page actually contains
7. **Geocoding addresses with phone numbers embedded** will fail - always clean first
8. **Different countries on the same site may use different HTML structures** - one parser may not fit all

---

## File Inventory
- `extraction_approach.md` - This file
- `final_build.py` - The final comprehensive extraction script with manually curated facility data
- `comprehensive_extract.py` - Automated extractor that parses all country pages
- `get_graphql_locations.py` - GraphQL API explorer for AEM sites
- `arcgis_extraction_script.py` - ArcGIS FeatureServer extraction with reverse geocoding

---

## ArcGIS Experience Apps & Proxied FeatureServers

### Problem
ArcGIS Experience applications (at `experience.arcgis.com`) often fetch data from a proxy service (e.g., `utility.arcgis.com/usrsvcs/servers/...`). Direct API queries via `requests` often fail with code 403 (Forbidden) or 401 even when typical headers like `Referer` and `Origin` are provided.

### Key Characteristics
- Data is usually in Feature Layers (Layer 0, 1, 2...).
- Polygons (`rings`) are more common than single point data (`x`, `y`).
- Attributes might contain station/facility names but not exact street addresses.

### Best Approach
1. **Identify the Underlying Service**:
   - Use the browser's Network tab to find queries to `FeatureServer` or `MapServer`.
   - Note the `outSR` (Spatial Reference) and `f` (Format, e.g., `pbf` or `json`).
2. **Handle Geometry**:
   - If geometries are polygons, calculate the centroid by averaging all coordinates in the `rings` array.
   - Request `outSR=4326` to get standard WGS84 (Lat/Long).
3. **Capture Headers**:
   - The proxy requires a precise `Referer` header matching the Experience URL (including any trailing slashes or subpaths).
   - If headers still result in 403, the proxy likely uses session-specific cookies or tokens that are hard to replicate.
4. **Browser Console Extraction**:
   - Use a browser agent or manual console to run `fetch` directly from the application's origin. The browser already satisfies all CORS and Referer requirements.
   - Example command to run in console:
     ```javascript
     fetch("https://utility.arcgis.com/usrsvcs/servers/.../query?where=1=1&f=json&outSR=4326&returnGeometry=true&outFields=Station_Name")
       .then(r => r.json())
       .then(data => console.log(JSON.stringify(data.features)))
     ```
5. **Reverse Geocoding**:
   - Since ArcGIS datasets often lack street addresses (focusing on name and region), use the Bing Maps Reverse Geocoding API (`Locations/{lat},{lon}`) to derive the exact `FACILITY_ADDRESS`.
   - Ensure a 0.3s delay between Bing requests to stay within rate limits.

### Success with Hydro One (Ontario)
- **Source**: `https://experience.arcgis.com/experience/b54bdb9b061c4c30839935683a949d92`
- **Challenge**: 403 error on direct script access despite referer spoofing.
- **Solution**: Extracted 50 unique station names and geometries via browser console fetch.
- **Enrichment**: Reverse geocoded all 50 coordinates to get clean street addresses.
- **Activity Mapping**: Classified DER stations as "Transmission and distribution" and Corporate HQ as "Office" based on the standardized business activity list.


---

## BAJAJ FINANCE LIMITED â€” Full Extraction (Mar 2026)

### Sources and Results
| Source | URL | Records | Method |
|--------|-----|---------|--------|
| Bajaj Housing Finance (BHFL) | https://www.bajajhousingfinance.in/branch-locator | 94 | Static JSON (hfl-map-locations.json embedded in page) |
| Bajaj Allianz Life Insurance | https://branch.bajajallianzlife.com/ | 450 | Sitemap + LD+JSON structured data |
| Bajaj General Insurance (BAGIC) | https://www.bajajgeneralinsurance.com/branch-locator.html | 200 | Static HTML hidden div (#findgeneralinsurancebranch), BeautifulSoup parse |
| Bajaj Finserv (BFS) | https://nearme.bajajfinserv.in/ | 1516 | SingleInterface PHP API + URL navigation |
| **TOTAL** | | **2260** | |

### Key Approaches Used

#### BHFL (bajajhousingfinance.in)
- **Direct static JSON**: The page embeds branch data as JSON in a <script> tag loading hfl-map-locations.json.
- **How**: httpx + BeautifulSoup to find the script src, then fetch the JSON.

#### Bajaj Allianz Life (branch.bajajallianzlife.com)
- **Sitemap crawl**: Sitemap yielded thousands of individual branch URLs.
- **LD+JSON**: Each branch page had structured pplication/ld+json data with address, lat/lng, contact info.
- **How**: httpx + BeautifulSoup with concurrent fetching across sitemap URLs.

#### BAGIC (bajajgeneralinsurance.com/branch-locator.html)
- **Static HTML embedded data**: Despite an apparent AEM-powered dynamic form, all branch data was hidden in a div#findgeneralinsurancebranch as static HTML sections.
- **Key discovery**: Each section div (section1â€“section29) contained a state name and city names as <p> elements.
- **How**: Playwright to load full page â†’ page.evaluate() to get innerHTML â†’ BeautifulSoup to parse sections.
- **Pitfall**: AEM API endpoints returned 0/empty results; the real data was in static HTML.

#### BFS â€” nearme.bajajfinserv.in (SingleInterface platform)
- **Platform**: SingleInterface (SI) â€” provides state/city dropdown PHP APIs and location pages.
- **Working URL pattern**: https://nearme.bajajfinserv.in/?state_name={STATE_ALIAS}&city_name={CITY_ALIAS}
  - e.g. ?state_name=maharashtra&city_name=pune returns filtered outlets for that city.
- **State-City map API**: getCitiesByStateAliasAndMasterOutletIdsForMergedBrands.php
  - Called from inside browser context via page.evaluate() fetch (required due to CORS from external)
  - master_outlet_id=165979,269506,165978,165980,265243 (BFS/Bajaj Finance outlet IDs on SI)
  - Returns city aliases for each state.
- **Outlet parsing**: div.store-info-box elements, with:
  - input.outlet-latitude / input.outlet-longitude for lat/lng
  - [data-track-event-business-name] for name, city, state, URL
  - li.outlet-address span for address parts
  - [href^="tel:"] for phone
- **Scrolling**: Scroll up to 6 times to trigger infinite scroll, break when outlet count stabilizes.
- **Coverage**: 960 city Ã— state combinations, 1552 unique raw outlets, 1516 final (after dedup).

#### Bajaj Finserv â€” bajajfinserv.in/branch-locator (MapMyIndia)
- **Status**: NOT EXTRACTED â€” the main branch locator uses MapMyIndia APIs behind Akamai WAF.
- **Issues**:
  - Akamai bot detection: solved by using channel='msedge' Playwright (system Edge browser).
  - API key captured (df0ba7f2-5c24-4d1c-9470-e9b503aff372 from webservices.bajajfinserv.in/api/v1/storelocator/token).
  - But nearbyRecordFinder returns JSONP (not JSON), and direct httpx calls get SSL/412 errors.
  - CORS blocks cross-origin fetch from browser context.
  - **Alternative**: 
earme.bajajfinserv.in (SingleInterface) covers the same branches â€” preferred approach.

### Technical Gotchas

1. **CORS for SingleInterface APIs**: Must call from within browser context (page.evaluate with etch) â€” not via httpx externally.
2. **Hidden <select> elements**: SingleInterface dropdowns are visually hidden but can be queried via jQuery in page.evaluate. However the state/city URL parameter approach ()?state_name=X&city_name=Y) is simpler.
3. **6-outlet page limit**: Each city URL shows max 6 outlets at a time without scrolling. Scrolling down loads more via infinite scroll â€” scroll up to 6â€“8 times with 1.2s pauses.
4. **0-outlet cities**: Use short timeout (4s) for wait_for_selector("div.store-info-box") to quickly skip cities with no branches.
5. **SingleInterface master_outlet_id**: Must know the correct IDs for the company on the SI platform. Find by inspecting hidden inputs like <input id="master_outlet_id" value="..."> on the nearme page.
6. **State/City aliases**: The API uses slug-style aliases (e.g., "uttar-pradesh", "new-delhi"). Retrieve from SI cities API to get the exact aliases expected.

### Data Quality
- Deduplication by (LATITUDE, LONGITUDE, FACILITY_NAME) for records with coords; (FACILITY_NAME, CITY, STATE) for those without.
- Some cities (e.g. Ludhiana, Tirupur, Vellore) timed out due to site slowness â€” missed those outlets (retry separately if needed).
- 145 cities showed 0 outlets â€” either no BFS branches there or slight city alias mismatch.

### Recommended Generic Approach for SingleInterface Sites
1. Identify the nearme/store-locator subdomain using SingleInterface.
2. Find the master_outlet_id value from the page's hidden inputs.
3. Call getCitiesByStateAliasAndMasterOutletIdsForMergedBrands.php for each state to get city aliases.
4. Navigate to /?state_name=X&city_name=Y for each combination.
5. Wait for div.store-info-box, scroll down to load all, parse outlet elements.
6. Deduplicate by outlet_id or lat/lng+name.

---

## KOTAK MAHINDRA BANK LIMITED — Full Extraction (Mar 2026)

### Sources and Results
| Source | URL | Records | Method |
|--------|-----|---------|--------|
| Kotak Reach-Us Branch Locator | https://www.kotak.com/en/reach-us.html | 2248 | AEM Sling API (.map.reachus. selector) |
| **TOTAL** | | **2248** | |

### Key Approach Used

#### The AEM Sling `.map.reachus.` API
- **Discovery method**: Analyzed the `maps/clientlib.min.js` file which contains the branch search logic
- **State/City list API**: `GET https://www.kotak.com/kotak/getStateCityList`
  - Returns JSON: `{"stateCityDropDownData": {"STATE_NAME": ["CITY1", "CITY2", ...], ...}}`
  - 34 states, 1087 state+city combinations
  - City and state names are in **ALL CAPS**
- **Branch Search API** (AEM Sling selector pattern):
  ```
  https://www.kotak.bank.in/content/kotakcl/en/reach-us/_jcr_content/mid_par/maps
    .map.reachus.{b64(lat)}.{b64(lng)}.{b64(radius)}.{b64(callType)}.{pageNum}.{b64(identifier)}.json
  ```
  - `lat` = "0", `lng` = "0" (ignored for state+city search)
  - `radius` = "0.003" (from radious element value / 1000 = 3/1000)
  - `callType` = "userSearch"
  - `identifier` = "STATE|CITY" (ALL CAPS, pipe separator)
  - `pageNum` = 0 (literal integer, not base64)
  - Base64 is STANDARD base64 with `=` padding (NOT URL-safe)
  - Actual hostname in response is `kotak.bank.in` not `kotak.com`

#### Why the API Works
- The `mapsPath` hidden input in the HTML contains: `/content/kotakcl/en/reach-us/jcr:content/mid_par/maps`
- `jcr:content` is replaced with `_jcr_content` in the URL
- The `=` signs in base64 ARE valid in the AEM Sling URL path
- Required headers: `X-Requested-With: XMLHttpRequest`, `Referer: https://www.kotak.com/en/reach-us.html`

#### Response Structure
```json
{
  "Radius": 0.003,
  "BranchList": [{
    "branchOrATMType": 2,       // 1=ATM/Recycler, 2=Branch, 4=eLobby
    "ifscCode": "KKBK0001375",  // "NA" for ATMs
    "branchOrATMName": "Mumbai - Khar - S.V.Road",
    "addressValue": "Kotak Mahindra Bank Ltd; Ground Floor...",
    "cityName": "Mumbai",
    "stateName": "Maharashtra",
    "pincodeNumber": 400052,
    "latitudeValue": 19.071989,
    "longitudeValue": 71.837334,
    "phoneNumber": "1800 4100",
    "branchUrl": "mumbai-khar-s-v-road-kkbk0001375",
    "identityValue": 190088,    // unique ID for deduplication
    "servicesOffered": "SGL,SL,NPS,..."
  }]
}
```

#### Filtering
- Include `branchOrATMType == 2` (regular branches) with valid `ifscCode` starting with "KKBK"
- Exclude `branchOrATMType == 1` (ATMs, Recyclers - ifscCode = "NA")
- Optionally include `branchOrATMType == 4` (eLobby physical locations)
- Deduplicate by `identityValue`

#### URL Construction for Detail Pages
- `https://www.kotak.com/en/reach-us/detail/ifsc-code/{city_slug}/{branchUrl}.html`
- city_slug = city name in lowercase

#### Performance
- 1087 combinations at 0.3s delay = ~5-6 minutes
- API returns ALL branches in the city regardless of radius (radius is set to 0.003 but ignored)
- 2248 unique branches, 99.8% data quality (only 4 missing coordinates)

### Technical Gotchas
1. **Domain mismatch**: The page is at kotak.com but the API responds from kotak.bank.in. Both work fine with the same URL pattern.
2. **Case sensitivity**: State and city names must be ALL CAPS in the identifier parameter.
3. **base64 `=` in URL paths**: AEM Sling accepts `=` in path selectors. The 400 error I initially got was because I used wrong case for the identifier.
4. **Radius value**: Must be `0.003` (3 km / 1000) not empty string - derived from the `#radious` DOM element value of `3`.
5. **Page-level JS analysis**: The key API was found by reading `etc.clientlibs/kotak/components/content/maps/clientlib.min.js` which contains the full URL construction logic.
6. **Playwright needed for initial discovery**: The working URL format was confirmed by having Playwright execute the jQuery AJAX call from within the browser page context, since the URL encoding details needed to be verified.

### Data Quality Results
- Total branches: 2248
- Clean records: 2244/2248 (99.8%)
- Missing coordinates: 4/2248 (0.2%)
- All records have address, city, state, pincode

### Recommended Generic Approach for AEM Sites with Branch Locators
1. Load the branch locator page and inspect JS files loaded (especially `maps/clientlib.min.js` or similar)
2. Look for `getStateCityList` or similar state/city dropdown APIs
3. Find the `mapsComponent` hidden input for the base AEM path
4. Reconstruct the `.map.reachus.` (or similar) Sling selector URL with base64 parameters
5. Use Playwright to verify the URL format by executing jQuery AJAX from within the page
6. Once URL format confirmed, use httpx to iterate all state+city combinations
7. Filter by branch type, deduplicate by identity value, export

---

## E.SUN FINANCIAL HOLDING COMPANY, LTD. — Full Extraction (Mar 2026)

### Sources and Results
| Source | URL | Records | Method |
|--------|-----|---------|--------|
| Taiwan Branches | https://www.esunbank.com/zh-tw/about/locations/branch | 183 | Static HTML `var info = [...]` in script tag |
| Overseas Branches/Rep Offices | https://www.esunbank.com/zh-tw/about/locations/overseas-branch | 21 | Static HTML `var info = [...]` in script tag |
| **TOTAL (non-ATM)** | | **204** | |

### Key Discovery: URL Path Change
- User-provided URLs (`/zh-tw/locations/`) returned 404
- Correct paths are `/zh-tw/about/locations/` (discovered via navigation link inspection in Playwright)
- The site is NOT Next.js/React — it's a traditional server-rendered ASP.NET/Sitecore CMS

### Data Strategy: `var info = [...]` in Static HTML
- The branches page is 330KB+ HTML with ALL branch data embedded as `var info = [...]` in a `<script>` tag
- The script tag containing location data is typically the largest (100KB+) script on the page
- Extract with regex `var\s+info\s*=\s*(\[.*?\])\s*;` (with DOTALL)
- Bracket-depth parser needed as fallback when semicolon is ambiguous

### Branch Data Structure
```json
{
  "EDeptId": "0783",
  "EDept": "基隆分行",                     // Chinese name
  "EDeptEnglish": "Keelung Branch",         // English name
  "EDeptAddress": "202 基隆市中正區義一路122號",  // Chinese address
  "EDeptAddressEnglish": "No. 122,Yi 1st Rd.,Zhongzheng Dist., Keelung City 202001 , Taiwan",
  "Tel": "(02)2427-1313",
  "Latitude": 25.134554,
  "Longitude": 121.746849,
  "ZipCode": "202",                         // 3-digit old Taiwan postal code
  "LocationCatID": "1",                     // 1=Branch, 2=Securities, 3=HQ/Dept, 4=Invest, 5=VC
  "BranchTypeIDs": [1, 3, 4, 5, 6, 7],
  "ServiceTime": "09:00 - 15:30"
}
```

### Key Technical Gotchas

#### 1. EDeptAddress vs EDeptAddressEnglish Inconsistency
For overseas branches, the fields are REVERSED for many locations:
- Some locations have `EDeptAddressEnglish = ""` but `EDeptAddress` contains English text
- Detection: if `EDeptAddressEnglish` is empty and `EDeptAddress` has <10% CJK characters, treat it as English
- Function: `is_english_text(text)` checking CJK character density

#### 2. Taiwan Postal Codes
- Old format: 3-digit (e.g., "202", "105")
- New format: 6-digit with dash (e.g., "202-001", "105-46") → strip dash to get 6-digit code
- English addresses often contain the 6-digit code embedded (e.g., "Keelung City 202001")
- Regex for Taiwan dash-format: `r"\b(\d{3})-(\d{2,3})\b"` → concatenate groups

#### 3. Japan Postal Codes
- Format: XXX-YYYY (e.g., "100-6323" = 7 digits) → strip dash
- Regex: `r"\b(\d{3})-(\d{4})\b"` → concatenate

#### 4. Taiwan City Parsing (Greedy Regex Issue)
- Problem: "台中市西屯區市政路" — greedy `[\u4e00-\u9fff]+(?:市|縣)` matches "台中市西屯區市" (stops at second 市)
- Fix: Use `[\u4e00-\u9fff]{2,4}(?:市|縣)` with character count limit to prevent greedy over-match

#### 5. User-Provided URLs May Be Outdated
- Always test URLs with httpx first; if 404, inspect nav links in the main site to find correct paths

#### 6. Branch Count: Page Shows 100, Data Has 183
- The page shows pagination with max 100 records visible
- `var info` array in the HTML contains ALL records (183) regardless of pagination
- Always extract from the embedded JS array, not the visible list

### Location Pages Available
- `/zh-tw/about/locations/branch` — all branches (183 inc. securities, HQ)
- `/zh-tw/about/locations/atm` — ATMs (909 records)
- `/zh-tw/about/locations/foreign-currency-atm` — forex ATMs (143)
- `/zh-tw/about/locations/overseas-branch` — international offices (21)
- `/zh-tw/about/locations/bilingual-branch` — bilingual branches (table format, subset of 183)

### Quality Results
- Total non-ATM: 204 records
- Clean: 202/204 (99.0%)
- Coordinates: 204/204 (100%)
- Remaining issues: 2 MISSING_STATE (Singapore and Fukuoka, legitimately no state)

### Recommended Approach for Similar Taiwanese Bank Sites
1. Find the correct URL by inspecting navigation links (not trusting user-provided URLs)
2. Load the page with httpx (not Playwright needed for data extraction)
3. Find the largest script tag (100KB+) containing `var info = [...]`
4. Use bracket-depth parser to extract the JSON array
5. Handle EDeptAddress/EDeptAddressEnglish field reversal for overseas locations
6. Extract 6-digit postal codes from English addresses (with dash-stripping)
7. Use `{2,4}` char limit in city regex to prevent greedy over-matching

---

## CHROMA ATE INC. â€” Full Extraction (Mar 2026)

### Sources and Results
| Source | URL | Records | Method |
|--------|-----|---------|--------|
| Americas Region | https://www.chromaate.com/en/chroma/global/americas | 9 | Static HTML div.country_card parsing |
| Asia Region | https://www.chromaate.com/en/chroma/global/asia | 62 | Static HTML div.country_card parsing |
| Europe Region | https://www.chromaate.com/en/chroma/global/europe | 54 | Static HTML div.country_card parsing |
| **TOTAL** | | **121** (after dedup) | |

### Key Approach Used

#### Static HTML div.country_card Pattern
- Pages are large (100-180KB) server-rendered HTML â€” NO JavaScript rendering needed
- All facility/distributor data is embedded in <div class="country_card"> elements
- Each card structure:
  - <p class="countyr_name"> â€” country name (note: typo "countyr" is intentional in the source HTML!)
  - <span class="con_name"> â€” company name, optionally <br/> + office name
  - <ul><li> items: address, tel, fax, URL, email, social media (each prefixed with the field name)
- Data is 100% static â€” plain httpx requests suffice (no Playwright needed)
- SSL certificate issue: site uses a self-signed cert chain â†’ use erify=False

#### CJK Mixed-Language Content Handling
- Company names often have format: "English Name ä¸­æ–‡åç§°" in same text node
- Unlike E.SUN where fields are separated, here CJK and English share a single text node
- **Solution**: Use strip_cjk() â€” apply CJK regex removal then clean residual empty parentheses ()
- After stripping "ä¸­èŒ‚ç”µå­(æ·±åœ³)æœ‰é™å…¬å¸", "(æ·±åœ³)" â†’ "()" which needs additional cleanup: 
e.sub(r'\(\s*\)', '', result)
- Address <li> tags contain English address on first line, Chinese on subsequent lines after <br>
  - Walk children: stop at first <br> tag; only collect non-CJK NavigableString children

#### Address Parsing (International Multi-Country)
The extractor handles 30+ countries with country-specific postal/city parsing:

**Key patterns discovered:**
1. **USA standard**: "Street, City, ST ZIPCODE, USA" â†’ regex ,\s*([A-Z]{2})\s+(\d{5}) for abbreviated states
2. **USA spelled-out state**: "City, Arizona 85225, USA" â†’ requires US_STATE_TO_ABBR lookup table
3. **USA embedded city**: "734 Forest St. Suite 500 Marlborough, MA 01752" â†’ city = last capitalized word(s) before a STREET_SUFFIX
4. **China**: Postal code embedded as "PC:518052" suffix â†’ regex PC:?\s*(\d{6})
5. **Czech/Italy**: City comes AFTER postal code â†’ "619 00, Brno" â†’ extract city from fter segment post-postal
6. **Turkey/Israel**: Similar â€” postal then city in next comma segment
7. **Germany**: "D-72770 Reutlingen" or "86165 Augsburg" â†’ \b(\d{5})\s+CityName
8. **Netherlands**: "6716 AH Ede" â†’ (\d{4}\s*[A-Z]{2})\s+CityName (alphanumeric postal)
9. **Brazil**: "Porto Alegre â€“ RS" (cityâ€“state, no street) â†’ regex ^(.+?)\s*[â€“â€”-]\s*([A-Z]{2})
10. **India**: City BEFORE postal â†’ extract last non-numeric part before the 6-digit postal code

**Generic city cleanup rules (apply after all country-specific parsing):**
- Strip leading digits from city field
- Strip trailing en/em dashes (â€“, â€”) and hyphens from city (Indian addresses use "City â€“ PIN")
- Remove trailing commas and whitespace

#### Data Coverage
- 121 total unique facilities (9 Americas + 62 Asia + 54 Europe, after 4 dupes removed)
- Includes both Chroma direct subsidiaries AND third-party distributors/resellers listed on the site
- No coordinates provided in source (expected â€” field left blank per SKILL rules)
- No maps or API endpoints for geodata

### Technical Gotchas

1. **CSS class typo**: The country name class is countyr_name NOT country_name. Copy carefully from page source.
2. **Mixed CJK+English in same text node**: Need strip_cjk() not just is_cjk_heavy() filtering. The latter drops the entire text node (including the English part). Strip CJK characters individually instead.
3. **Empty parentheses artifact**: After CJK removal, (æ·±åœ³) becomes (). Always add 
e.sub(r'\(\s*\)', '', ...) after CJK stripping.
4. **SSL verification failure**: chromaate.com uses a self-signed intermediate cert. Use erify=False with httpx.
5. **Austria distributor with German address**: dataTec AG is listed under Austria but has a German address (D-72770 Reutlingen). Handle with D-XXXXX prefix detection before Austrian XXXX 4-digit parsing.
6. **Japan postal codes are 7 digits**: The standard validator (^\d{4,6}$) will flag all Japanese postal codes as BAD_PIN. This is a known validator limitation â€” Japanese format is XXXXXXX (7 digits). Accept as valid.
7. **Duplicate records**: 4 duplicates found across the 125 raw records. Deduplicate by (facility_name.lower(), address.lower()).

### Data Quality Final Results
- Total records: 121 unique
- MISSING_COORDS: 121/121 (expected â€” no geodata in source)
- MISSING_STATE: 112/121 (expected â€” international records don't use US-style state)
- BAD_PIN: 32/121 (acceptable â€” Japan 7-digit, Netherlands alphanumeric, Poland hyphenated)
- MISSING_PIN: 21/121 (some distributor listings have incomplete addresses)
- MISSING_CITY: 2/121 (2 records have no address at all on the source page)
- MISSING_ADDRESS: 2/121 (same 2 records)

### Recommended Generic Approach for Similar Corporate Global Pages
1. Check if pages have div.country_card or similar card-style containers â€” very common pattern
2. Use BeautifulSoup on raw httpx HTML (no Playwright needed)
3. Look for <ul><li> structure within cards â€” field type indicated by text prefix ("Tel:", "Fax:", "URL:", "Email:")
4. Address field = the li that doesn't start with any of the known prefixes
5. CJK-mixed text: always strip CJK characters rather than dropping the whole text node
6. Use country-specific postal/city parsing for international data
7. No coordinates expected from corporate directory pages â€” don't geocode

---

## Generic Feedback Points for All Extractions

- **Always check raw HTML first** â€” many corporate global pages have ALL data statically embedded (no JS rendering)
- **CJK stripping vs CJK filtering**: For mixed bilingual text nodes, strip CJK chars (keep the English), don't drop the whole node
- **Country-aware validators**: The default ^\d{4,6}$ postal code validator is India/US-centric. Japan uses 7 digits, Netherlands uses alphanumeric, Taiwan uses 3-digit (old) or 6-digit (new). Adjust validation accordingly.
- **Self-signed SSL certs**: Use erify=False for sites with self-signed chains (common for APAC companies)
- **CSS class typos in source HTML**: Check actual element attributes â€” companies sometimes have typos in their own HTML (e.g., countyr_name instead of country_name)
- **City-after-postal patterns**: Czech, Italy, Turkey, Israel often put the city AFTER the postal code in their address strings (reverse of US/Germany pattern)
- **Multi-country corporate pages**: A single page may list 30+ countries, each with different address formats â€” the parser must be country-aware

---

## CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD. (CATL) â€” Full Extraction (Mar 2026)

### Issuer Details
- **Issuer:** CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD.
- **ISSUER_ID:** IID000000002841129
- **Source URL:** `https://www.catl.com/en/uploads/1/image/public/202603/20260317210914_ny0ie1ycx1.png` (map image from CATL website, dated 2026-03-17)

### Sources and Results
| Source | URL / Method | Records |
|--------|-------------|---------|
| CATL Contact Us page (direct scrape) | https://www.catl.com/en/contactus/ | 10 (HQ + 9 subsidiaries) |
| Tavily web search (plant addresses) | Various queries | 7 additional plants |
| LinkedIn company page | linkedin.com/company/contemporary-amperex-technology-gmbh | 1 (Auburn Hills MI) |
| CATL Annual Report 2024 (PDF search) | catl.com annual report | Confirmed 13 mfg bases |
| CATL News articles | catl.com/en/news/ | 5 plant groundbreaking/inauguration details |
| **TOTAL** | | **21** |

### What Worked
1. **Direct scraping of English contact page** (`https://www.catl.com/en/contactus/`) was the single most valuable action â€” returned a clean table with 10 facilities including full addresses and phone numbers.
2. **Tavily targeted searches** filled in Chinese manufacturing plants not on the contact page (Xiamen, Yichun, Guiyang/Gui'an, Jining/Yanzhou, Luoyang, Fuding).
3. **CATL Annual Report search** (`catl.com/en/uploads/1/file/public/...annual report pdf`) confirmed the official count: 13 manufacturing bases as of Dec 31, 2024.
4. **LinkedIn company page** revealed Auburn Hills, Michigan office (2455 Featherstone Rd) not listed on CATL's own website.
5. **CATL news pages** (`catl.com/en/news/XXXX.html`) provided city/district-level location for groundbreaking ceremonies (e.g., Haicang District for Xiamen, Gui'an New Area for Guiyang).
6. **Bing Maps geocoding** worked for all 21 facilities including Chinese addresses â€” 100% success rate.

### What Did NOT Work
- **Azure OpenAI GPT-4o** â€” deployment name "gpt-4o" returned 404 (deployment not provisioned in this Azure resource). Other names (gpt-4o-mini, gpt-4, gpt-4-turbo) also failed. **o3-mini** was found to work but does NOT support vision/images.
- **Google Gemini 1.5 Pro** (old `google.generativeai` SDK) â€” deprecated SDK, model not accessible.
- **Google Gemini 2.0 Flash** (new `google.genai` SDK) â€” free tier quota RESOURCE_EXHAUSTED (429).
- **Firecrawl API** â€” 402 Insufficient Credits.
- **CATL `/en/about/`** â€” 403 Forbidden.
- **CATL `/en/about/factories/`** â€” 404 Not Found.
- Vision-based approach for image extraction was entirely blocked by API quota/availability issues â€” fell back to web scraping.

### CATL's 13 Manufacturing Bases (official, as of Dec 2024 Annual Report)
- **Domestic (11):** Ningde/Fujian (HQ), Fuding/Fujian, Xining/Qinghai, Liyang/Jiangsu, Yibin/Sichuan, Zhaoqing/Guangdong, Shanghai (Lingang), Xiamen/Fujian, Yichun/Jiangxi, Guiyang/Guizhou (Gui'an New Area), Jining/Shandong (Yanzhou District), Luoyang/Henan
- **Overseas (2):** Arnstadt/Germany (Thuringia), Debrecen/Hungary

### 21 Facilities Extracted
| No. | Facility | City | Country | Source |
|-----|----------|------|---------|--------|
| 1 | CATL Global Headquarters | Ningde | China | Contact page |
| 2 | Fuding Battery Base | Ningde (Fuding) | China | News |
| 3 | Guangdong Ruiqing CAT Ltd | Zhaoqing | China | Contact page |
| 4 | Jiangsu CAT Ltd | Liyang | China | Contact page |
| 5 | Qinghai CAT Ltd | Xining | China | Contact page |
| 6 | Ruiting CAT (Shanghai) Ltd | Shanghai | China | Contact page |
| 7 | Sichuan CAT Ltd | Yibin | China | Contact page |
| 8 | Xiamen Battery Base | Xiamen | China | News/Annual Report |
| 9 | Yichun Battery Base | Yichun | China | News/Annual Report |
| 10 | Guiyang Battery Base | Guiyang | China | News/Annual Report |
| 11 | CATL Shandong (Jining) | Jining | China | News/Annual Report |
| 12 | Zhongzhou CAT (Luoyang) | Luoyang | China | News/Annual Report |
| 13 | CAT Thuringia GmbH | Arnstadt | Germany | Contact page |
| 14 | CAT GmbH (Munich) | Munich | Germany | Contact page |
| 15 | CATL Hungary Battery Factory | Debrecen | Hungary | Web search |
| 16 | CAT France | Paris | France | Contact page |
| 17 | CAT Japan K.K. | Yokohama | Japan | Contact page |
| 18 | CAT (USA) Inc | Wilmington, DE | USA | Contact page |
| 19 | CATL Auburn Hills Office | Auburn Hills, MI | USA | LinkedIn |
| 20 | NING SERVICE Center Riyadh | Riyadh | Saudi Arabia | News (Jan 2026) |
| 21 | CAT Europe Nanterre Office | Nanterre | France | LinkedIn |

### Key Technical Details

#### CATL Contact Page Parsing (most valuable)
- URL: `https://www.catl.com/en/contactus/`
- Returns plain HTML table: `Company Name | Address | Contact Information`
- Works with simple `requests.get()` + BeautifulSoup
- **No JavaScript rendering needed** (data is in static HTML)
- SSL works fine without `verify=False` on CATL's domain

#### Chinese contact page (`https://www.catl.com/contactus/`) 
- Contains same facilities in Chinese characters + some additional Chinese addresses
- Jiangsu address differs: English page shows "No. 1000, Chengbei Road"; Chinese shows "å—å¤§è¡—çŽ¯å²›è¥¿è·¯328å·" (different buildings of same facility)
- Run Python with `-X utf8` flag or `sys.stdout.reconfigure(encoding='utf-8')` to handle CJK output

#### Address Construction for Plants Without Street Addresses
- When only district/zone is available: use `{district/zone}, {city}, {province}` 
- Example: Xiamen â†’ "Haicang District, Xiamen, Fujian" (from news article groundbreaking ceremony location)
- Example: Guiyang â†’ "Gui'an New Area, Guiyang, Guizhou" (from news article)
- These district-level addresses geocode correctly with Bing Maps

#### Geocoding Performance
- **Bing Maps API:** 100% success rate on all 21 facilities
- Chinese addresses like "No. 182, Chuangye Road, Nanchuan Industry Park, Xining, Qinghai" geocode perfectly
- No need to fall back to city-only queries for Chinese addresses when the full address from the website is used
- Rate limit: 0.3s delay between requests is sufficient

### Reusable Approach for Manufacturing Company Image Sources
When the source is an **image URL** (map infographic from a company website):
1. First try to identify which company page embeds the image
2. Go directly to the company's Contact Us / About / Factories pages instead
3. The image is usually a visual summary of data that's already available in structured form on the website
4. Vision LLM is useful only if the image contains unique data NOT on any other page

### Output File
- **CSV:** `CATL_Facilities.csv` in `C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection\`
- **Columns:** ISSUER_ID, ISSUER_NAME, FACILITY_NAME, FACILITY_ADDRESS, CITY, STATE, POSTAL_CODE, FACILITY_REGION, LATITUDE, LONGITUDE, FACILITY_CONTACT_NUMBER, RELEVANT_URL, ACTIVITY_AT_SOURCE, coord_source, FACILITY_NAME_NATIVE, FACILITY_ADDRESS_NATIVE
- **Script:** `catl_build_csv.py` (hardcoded data + Bing geocoding)

---
