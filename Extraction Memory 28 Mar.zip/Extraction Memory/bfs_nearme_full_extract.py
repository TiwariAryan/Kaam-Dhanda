"""
BFS Full Extraction — nearme.bajajfinserv.in
Uses /?state_name=X&city_name=Y URL pattern (confirmed working).
Iterates all 960 state-city combinations, scrolls to load all outlets.
"""
import asyncio
import json
import sys
import re
import time
from datetime import datetime
from pathlib import Path

from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

OUT = Path("bajaj_finance_output")
OUT.mkdir(exist_ok=True)

NEARME_URL = "https://nearme.bajajfinserv.in"
STATE_CITY_MAP_FILE = OUT / "bfs_state_city_full.json"
PROGRESS_FILE = OUT / "bfs_extract_progress.json"
OUTLETS_FILE = OUT / "bfs_all_outlets.json"

SCHEMA = [
    "FACILITY_NAME", "FACILITY_ADDRESS", "FACILITY_ADDRESS_2",
    "CITY", "STATE", "PINCODE", "LATITUDE", "LONGITUDE",
    "PHONE", "RELEVANT_URL", "SOURCE_URL", "BUSINESS_ACTIVITY",
]


def log(msg):
    print(msg, flush=True)


def parse_store_info_box(el) -> dict:
    """Parse a store-info-box element into structured outlet data."""
    outlet = {}

    lat_inp = el.find("input", class_="outlet-latitude")
    lng_inp = el.find("input", class_="outlet-longitude")
    if lat_inp:
        outlet["latitude"] = lat_inp.get("value", "").strip()
    if lng_inp:
        outlet["longitude"] = lng_inp.get("value", "").strip()

    name_a = el.find("a", attrs={"data-track-event-business-name": True})
    if name_a:
        outlet["name"] = name_a.get("data-track-event-business-name", "").strip()
        outlet["name_display"] = name_a.get_text(strip=True)
        outlet["city"] = name_a.get("data-track-event-city", "").strip()
        outlet["state"] = name_a.get("data-track-event-state", "").strip()
        outlet["url"] = name_a.get("href", "").strip()
        id_m = re.search(r'-(\d{4,8})/Home', outlet["url"])
        if id_m:
            outlet["outlet_id"] = id_m.group(1)

    addr_li = el.find("li", class_="outlet-address")
    if addr_li:
        spans = addr_li.find_all("span")
        addr_parts = [s.get_text(strip=True) for s in spans if s.get_text(strip=True)]
        outlet["address_raw"] = " | ".join(addr_parts)
        for sp in spans:
            t = sp.get_text(strip=True)
            if re.match(r'^\d{6}$', t):
                outlet["pincode"] = t

    phone_a = el.find("a", href=re.compile(r'^tel:'))
    if phone_a:
        outlet["phone"] = phone_a.get_text(strip=True)

    return outlet


def to_schema_row(outlet: dict) -> dict:
    """Convert raw outlet dict to standard schema."""
    # Parse address_raw into parts
    addr_raw = outlet.get("address_raw", "")
    addr_parts = [p.strip() for p in addr_raw.split("|") if p.strip()]

    # First 2 parts are address lines, then locality, then city-pincode, then city, then -, then pincode
    addr1 = addr_parts[0] if len(addr_parts) > 0 else ""
    addr2 = addr_parts[1] if len(addr_parts) > 1 else ""

    name = outlet.get("name_display") or outlet.get("name", "Bajaj Finserv")
    if not name:
        name = "Bajaj Finserv"

    return {
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": addr1,
        "FACILITY_ADDRESS_2": addr2,
        "CITY": outlet.get("city", ""),
        "STATE": outlet.get("state", ""),
        "PINCODE": outlet.get("pincode", ""),
        "LATITUDE": outlet.get("latitude", ""),
        "LONGITUDE": outlet.get("longitude", ""),
        "PHONE": outlet.get("phone", ""),
        "RELEVANT_URL": outlet.get("url", ""),
        "SOURCE_URL": NEARME_URL,
        "BUSINESS_ACTIVITY": "Financial Services",
    }


async def get_outlets_for_city(page, state: str, city: str) -> list:
    """Navigate to city URL, scroll to load all outlets, return parsed outlet list."""
    url = f"{NEARME_URL}/?state_name={state}&city_name={city}"
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=15000)
    except Exception as e:
        log(f"    Timeout/error loading {state}/{city}: {e}")
        return []

    # Wait for outlets to appear (short timeout - if none, move on quickly)
    try:
        await page.wait_for_selector("div.store-info-box", timeout=4000)
    except Exception:
        # No outlets found for this city
        return []

    # Scroll down to trigger infinite scroll / load more
    prev_count = 0
    for scroll_attempt in range(6):
        await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        await asyncio.sleep(1.2)

        # Check if a "Load More" button exists and click it
        try:
            load_more = page.locator("button.load-more, .load-more-btn, [class*='load-more'], .show-more")
            count = await load_more.count()
            if count > 0:
                await load_more.first.click()
                await asyncio.sleep(1.5)
        except Exception:
            pass

        html = await page.content()
        soup = BeautifulSoup(html, "html.parser")
        outlets = soup.find_all("div", class_="store-info-box")
        curr_count = len(outlets)

        if curr_count == prev_count and scroll_attempt > 1:
            break  # No more items loading
        prev_count = curr_count

    html = await page.content()
    soup = BeautifulSoup(html, "html.parser")
    outlet_els = soup.find_all("div", class_="store-info-box")
    results = []
    for el in outlet_els:
        data = parse_store_info_box(el)
        if data.get("outlet_id") or data.get("name"):
            results.append(data)
    return results


async def main():
    log("=" * 70)
    log("BFS Full Extraction — nearme.bajajfinserv.in")
    log("=" * 70)

    # Load state-city map
    with open(STATE_CITY_MAP_FILE, encoding="utf-8") as f:
        state_city_map = json.load(f)

    total_cities = sum(len(v) for v in state_city_map.values())
    log(f"Loaded {len(state_city_map)} states, {total_cities} cities")

    # Load progress (for resume)
    all_outlets = {}  # outlet_id -> outlet dict
    done_states = set()
    done_cities = {}  # state -> set of done cities

    if OUTLETS_FILE.exists():
        with open(OUTLETS_FILE, encoding="utf-8") as f:
            all_outlets = json.load(f)
        log(f"Resumed: {len(all_outlets)} outlets already captured")

    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, encoding="utf-8") as f:
            prog = json.load(f)
        done_cities = {s: set(cities) for s, cities in prog.get("done_cities", {}).items()}
        log(f"Resumed progress: {sum(len(v) for v in done_cities.values())} cities done")

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            channel="msedge",
            headless=False,
            args=["--disable-blink-features=AutomationControlled"],
        )
        ctx = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0",
            viewport={"width": 1280, "height": 900},
        )
        page = await ctx.new_page()
        await page.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )

        # Warm up - load the main page once to establish cookies/session
        log("\nWarm-up: loading main page...")
        try:
            await page.goto(NEARME_URL + "/", wait_until="domcontentloaded", timeout=30000)
        except Exception:
            pass
        await asyncio.sleep(2)

        processed = 0
        total_processed = sum(len(v) for v in done_cities.values())

        for state, cities in state_city_map.items():
            state_done = done_cities.get(state, set())
            cities_to_do = [c for c in cities if c not in state_done]

            if not cities_to_do:
                log(f"\n[SKIP] {state} — all {len(cities)} cities done")
                continue

            log(f"\n[STATE] {state} — {len(cities_to_do)}/{len(cities)} cities remaining")

            for city in cities_to_do:
                total_processed += 1
                pct = total_processed * 100 // total_cities
                log(f"  [{pct}%] {state}/{city}", )

                outlets = await get_outlets_for_city(page, state, city)
                new_count = 0
                for o in outlets:
                    key = o.get("outlet_id") or f"{o.get('latitude','')},{o.get('longitude','')}" or o.get("name", "")
                    if key and key not in all_outlets:
                        all_outlets[key] = o
                        new_count += 1

                log(f"    → {len(outlets)} shown, {new_count} new | Total: {len(all_outlets)}")

                # Mark city done
                if state not in done_cities:
                    done_cities[state] = set()
                done_cities[state].add(city)

                processed += 1

                # Save progress every 20 cities
                if processed % 20 == 0:
                    with open(OUTLETS_FILE, "w", encoding="utf-8") as f:
                        json.dump(all_outlets, f, ensure_ascii=False, indent=2)
                    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
                        json.dump({"done_cities": {s: list(c) for s, c in done_cities.items()}}, f)
                    log(f"    [SAVED] {len(all_outlets)} total outlets")

                await asyncio.sleep(0.3)  # Brief pause between cities

            # Save after each state
            with open(OUTLETS_FILE, "w", encoding="utf-8") as f:
                json.dump(all_outlets, f, ensure_ascii=False, indent=2)
            with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
                json.dump({"done_cities": {s: list(c) for s, c in done_cities.items()}}, f)
            log(f"[SAVED STATE] {state} complete. Total outlets: {len(all_outlets)}")

        await browser.close()

    log(f"\n{'='*70}")
    log(f"EXTRACTION COMPLETE")
    log(f"Total unique outlets: {len(all_outlets)}")

    # Save final results
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Convert to schema rows
    rows = [to_schema_row(o) for o in all_outlets.values()]
    df = pd.DataFrame(rows, columns=SCHEMA)
    df = df.drop_duplicates(subset=["LATITUDE", "LONGITUDE", "FACILITY_NAME"])
    df = df[df["FACILITY_NAME"].notna() & (df["FACILITY_NAME"] != "")]

    json_path = OUT / f"BFS_NEARME_{ts}.json"
    xlsx_path = OUT / f"BFS_NEARME_{ts}.xlsx"
    df.to_json(json_path, orient="records", indent=2, force_ascii=False)
    df.to_excel(xlsx_path, index=False)

    log(f"Final records: {len(df)}")
    log(f"Saved: {json_path}")
    log(f"Saved: {xlsx_path}")

    return df


if __name__ == "__main__":
    asyncio.run(main())
