import pandas as pd
import requests
import time
import os
import json
import urllib3
import unicodedata

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# BING API DETAILS
BING_KEY = "yGyflKQJyJ3lNV3yKcYP~FSPEyZhJWuaj1EsG7Ajmkg~AkM_12vG3agHCBs6OD3BxSGIJ38YadqKG687egd-7Mvzp4qrkNnMMvbal7v3xIYw"
BING_URL = "http://dev.virtualearth.net/REST/v1/Locations"

def clean_address(addr):
    if not addr: return ""
    return addr.replace("#", "").strip()

def transliterate(text):
    if not text: return ""
    # Normalize to NFD and keep the base characters
    nfd_form = unicodedata.normalize('NFD', text)
    only_ascii = nfd_form.encode('ascii', 'ignore').decode('utf-8')
    return only_ascii

def get_bing_address(lat, lon):
    try:
        url = f"http://dev.virtualearth.net/REST/v1/Locations/{lat},{lon}"
        params = {
            'key': BING_KEY,
            'includeEntityTypes': 'Address',
            'o': 'json'
        }
        r = requests.get(url, params=params, timeout=10)
        if r.status_code == 200:
            data = r.json()
            if 'resourceSets' in data and len(data['resourceSets']) > 0:
                resources = data['resourceSets'][0].get('resources', [])
                if resources:
                    addr = resources[0].get('address', {})
                    return addr
    except Exception as e:
        print(f"Error geocoding {lat},{lon}: {e}")
    return None

# LIST OF STATIONS FROM BROWSER SUBAGENT
stations_raw = """
DRYDEN TS, 49.8027, -92.8315
BARWICK TS, 48.6275, -93.7051
HEARST TS, 49.6211, -83.2970
KAPUSKASING TS, 49.4053, -82.4457
MANITOUWADGE TS, 49.1651, -85.3294
RAMORE TS, 48.4379, -80.3519
TIMMINS TS, 48.5078, -81.4981
ELLIOT LAKE TS, 46.4145, -82.6452
ESPANOLA TS, 46.2807, -81.7765
MANITOULIN TS, 45.8429, -82.2433
CRYSTAL FALLS TS, 46.4175, -79.9219
TROUT LAKE TS, 46.2193, -79.3656
CLARABELLE TS, 46.5556, -81.0299
LARCHWOOD TS, 46.6071, -81.3359
MARTINDALE TS, 46.2221, -80.7075
MIDHURST TS DESN1, 44.3832, -79.7846
STAYNER TS, 44.4506, -80.1779
WAUBAUSHENE TS, 44.6747, -79.7544
MINDEN TS, 45.0203, -78.4539
MUSKOKA TS, 45.1084, -79.5901
ORILLIA TS, 44.6494, -79.5452
PARRY SOUND TS, 45.4456, -80.1628
ALMONTE TS, 45.2696, -76.2514
ARNPRIOR TS, 45.4262, -76.3384
SOUTH MARCH TS, 45.2983, -75.9416
STEWARTVILLE TS, 45.3994, -76.5632
BROCKVILLE TS, 44.7053, -75.5954
COBDEN TS, 45.5549, -77.1801
PEMBROKE TS, 45.7980, -77.0974
WALLACE TS, 45.4869, -77.8271
CROSBY TS DESN1, 44.6543, -76.3210
SMITHS FALLS TS, 44.9169, -76.1137
LONGUEUIL TS, 45.5169, -74.6115
ST ISIDORE TS, 45.4463, -74.9845
ST LAWRENCE TS, 45.0645, -74.7992
BILBERRY CREEK TS, 45.4872, -75.5173
CHESTERVILLE TS, 45.1083, -75.2699
HAWTHORNE TS, 45.2228, -75.5454
MORRISBURG TS, 44.8116, -75.3701
PORT HOPE TS DESN1, 44.0943, -78.2627
PORT HOPE TS DESN2, 43.9592, -78.2587
BEAVERTON TS, 44.4959, -79.0853
LINDSAY TS, 44.3656, -78.7435
FRONTENAC TS, 44.3050, -76.3981
DOBBIN TS, 44.2256, -78.4301
NAPANEE TS, 44.2539, -76.9816
PICTON TS, 43.9885, -77.1257
ALLISTON TS, 44.2592, -79.7857
WILSON TS DESN2, 43.9904, -78.8435
PORT ARTHUR TS #1, 48.6161, -89.0242
"""

data_rows = []
lines = [l.strip() for l in stations_raw.split("\n") if l.strip()]

# Add HQ
data_rows.append({
    'FACILITY_NAME': 'Hydro One Corporate Headquarters',
    'LATITUDE': 43.6542,
    'LONGITUDE': -79.3824,
    'ACTIVITY_AT_SOURCE': 'Corporate Headquarters',
    'RELEVANT_URL': 'https://www.hydroone.com',
    'coord_source': 'search'
})

for line in lines:
    parts = line.split(",")
    name = parts[0].strip()
    lat = parts[1].strip()
    lon = parts[2].strip()
    data_rows.append({
        'FACILITY_NAME': name,
        'LATITUDE': float(lat),
        'LONGITUDE': float(lon),
        'ACTIVITY_AT_SOURCE': 'Estimated Available Distribution Generation Capacity Zone (DER Station)',
        'RELEVANT_URL': 'https://experience.arcgis.com/experience/b54bdb9b061c4c30839935683a949d92',
        'coord_source': 'website'
    })

results = []
for row in data_rows:
    print(f"Processing: {row['FACILITY_NAME']}")
    bing_addr = get_bing_address(row['LATITUDE'], row['LONGITUDE'])
    
    # Defaults
    city = ""
    state = "Ontario"
    postal = ""
    address = ""
    country = "Canada"
    
    if bing_addr:
        address = bing_addr.get('addressLine', "")
        city = bing_addr.get('locality', "")
        state = bing_addr.get('adminDistrict', "Ontario")
        postal = bing_addr.get('postalCode', "")
        # If address is still blank, try formattedAddress
        if not address:
            address = bing_addr.get('formattedAddress', "").split(",")[0]
            
    # Cleaning
    address = clean_address(address) if address else "Unknown Location"
    
    # Transliteration
    native_name = row['FACILITY_NAME']
    native_address = address
    
    clean_name = transliterate(native_name)
    clean_address_final = transliterate(address)
    
    # Mapping Business Activity
    if "Headquarters" in row['ACTIVITY_AT_SOURCE']:
        biz_act = "Office"
    else:
        biz_act = "Transmission and distribution"
        
    res = {
        'ISSUER_ID': 'IID000000002745802',
        'ISSUER_NAME': 'HYDRO ONE LIMITED',
        'FACILITY_NAME': clean_name,
        'FACILITY_ADDRESS': clean_address_final,
        'CITY': transliterate(city),
        'STATE': transliterate(state),
        'POSTAL_CODE': postal,
        'FACILITY_REGION': country,
        'LATITUDE': row['LATITUDE'],
        'LONGITUDE': row['LONGITUDE'],
        'FACILITY_CONTACT_NUMBER': '', # Not available per station on ArcGIS
        'RELEVANT_URL': row['RELEVANT_URL'],
        'ACTIVITY_AT_SOURCE': row['ACTIVITY_AT_SOURCE'],
        'BUSINESS_ACTIVITY': biz_act,
        'FACILITY_NAME_NATIVE': native_name if native_name != clean_name else "",
        'FACILITY_ADDRESS_NATIVE': native_address if native_address != clean_address_final else "",
        'coord_source': row['coord_source']
    }
    results.append(res)
    time.sleep(0.3) # Bing Rate Limit

# Export to CSV
output_path = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\WORLD Re-work\Re-collection\IID000000002745802_HYDRO_ONE_LIMITED.csv"
df = pd.DataFrame(results)
df.to_csv(output_path, index=False, encoding='utf-8-sig')
print(f"Exported {len(results)} facilities to {output_path}")
