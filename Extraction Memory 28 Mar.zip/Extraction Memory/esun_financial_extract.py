"""
E.SUN FINANCIAL HOLDING COMPANY, LTD. — Branch & Overseas Office Extractor
Sources:
  - https://www.esunbank.com/zh-tw/about/locations/branch (183 domestic facilities)
  - https://www.esunbank.com/zh-tw/about/locations/overseas-branch (21 international)

Strategy: Static HTML — all location data is embedded as `var info = [...]` in script tags.
Usage: python -m issuers.e_sun_financial.extract
"""
import asyncio
import json
import re
import sys
from pathlib import Path

import httpx
from bs4 import BeautifulSoup

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from issuers.common import (
    log, COLUMNS, quality_report, print_sample,
    save_json, export_xlsx, archive_scripts,
)

ISSUER = "E.SUN FINANCIAL HOLDING COMPANY,LTD."
BASE_URL = "https://www.esunbank.com"
OUT = "e_sun_financial_output"
ISSUER_DIR = Path(__file__).parent

LOCATION_URLS = {
    "domestic": f"{BASE_URL}/zh-tw/about/locations/branch",
    "overseas": f"{BASE_URL}/zh-tw/about/locations/overseas-branch",
}

COUNTRY_MAP = {
    "香港": "Hong Kong",
    "中國": "China",
    "美國": "United States of America (the)",
    "日本": "Japan",
    "澳大利亞": "Australia",
    "新加坡": "Singapore",
    "越南": "Viet Nam",
    "緬甸": "Myanmar",
    "泰國": "Thailand",
    "馬來西亞": "Malaysia",
    "柬埔寨": "Cambodia",
}

ACTIVITY_MAP = {
    "1": "Banking",
    "2": "Banking; Securities Trading",
    "3": "Banking",
    "4": "Banking; Investment Consulting",
    "5": "Banking; Venture Capital",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7",
    "Referer": "https://www.esunbank.com/",
}

# Taiwan city to English name mapping (for CITY field)
TW_CITY_EN = {
    "基隆市": "Keelung City",
    "臺北市": "Taipei City",
    "台北市": "Taipei City",
    "新北市": "New Taipei City",
    "桃園市": "Taoyuan City",
    "新竹市": "Hsinchu City",
    "新竹縣": "Hsinchu County",
    "苗栗縣": "Miaoli County",
    "臺中市": "Taichung City",
    "台中市": "Taichung City",
    "彰化縣": "Changhua County",
    "南投縣": "Nantou County",
    "雲林縣": "Yunlin County",
    "嘉義市": "Chiayi City",
    "嘉義縣": "Chiayi County",
    "臺南市": "Tainan City",
    "台南市": "Tainan City",
    "高雄市": "Kaohsiung City",
    "屏東縣": "Pingtung County",
    "宜蘭縣": "Yilan County",
    "花蓮縣": "Hualien County",
    "臺東縣": "Taitung County",
    "台東縣": "Taitung County",
    "澎湖縣": "Penghu County",
    "金門縣": "Kinmen County",
    "連江縣": "Lienchiang County",
}


def extract_info_from_html(html: str) -> list:
    """Extract the var info = [...] array from page JavaScript."""
    soup = BeautifulSoup(html, "html.parser")
    scripts = soup.find_all("script")

    for script in scripts:
        txt = script.string or ""
        if "var info" not in txt or len(txt) < 1000:
            continue

        # Try regex match first
        info_match = re.search(r"var\s+info\s*=\s*(\[.*?\])\s*;", txt, re.DOTALL)
        if info_match:
            try:
                return json.loads(info_match.group(1))
            except json.JSONDecodeError:
                pass

        # Fallback: bracket-depth parser
        idx = txt.find("var info =")
        if idx < 0:
            continue
        start = txt.find("[", idx)
        if start < 0:
            continue

        depth = 0
        in_string = False
        escape_next = False
        string_char = None

        for j, char in enumerate(txt[start:], start):
            if escape_next:
                escape_next = False
                continue
            if char == "\\" and in_string:
                escape_next = True
                continue
            if char in ('"', "'") and not in_string:
                in_string = True
                string_char = char
            elif char == string_char and in_string:
                in_string = False
                string_char = None
            elif not in_string:
                if char == "[":
                    depth += 1
                elif char == "]":
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(txt[start: j + 1])
                        except json.JSONDecodeError:
                            break

    return []


def extract_postal_from_english(addr_en: str) -> str:
    """Extract postal code from English address."""
    if not addr_en:
        return ""

    # Japan 7-digit codes: 100-6323, 810-0001 → strip dash
    jp_match = re.search(r"\b(\d{3})-(\d{4})\b", addr_en)
    if jp_match:
        return jp_match.group(1) + jp_match.group(2)

    # Taiwan new 6-digit codes with dash: 105-46, 202-001 → strip dash
    tw_dash = re.search(r"\b(\d{3})-(\d{2,3})\b", addr_en)
    if tw_dash:
        return tw_dash.group(1) + tw_dash.group(2)

    # Taiwan 6-digit codes: 202001, 105402, etc.
    tw_match = re.search(r"\b(\d{6})\b", addr_en)
    if tw_match:
        return tw_match.group(1)

    # Singapore 6-digit
    sg_match = re.search(r"Singapore\s+(\d{6})", addr_en)
    if sg_match:
        return sg_match.group(1)

    # USA 5-digit ZIP
    us_match = re.search(r"\b([A-Z]{2})\s+(\d{5})\b", addr_en)
    if us_match:
        return us_match.group(2)

    # Australia 4-digit
    aus_match = re.search(r"\b(NSW|VIC|QLD|WA|SA|TAS|ACT|NT)\s+(\d{4})\b", addr_en)
    if aus_match:
        return aus_match.group(2)

    # Malaysia 5-digit
    my_match = re.search(r"\b(\d{5})\s+Kuala Lumpur", addr_en)
    if my_match:
        return my_match.group(1)

    # Generic 4-6 digit code
    codes = re.findall(r"\b(\d{4,6})\b", addr_en)
    if codes:
        return codes[-1]

    return ""


def parse_taiwan_address(address: str) -> dict:
    """
    Parse Taiwan address: 'ZipCode 縣市 區/鎮/鄉 street'
    """
    address = address.strip()
    result = {"postal_code": "", "city": "", "district": "", "street": address}

    # Strip leading zip code (3-6 digits)
    zip_match = re.match(r"^(\d{3,6})\s*", address)
    if zip_match:
        result["postal_code"] = zip_match.group(1)
        address = address[zip_match.end():].strip()

    # Extract city — match known Taiwan city names (2-3 chars + 市/縣) to avoid greedy matching
    # Use non-greedy approach: match shortest prefix ending with 市/縣
    city_match = re.match(r"^([\u4e00-\u9fff]{2,4}(?:市|縣))", address)
    if city_match:
        result["city"] = city_match.group(1)
        address = address[city_match.end():].strip()

    # Extract district (ends with 區, 鎮, 鄉 — not 市 to avoid "市政路" false match)
    district_match = re.match(r"^([\u4e00-\u9fff]+(?:區|鎮|鄉))", address)
    if district_match:
        result["district"] = district_match.group(1)
        result["street"] = address[district_match.end():].strip()
    else:
        result["street"] = address

    return result


def is_english_text(text: str) -> bool:
    """Return True if text is predominantly ASCII/Latin (not CJK)."""
    if not text:
        return False
    cjk_count = sum(1 for c in text if "\u4e00" <= c <= "\u9fff" or "\u3400" <= c <= "\u4dbf")
    return cjk_count < len(text) * 0.1


def get_address_pair(record: dict) -> tuple[str, str]:
    """
    Return (addr_en, addr_zh) for a record.
    Handles the inconsistency where EDeptAddress sometimes holds the English address.
    """
    raw_en = (record.get("EDeptAddressEnglish", "") or "").strip()
    raw_zh = (record.get("EDeptAddress", "") or "").strip()

    if raw_en and is_english_text(raw_en):
        return raw_en, raw_zh
    elif not raw_en and raw_zh and is_english_text(raw_zh):
        # EDeptAddress holds the English address
        return raw_zh, ""
    else:
        return raw_en, raw_zh


def determine_country(record: dict, is_overseas: bool) -> str:
    """Determine country from address."""
    if not is_overseas:
        return "Taiwan"

    addr_en, addr_zh = get_address_pair(record)

    # Check the last few words of the address for country name
    addr_stripped = addr_en.strip().rstrip(".").strip()

    end_country_map = [
        ("Hong Kong", "Hong Kong"),
        ("China", "China"),
        ("USA", "United States of America (the)"),
        ("U.S.A.", "United States of America (the)"),
        ("Japan", "Japan"),
        ("Australia", "Australia"),
        ("Singapore", "Singapore"),
        ("Vietnam", "Viet Nam"),
        ("Viet Nam", "Viet Nam"),
        ("Myanmar", "Myanmar"),
        ("Thailand", "Thailand"),
        ("Malaysia", "Malaysia"),
        ("Cambodia", "Cambodia"),
    ]

    # Check trailing words (last 15 chars covers most country names)
    addr_tail = addr_stripped[-20:] if len(addr_stripped) > 20 else addr_stripped
    for keyword, country in end_country_map:
        if addr_tail.endswith(keyword) or addr_stripped.endswith(keyword):
            return country

    # Full text search (ordered by specificity)
    priority_order = [
        ("Shenzhen", "China"),
        ("Guangzhou", "China"),
        ("Dongguan", "China"),
        ("Shanghai", "China"),
        ("Beijing", "China"),
        ("Changan Town, Dongguan", "China"),
        ("Hong Kong", "Hong Kong"),
        ("C.A.", "United States of America (the)"),
        ("TX ", "United States of America (the)"),
        ("NSW", "Australia"),
        ("QLD", "Australia"),
        ("VIC", "Australia"),
        ("Phnom Penh", "Cambodia"),
        ("Hanoi", "Viet Nam"),
        ("Ho Chi Minh", "Viet Nam"),
        ("Dong Nai", "Viet Nam"),
        ("Yangon", "Myanmar"),
        ("Bangkok", "Thailand"),
        ("Kuala Lumpur", "Malaysia"),
    ]

    for keyword, country in priority_order:
        if keyword in addr_en:
            return country

    # Full text keyword search
    full_text_map = [
        ("Japan", "Japan"),
        ("Singapore", "Singapore"),
        ("Australia", "Australia"),
    ]
    for keyword, country in full_text_map:
        if keyword in addr_en:
            return country

    for kw, country in COUNTRY_MAP.items():
        if kw in addr_zh:
            return country

    return "International"


def parse_overseas_city_state(addr_en: str, country: str) -> tuple:
    """Parse city and state from international English address."""
    if not addr_en:
        return "", ""

    if country == "United States of America (the)":
        # City of Industry, C.A. 91748 USA
        m = re.search(r"City of ([A-Za-z\s]+),\s*[A-Z\.]+\s+\d+", addr_en)
        if m:
            return f"City of {m.group(1).strip()}", "CA"
        # Dallas, TX 75201
        m = re.search(r"([A-Za-z\s]+),\s*([A-Z]{2})\s+(\d{5})", addr_en)
        if m:
            return m.group(1).strip(), m.group(2)

    elif country == "Australia":
        # Sydney, NSW 2000 or Brisbane, QLD 4000
        for city in ["Sydney", "Brisbane", "Melbourne", "Perth"]:
            if city in addr_en:
                state_m = re.search(r"(NSW|VIC|QLD|WA|SA|TAS|ACT|NT)\s+\d{4}", addr_en)
                return city, state_m.group(1) if state_m else ""

    elif country == "Japan":
        # Chiyoda-ku, Tokyo 100-6323
        m = re.search(r"([A-Za-z\-]+ku),\s*([A-Za-z]+)\s+\d{3}-\d{4}", addr_en)
        if m:
            return m.group(2), m.group(1)
        # Fukuoka, 810-0001
        for city in ["Tokyo", "Fukuoka", "Kumamoto", "Osaka"]:
            if city in addr_en:
                return city, ""

    elif country == "Singapore":
        return "Singapore", ""

    elif country == "Hong Kong":
        # Tsimshatsui, Kowloon, Hong Kong
        m = re.search(r"([A-Za-z\s]+),\s*(Kowloon|Hong Kong Island|New Territories),\s*Hong Kong", addr_en)
        if m:
            return m.group(2).strip(), m.group(1).strip()
        return "Hong Kong", ""

    elif country == "China":
        for city in ["Shenzhen", "Guangzhou", "Dongguan", "Shanghai", "Beijing"]:
            if city in addr_en:
                state = "Guangdong Province" if city in ["Shenzhen", "Guangzhou", "Dongguan"] else ""
                return city, state

    elif country == "Viet Nam":
        for city in ["Ho Chi Minh City", "Hanoi", "Dong Nai"]:
            if city in addr_en:
                return city, ""

    elif country == "Myanmar":
        return "Yangon", "Yangon Region"

    elif country == "Thailand":
        return "Bangkok", "Bangkok"

    elif country == "Malaysia":
        return "Kuala Lumpur", "Kuala Lumpur"

    elif country == "Cambodia":
        return "Phnom Penh", "Phnom Penh"

    # Generic fallback
    parts = [p.strip() for p in addr_en.split(",")]
    for p in reversed(parts):
        p_clean = re.sub(r"\s+", " ", p).strip()
        if (re.match(r"^[A-Za-z][A-Za-z\s\-]+$", p_clean)
                and len(p_clean) > 2
                and country.split("(")[0].strip() not in p_clean):
            return p_clean, ""

    return "", ""


def build_record(item: dict, is_overseas: bool, source_url: str) -> dict:
    """Convert a raw info item to the standard COLUMNS schema."""
    country = determine_country(item, is_overseas)
    cat_id = str(item.get("LocationCatID", "1"))
    activity = ACTIVITY_MAP.get(cat_id, "Banking")

    if is_overseas:
        name = (item.get("EDeptEnglish", "") or item.get("EDept", "")).strip()
        addr_en, addr_zh = get_address_pair(item)

        # Use English address if available, else Chinese
        addr = addr_en if addr_en else addr_zh
        postal = extract_postal_from_english(addr_en) or item.get("ZipCode", "")

        city, state = parse_overseas_city_state(addr_en, country)

    else:
        # Taiwan domestic
        name = (item.get("EDeptEnglish", "") or item.get("EDept", "")).strip()
        addr_zh = (item.get("EDeptAddress", "") or "").strip()
        addr_en = (item.get("EDeptAddressEnglish", "") or "").strip()

        # Prefer English address
        addr = addr_en if addr_en else addr_zh

        # Parse Taiwan address for Chinese city
        parsed = parse_taiwan_address(addr_zh)
        city_zh = parsed["city"]

        # Convert to English city name
        city = TW_CITY_EN.get(city_zh, city_zh)
        state = city  # In Taiwan, the city IS the top-level admin division
        country = "Taiwan"

        # Extract 6-digit postal from English address, fallback to ZipCode
        postal = extract_postal_from_english(addr_en)
        if not postal:
            postal = item.get("ZipCode", "") or parsed["postal_code"]

    if not name:
        name = item.get("EDept", "").strip()

    # Clean up address
    addr = addr.replace("  ", " ").strip()

    rec = {
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": addr,
        "CITY": city,
        "STATE": state,
        "POSTAL_CODE": str(postal).strip() if postal else "",
        "FACILITY_REGION": country,
        "LATITUDE": item.get("Latitude", "") or "",
        "LONGITUDE": item.get("Longitude", "") or "",
        "FACILITY_CONTACT_NUMBER": (item.get("Tel", "") or "").strip(),
        "RELEVANT_URL": source_url,
        "BUSINESS_ACTIVITY": activity,
    }

    return rec


def custom_validate(b: dict) -> list:
    """Custom validator for E.SUN data — accepts 3-digit Taiwan postal codes."""
    issues = []
    addr = b.get("FACILITY_ADDRESS", "")
    if not addr:
        issues.append("MISSING_ADDRESS")
    elif len(addr) < 10:
        issues.append("SHORT_ADDRESS")

    pin = b.get("POSTAL_CODE", "")
    region = b.get("FACILITY_REGION", "")
    if not pin:
        # Some international locations (HK, VN) don't have postal codes — acceptable
        if region not in ("Hong Kong", "Viet Nam", "Myanmar", "Cambodia"):
            issues.append("MISSING_PIN")
    elif not re.match(r"^\d{3,8}$", str(pin)):
        # Accept 3-digit Taiwan postal codes
        issues.append(f"BAD_PIN({pin})")

    city = b.get("CITY", "")
    if not city:
        issues.append("MISSING_CITY")

    state = b.get("STATE", "")
    if not state:
        # Some international locations don't have states — acceptable
        if region not in ("Hong Kong", "Singapore", "Cambodia", "Myanmar", "Viet Nam", "Thailand", "Malaysia"):
            issues.append("MISSING_STATE")

    lat = b.get("LATITUDE", "")
    lng = b.get("LONGITUDE", "")
    if not lat and not lng:
        issues.append("MISSING_COORDS")

    return issues


async def fetch_page(client: httpx.AsyncClient, url: str) -> str:
    log(f"Fetching: {url}")
    r = await client.get(url)
    log(f"  Status: {r.status_code}, Size: {len(r.content)} bytes")
    return r.text


async def main():
    log("=" * 70)
    log(f"{ISSUER} — EXTRACTOR")
    log("=" * 70)

    all_records = []
    domestic_items = []
    overseas_items = []

    async with httpx.AsyncClient(
        headers=HEADERS,
        follow_redirects=True,
        verify=False,
        timeout=30,
    ) as client:

        log("\n--- Phase 1: Domestic Branches ---")
        html = await fetch_page(client, LOCATION_URLS["domestic"])
        domestic_items = extract_info_from_html(html)
        log(f"Extracted {len(domestic_items)} domestic items")

        for item in domestic_items:
            rec = build_record(item, is_overseas=False, source_url=LOCATION_URLS["domestic"])
            all_records.append(rec)

        log("\n--- Phase 2: Overseas Branches & Representative Offices ---")
        html = await fetch_page(client, LOCATION_URLS["overseas"])
        overseas_items = extract_info_from_html(html)
        log(f"Extracted {len(overseas_items)} overseas items")

        for item in overseas_items:
            rec = build_record(item, is_overseas=True, source_url=LOCATION_URLS["overseas"])
            all_records.append(rec)

    log(f"\n=== TOTAL RECORDS: {len(all_records)} ===")
    log(f"  Domestic: {len(domestic_items)}")
    log(f"  Overseas: {len(overseas_items)}")

    # Quality report with custom validator
    quality_report(all_records, validate_fn=custom_validate)
    print_sample(all_records, n=5)

    Path(OUT).mkdir(exist_ok=True)
    jp = save_json(all_records, OUT, ISSUER, BASE_URL)
    export_xlsx(jp)

    archive_scripts(ISSUER_DIR, [Path(__file__)])

    log(f"\nDone! {len(all_records)} total facilities extracted.")


if __name__ == "__main__":
    asyncio.run(main())
