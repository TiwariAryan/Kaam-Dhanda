# BAJAJ FINANCE LIMITED — Extraction Approach Notes
**Date:** 2026-03-23  
**Issuer:** BAJAJ FINANCE LIMITED  
**Analyst:** Auto-extracted via Interactive Asset Scraper  

---

## Source URLs Provided

| URL | Status | Outcome |
|-----|--------|---------|
| https://www.bajajfinserv.in/branch-locator | Browser-required | MapMyIndia SPA — see notes |
| https://www.bajajhousingfinance.in/branch-locator | ✅ EXTRACTED | Static JSON file — 94 branches |
| https://www.bajajfinserv.in/finance-digital-annual-report-fy25/…/annual-report-fy2025.pdf | N/A | PDF — aggregate data only, no branch addresses |
| https://www.bajajfinserv.in/finance-digital-annual-report-fy25/index.html | N/A | Annual report page, no branch data |
| https://www.bajajfinserv.in/all-about-our-service-branches | Browser-required | AEM SPA — same API as branch-locator |
| https://www.bajajgeneralinsurance.com/branch-locator.html | Browser-required | AEM authenticated endpoints |
| https://branch.bajajallianzlife.com/ | ✅ EXTRACTED | Sitemap crawl → 595 branches |
| https://www.bajajfinservmarkets.in/ | ❌ No branches | Online marketplace, no physical locations |
| https://www.bajajbroking.in/ | ❌ No branches | Online stockbroker, no physical locations |
| https://www.bajajfinservhealth.in/ | ❌ No branches | Online health platform, no physical locations |

---

## Extraction Results

| Source | Branches | Lat/Lng | Quality |
|--------|----------|---------|---------|
| Bajaj Housing Finance (BHFL) | 94 | ✅ Yes | 98.9% clean |
| Bajaj Allianz Life Insurance | 595 | ❌ No | 100% address/pin complete |
| **TOTAL** | **689** | Partial | — |

**Output files:** `bajaj_finance_output/` in project workspace  
**Canonical extractor:** `issuers/bajaj_finance/extract.py`

---

## Source 1: Bajaj Housing Finance (BHFL)

### How it works
Static JSON file embedded in Liferay CMS:
```
GET https://www.bajajhousingfinance.in/documents/37350/7953389/bhfl-map-locations.json
```
No auth required. Returns array of 94 branch objects.

### Data fields available
- `position.lat`, `position.lng` — GPS coordinates ✅
- `branch_name` — Branch name (e.g., "Ahmedabad - Ambavadi")
- `city`, `state`, `postal` — Location details
- `primary_phone`, `additional_phones`
- `detailed_address` — Clean address string
- `formatted_address` — Google Maps formatted (has business name prefix)
- `servicename` — Branch type (e.g., "Service Branch", "Data Centre Branch")
- `place_id` — Google Maps Place ID (→ use for RELEVANT_URL)

### Additional JSON
```
GET https://www.bajajhousingfinance.in/documents/37350/7953389/bhfl-map-options.json
```
Contains city → lat/lng center + zoom for the map (not branch data).

---

## Source 2: Bajaj Allianz Life Insurance

### How it works
1. Fetch main sitemap: `https://branch.bajajallianzlife.com/sitemap.xml`
   - Contains 450 city-level `.xml.gz` URLs
   - Format: `https://branch.bajajlifeinsurance.com/files/enterprise/sitemap/google/119541/{state_slug}/{city_slug}.xml.gz`

2. Fetch each `.xml.gz`, decompress (gzip), extract `/Home` URLs
   - Each branch has 4 pages: `/Home`, `/Map`, `/Contact-Us`, `/Photos-Videos`
   - 450 city files × avg ~1.3 branches/city = ~595 unique branches

3. Fetch each `{branch-slug}/Home` page
   - Parse `application/ld+json` script with `@type: "LocalBusiness"`
   - Extract: name, streetAddress, addressLocality, addressRegion, postalCode, telephone

4. State derived from sitemap URL path (`{state_slug}` → proper state name via lookup table)

### LD+JSON structure (per branch)
```json
{
  "@type": "LocalBusiness",
  "name": "Bajaj Life Insurance",
  "url": "https://branch.bajajlifeinsurance.com/{slug}/Home",
  "address": [{
    "@type": "PostalAddress",
    "streetAddress": "Shop No 16, 6th Floor, DCM Building",
    "addressLocality": "Barakhamba Road",  ← neighborhood
    "addressRegion": "New Delhi",          ← city in Indian context
    "postalCode": "110001",
    "addressCountry": "India",
    "telephone": ["+912067121212", "+912261241800"]
  }]
}
```
**Note:** No lat/lng coordinates in LD+JSON. Do NOT geocode.

### Caveats
- Phone: all Allianz branches return the same central number (+912067121212) — no individual branch phones
- `addressLocality` is the locality/neighborhood, `addressRegion` is city/district
- State must be derived from sitemap URL path

---

## Source 3: Bajaj Finserv (branch-locator) — Browser-Required

### What we found
- Uses **MapMyIndia** SDK for map rendering
- Token endpoint: `POST https://www.bajajfinserv.in/api/v1/storelocator/token`
  - Returns MapMyIndia access_token (expires in N minutes)
  - Used to load MapMyIndia `map_sdk_plugins` JS bundle
  - NOT directly usable for branch data without session cookies
- Store locator is React/Redux webpack bundle (chunk 65841 = StoreLocator)
- AEM-based site (Adobe Experience Manager)

### API pattern
```javascript
// From clientlib-site.min.js:
const token = (yield P6("POST", "/api/v1/storelocator/token", "")).data.access_token;
// Then loads MapMyIndia SDK, then searches for nearby "Bajaj Finance" points
```

### Why it's browser-required
The `/api/v1/storelocator/token` endpoint returns 404 without a valid session cookie.
Requires full browser session (Playwright) to:
1. Load the page (sets session cookies)
2. POST to token endpoint (with session)
3. Use token to query MapMyIndia Place Discovery API

### Playwright approach (future work)
```python
# 1. Navigate to /branch-locator (sets session)
# 2. POST /api/v1/storelocator/token → get access_token
# 3. Query MapMyIndia TextSearch: 
#    GET https://atlas.mapmyindia.com/api/places/search/json?query=Bajaj+Finance+branch&access_token={token}
# 4. Paginate through results
```

---

## Source 4: Bajaj General Insurance (BAGIC) — Browser-Required

### What we found
- AEM-based site with custom Sling servlets
- `appName = "bagic"`, `contentRoot = "/content/bagic"`, `apiRoot = "/content/bagic/api"`
- `apiExtension = ".json"`
- API URL format: `{apiRoot}.{selector}{apiExtension}` = `/content/bagic/api.{SELECTOR}.json`

### API Constants
- `CUST_BRANCH_NAME = "CUST_BRANCH_NAME"` (maps to "get-branch-name")
- Request body: `{"branchCode": ""}` (GET all branches, or filter by code)
- `SEARCH_NETWORK_STATE = "SEARCH_NETWORK_STATE"` (state list)
- `GET_CITY_LIST = "GET_CITY_LIST"` (city list)

### Why it's browser-required
All AEM Sling servlet endpoints return:
- GET: Empty responses (1 byte, `text/html;charset=iso-8859-1`)
- POST: `409 Conflict` (endpoint exists but requires auth)
The servlet validates a session token/CSRF token from the AEM login.

### Playwright approach (future work)
```python
# 1. Navigate to /branch-locator.html (loads session + CSRF)
# 2. Intercept XHR to /content/bagic/api.CUST_BRANCH_NAME.json
# 3. Replay with session cookies to get branch list
# OR:
# 4. Click each state in dropdown, capture response
```

---

## Python Extractor

**Location:** `issuers/bajaj_finance/extract.py`

```bash
# Full extraction (BHFL + Allianz Life)
python -m issuers.bajaj_finance.extract

# BHFL only (fast, 94 branches with coordinates)
python -m issuers.bajaj_finance.extract --bhfl-only

# Allianz Life only
python -m issuers.bajaj_finance.extract --allianz-only

# Sample 50 Allianz Life branches (for testing)
python -m issuers.bajaj_finance.extract --allianz-only --sample 50
```

---

## Column Mapping

| Standard Column | BHFL Source | Allianz Life Source |
|----------------|-------------|---------------------|
| FACILITY_NAME | `branch_name` | LD+JSON `name` |
| FACILITY_ADDRESS | `detailed_address` | `streetAddress, addressLocality, addressRegion, postalCode` |
| CITY | `city` | sitemap city_slug (title-cased) |
| STATE | `state` | sitemap state_slug → STATE_NAME_MAP lookup |
| POSTAL_CODE | `postal` | LD+JSON `postalCode` |
| FACILITY_REGION | "India" | "India" |
| LATITUDE | `position.lat` | — (not available) |
| LONGITUDE | `position.lng` | — (not available) |
| FACILITY_CONTACT_NUMBER | `primary_phone` | LD+JSON `telephone[0]` |
| RELEVANT_URL | Google Maps Place ID URL | branch /Home URL |
| BUSINESS_ACTIVITY | "Housing Finance — {type}" | "Life Insurance" |

---

## Known Issues & Limitations

1. **Allianz Life**: All branches return the same phone (+912067121212) — no individual branch phones
2. **Allianz Life**: No lat/lng coordinates available on source
3. **BHFL**: 1 record with BAD_PIN (malformed postal code in source data)
4. **BFS & BAGIC**: Not extracted — require Playwright browser session
5. **Bajaj Finserv (main branch locator)**: Likely has the most Bajaj Finance NBFC branches but API requires browser session with session cookies

---

## Future Improvements

1. **Playwright extractor for BFS**: Automate browser session → token → MapMyIndia search
2. **Playwright extractor for BAGIC**: Capture XHR after dropdown selection
3. **BHFL refresh**: Static JSON updates when Liferay page is republished — monitor periodically
4. **Allianz Life refresh**: Sitemap auto-updates — rerun extractor periodically
