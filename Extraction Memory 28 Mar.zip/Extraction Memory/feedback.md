

---

## Feedback â€” BAJAJ FINANCE LIMITED Extraction (Mar 23, 2026)

### Skill Used: Interactive Asset Scraper (Playwright-based)

#### What Worked Well
1. **Resume/Progress Saving**: The extraction script saved progress every 20 cities and after each state, enabling safe resumption after interruptions. Critical for long-running 960-city iterations.
2. **In-browser API calls via page.evaluate()**: Bypassed CORS restrictions by executing etch() inside the Playwright browser context, allowing calls to SingleInterface PHP APIs.
3. **URL-based filtering** (?state_name=X&city_name=Y): The most reliable method to get city-specific outlets. Much simpler than trying to interact with hidden form dropdowns.
4. **Short timeout for empty cities (4s)**: Reduced wasted time from 8s to 4s for cities with no branches, significantly speeding up the overall extraction.
5. **Anti-bot bypass with system browser**: Using channel='msedge' in Playwright with anti-fingerprinting (
avigator.webdriver = undefined) successfully bypassed Akamai WAF on bajajfinserv.in.
6. **Static HTML hidden content**: Always check hidden/invisible DOM elements (display:none, isibility:hidden) â€” BAGIC stored all branch data in a hidden div#findgeneralinsurancebranch.

#### What Did Not Work / Time Wasters
1. **MapMyIndia/MMI API**: Despite capturing the API key from network intercepts, direct usage was blocked by SSL errors, 412 Precondition Failed, CORS, and JSONP-only responses. The nearme.bajajfinserv.in alternative was much better.
2. **AEM API on BAGIC**: The granite/core/content/login AEM API returned 0/empty results despite correct endpoint and headers. The data was static HTML, not from the API.
3. **Clicking hidden <select> dropdowns**: Using page.click() or select_option() on visually hidden elements caused timeouts. Use page.evaluate() with JavaScript to set values and dispatch events instead.
4. **Incorrect button identification**: Early attempts consistently clicked the wrong button (a text span instead of the actual search submit button), causing search filter to not apply. URL-based approach eliminated this problem.

#### Skill Improvement Suggestions
1. **URL parameter discovery**: Before attempting form interaction, try URL patterns like ?state=X&city=Y&search=Z â€” many store locators accept GET params and this is orders of magnitude faster.
2. **Detect SingleInterface platform early**: Look for 
earme. subdomain or .php endpoints with master_outlet_id and getCitiesByStateAlias... patterns. If detected, use the SI-specific workflow.
3. **Always look for hidden DOM content**: Before using API-based approaches, run document.querySelectorAll('[style*="display:none"], [hidden]') to reveal hidden data containers.
4. **Progress file + resumability**: Long multi-city extractions should always save progress to a JSON file (done-states/cities) so they can be interrupted and resumed. This should be a standard pattern in the skill.
5. **Parallel extraction**: Consider running 2-3 Playwright browser tabs in parallel to speed up city iteration. Would reduce 2-hour run to 30-40 minutes.
6. **Check for infinite scroll vs pagination**: The skill should detect whether the page uses infinite scroll, a "Load More" button, or pagination, and handle each accordingly.
7. **Timeout tuning**: Default wait_for_selector timeout of 8s is too long for pages with no data. 3-4s is sufficient and reduces empty-city overhead by 50%.

---

## Feedback — KOTAK MAHINDRA BANK LIMITED Extraction (Mar 24, 2026)

### Skill Used: Interactive Asset Scraper (httpx-based non-interactive)

#### What Worked Well
1. **JavaScript analysis for API discovery**: Reading the `maps/clientlib.min.js` file revealed the complete API URL construction logic including the base64 encoding of parameters. This is much faster than network interception.
2. **Playwright for URL format verification**: Used Playwright's `page.evaluate()` to run the website's own jQuery code to verify the exact URL format. This bypassed CORS and confirmed the base64 encoding format with `=` padding.
3. **State/City API discovery**: Found `/kotak/getStateCityList` which returns ALL states and cities in a single JSON response. This eliminates any need to scrape the website UI for city lists.
4. **AEM Sling selector pattern**: The `.map.reachus.` pattern is an AEM-specific approach where parameters are encoded in URL selectors. Once discovered, it's extremely reliable and fast.
5. **Progress saving every 20 combos**: The extraction ran 1087 state+city combinations and saved progress every 20. This enabled safe resumption from where a previous interrupted run left off.
6. **httpx async approach**: Using httpx AsyncClient with 0.3s delays between requests was fast enough (~6 minutes for 1087 combinations) without triggering rate limiting.
7. **Deduplication by identityValue**: The API returns the same branch for multiple nearby cities. Deduplicating by the `identityValue` field eliminated all duplicates effectively.

#### What Did Not Work / Time Wasters
1. **Initial 400 errors on httpx**: Got 400 Bad Request when constructing the URL manually. Root cause was wrong case (mixed-case city/state names) and empty radius string instead of "0.003". Playwright verification was needed to confirm the exact format.
2. **Sitemap search**: Kotak has no accessible sitemap.xml. Dead end.
3. **AEM model.json API**: The `/content/kotakcl/en/reach-us.model.json` endpoint exists but only returns page structure metadata, not branch data.
4. **RBI/Razorpay IFSC database approach**: While the Razorpay IFSC API works per-IFSC-code, there was no public batch list of all KKBK codes. The in-site API approach was much better.
5. **Playwright UI interaction**: The state dropdown uses a custom JS-rendered component. Standard `select_option()` failed. The URL/API approach eliminated all UI interaction requirements.

#### Skill Improvement Suggestions
1. **AEM Site detection**: When a page loads `etc.clientlibs/.../maps/clientlib.min.js` or similar AEM component paths, automatically check for:
   - A state/city list API at `/kotak/getStateCityList` or similar
   - A hidden input with `id="mapsComponent"` containing the AEM content path
   - The `.map.reachus.` selector pattern in the JS
2. **JS file analysis automation**: Add a step to automatically fetch all JS files loaded on the page and search for AJAX URL construction patterns (look for `$.ajax`, `fetch(`, URL templates with base64 encoding).
3. **Playwright URL verification step**: For any discovered API URL with special encoding, use Playwright's evaluate to call the same jQuery/fetch from within the page to verify the format before attempting httpx bulk extraction.
4. **Branch type filtering guidance**: Prompt user about different branch types (ATM vs Branch vs eLobby) when multiple types are found in the data.
5. **AEM hidden input scanning**: Always scan the target page for hidden `<input>` elements that might contain API paths and configuration. These are gold mines for AEM sites.
6. **Large page size detection**: A 774KB HTML page with no visible branch links is suspicious. Flag this pattern and pivot to JS analysis immediately.

---

## Feedback — E.SUN FINANCIAL HOLDING COMPANY, LTD. Extraction (Mar 24, 2026)

### Skill Used: Interactive Asset Scraper (httpx-based non-interactive)

#### What Worked Well
1. **Static HTML with embedded JSON**: The page embeds ALL branch data as `var info = [...]` in a large script tag (~100KB). This is a common pattern for Google Maps-based branch locators in Asia. Fetching with plain httpx (no JS rendering needed) gives the full dataset.
2. **Bracket-depth parser for JSON extraction**: When the simple regex `var info = [...];` fails (e.g., semicolon not present), a character-by-character bracket depth parser reliably finds the end of the array. This should be a standard tool in the extraction toolkit.
3. **Navigation link inspection**: User-provided URLs were all 404 (outdated). Playwright navigation link inspection quickly revealed the correct URLs (`/zh-tw/about/locations/` instead of `/zh-tw/locations/`).
4. **get_address_pair() pattern**: For sites where `EDeptAddressEnglish` and `EDeptAddress` field names are misleading (English content in the "Chinese" field), detecting CJK character density (< 10%) to identify English text is a reliable approach.
5. **100% coordinate coverage**: All 204 records had valid lat/lng coordinates directly from the page data — no geocoding needed.

#### What Did Not Work / Time Wasters
1. **User-provided URLs**: All of the provided `/zh-tw/locations/` URLs returned 404. Always verify URLs before building a scraper — inspect navigation links first.
2. **EDeptAddressEnglish field**: For ~40% of overseas branches, this field was EMPTY and the actual English address was in `EDeptAddress`. This caused incorrect country detection. Always check both fields.
3. **Greedy regex for CJK city parsing**: `r"[\u4e00-\u9fff]+(?:市|縣)"` is greedy and over-matches. "台中市西屯區市政路" was parsed as "台中市西屯區市" (7 chars) instead of "台中市" (3 chars). Fix: use `{2,4}` character count limit.
4. **Taiwan 3-digit postal codes**: The common validator expects 4-6 digit codes, but Taiwan uses 3-digit codes. Need country-aware validation or a permissive 3-8 digit range.
5. **UCB Cambodia website**: `www.ucbcambodia.com` was inaccessible (DNS not resolved from this network). The main Phnom Penh office was already in the overseas branch data.

#### Skill Improvement Suggestions
1. **URL verification step**: Before building the scraper, always test all user-provided URLs with httpx and report which ones return 200 vs 404. If 404, automatically inspect navigation links to find the correct paths.
2. **`var info = [...]` pattern detection**: Add this as a standard detection step — after loading a page, search for any `var \w+ = \[` pattern in script tags. This is used by many Asian bank websites for embedded location data.
3. **Bilingual address field handling**: When a record has both Chinese and English address fields, but one is empty, detect language via CJK density before deciding which to use. Normalize the field names.
4. **Country-aware postal code validation**: Taiwan uses 3-digit codes, Japan uses 7-digit (XXX-YYYY), Hong Kong has no postal codes. The validator should accept empty postal codes for certain countries without flagging as an issue.
5. **`endswith` country detection**: When checking if an address ends with a country name, ensure proper whitespace stripping before comparison. Use `.strip()` not `.rstrip(".")` to avoid missing trailing spaces.
6. **Detect reversed address fields**: After fetching the first record, check if `EDeptAddressEnglish` is consistently empty while `EDeptAddress` contains English. Flag this early and switch the field usage pattern.

---

## Feedback â€” CHROMA ATE INC. Extraction (Mar 24, 2026)

### Skill Used: Interactive Asset Scraper (httpx-based non-interactive / static HTML)

#### What Worked Well
1. **Static HTML parsing with BeautifulSoup**: The chromaate.com global pages are large (100-180KB) server-rendered HTML. All facility data is embedded in div.country_card elements â€” no Playwright, no API calls, no JavaScript rendering needed. Plain httpx + BeautifulSoup is sufficient.
2. **Structured card-based HTML**: The div.country_card pattern is clean and consistent across all 125 entries. Each card has predictable fields: p.countyr_name, span.con_name, and ul > li items labeled by prefix ("Tel:", "Fax:", "URL:", "Email:").
3. **CJK stripping approach**: For bilingual company names (e.g., "Chroma ATE Inc. è‡´èŒ‚é›»å­è‚¡ä»½æœ‰é™å…¬å¸"), stripping CJK chars individually (not dropping the whole node) correctly extracts the English part. Added empty-parenthesis cleanup for (æ·±åœ³) â†’ () artifacts.
4. **Country-specific address parsers**: Writing 30+ country-specific regex parsers for postal code and city extraction worked well. The patterns varied significantly across countries (Germany: D-XXXXX, Netherlands: XXXX AA, Czech: postal THEN city, Japan: 7-digit, etc.).
5. **SSL verify=False**: Immediately resolved the SSL certificate chain error without other workarounds.
6. **US spelled-out state fallback**: Added US_STATE_TO_ABBR lookup to handle "Arizona 85225" patterns (not just abbreviated "AZ 85225"). Caught the Arizona Office record correctly.
7. **Multi-country deduplication**: Using (facility_name.lower(), address.lower()) as dedup key correctly identified 4 duplicate entries without over-deduping.

#### What Did Not Work / Time Wasters
1. **is_cjk_heavy() for text filtering**: Initially used is_cjk_heavy() (>20% CJK â†’ skip) to filter text nodes. This dropped "Chroma ATE Inc. è‡´èŒ‚é›»å­è‚¡ä»½æœ‰é™å…¬å¸" entirely (50% CJK). Had to switch to strip_cjk() approach.
2. **Single regex for all countries**: Initially tried to handle postal codes with a generic \b(\d{4,6})\b pattern. Failed for Japanese 7-digit codes, Dutch alphanumeric codes, Brazilian XXXXX-XXX format, and Czech 3+2 space format.
3. **FACILITY_ADDRESS truncation**: Initially truncated the address to the "street only" part (removing city and state). Better to keep the full address string in FACILITY_ADDRESS and extract city/state/postal as separate fields.
4. **City extraction for US "embedded city" addresses**: "734 Forest St. Suite 500 Marlborough, MA 01752" â€” city "Marlborough" is embedded at the end of the street. Needed STREET_SUFFIXES set to stop walking backwards before "Suite".

#### What Could Not Be Fixed
1. **2 records with no address**: Chroma Electronics (Shenzhen) and Chroma Japan (Nagoya) have no address listed on the website. These show MISSING_ADDRESS and MISSING_CITY â€” this is a source data issue.
2. **Japan 7-digit postal codes flagged as BAD_PIN**: The validator only accepts 4-6 digit codes. Japanese codes are 7 digits. This is a validator limitation â€” all 28 Japanese records show this issue. Accept as valid.
3. **Coordinates**: The corporate directory pages do not provide coordinates. No maps embed or API for geodata. 121/121 records show MISSING_COORDS â€” expected per SKILL rules (never geocode).

#### Skill Improvement Suggestions
1. **Detect card-based layouts early**: After initial page load, auto-detect common card selectors: div[class*="card"], div[class*="country"], div[class*="location"], div[class*="branch"], li[class*="office"]. Report count and structure.
2. **CJK stripping utility**: The skill should provide a standard strip_cjk(text) utility function that: (a) removes CJK characters, (b) removes empty parentheses (), (c) normalizes whitespace. This is reusable across multilingual corporate sites.
3. **STREET_SUFFIXES set for city extraction**: Provide a standard set of common street suffixes (St, Street, Rd, Road, Ave, Suite, etc.) for use when extracting embedded city names from combined "street+city" address parts.
4. **Country-aware postal code validation**: The validator should accept different formats per country:
   - Japan: 7 digits
   - Netherlands/UK/Canada: alphanumeric
   - Poland: XX-XXX with hyphen
   - Taiwan: 3-digit (old) or 6-digit (new)
   Flag these as INFO rather than BAD_PIN.
5. **US state name lookup table**: Include US_STATE_TO_ABBR in the standard skill toolkit for handling full state names instead of abbreviations.
6. **"City after postal" detection**: For European addresses (Czech, Italy, Turkey, Greece, others), detect when a postal code is FOLLOWED by a city name (not preceded). Pattern: POSTAL, City rather than City POSTAL.
7. **Mixed language text detection**: After fetching a page, detect if text nodes contain mixed English+CJK text (same node, not <br> separated). If so, use strip_cjk() mode; if separated by <br>, use first-line-only mode.
