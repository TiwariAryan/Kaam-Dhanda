"""
CATL Facility Final CSV Builder
Sources: CATL Contact Page (direct scrape) + Tavily web search + CATL annual report data
Issuer: CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD. | IID000000002841129
"""

import re
import sys
import time

import pandas as pd
import requests
import urllib3

urllib3.disable_warnings()
sys.stdout.reconfigure(encoding='utf-8')

# ── Configuration ────────────────────────────────────────────────────────────
BING_API_KEY = "yGyflKQJyJ3lNV3yKcYP~FSPEyZhJWuaj1EsG7Ajmkg~AkM_12vG3agHCBs6OD3BxSGIJ38YadqKG687egd-7Mvzp4qrkNnMMvbal7v3xIYw"
BING_API_URL = "http://dev.virtualearth.net/REST/v1/Locations"

ISSUER_ID    = "IID000000002841129"
ISSUER_NAME  = "CONTEMPORARY AMPEREX TECHNOLOGY CO., LTD."
RELEVANT_URL = "https://www.catl.com/en/uploads/1/image/public/202603/20260317210914_ny0ie1ycx1.png"
OUTPUT_CSV   = r"C:\Users\tiwaary\OneDrive - MSCI Office 365\ACWI Collection\CATL_Facilities.csv"

# ── Raw facility data compiled from multiple sources ─────────────────────────
# Sources:
#   [C] = CATL Contact Page https://www.catl.com/en/contactus/ (directly scraped)
#   [A] = CATL Annual Report 2024 (PDF from catl.com)
#   [N] = CATL News articles (catl.com/en/news/)
#   [S] = Web search / Tavily results
#   [L] = LinkedIn company page data

RAW_FACILITIES = [
    # ── Headquarters ─────────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Global Headquarters",
        "FACILITY_ADDRESS":       "No. 2, Xingang Road, Zhangwan Town, Jiaocheng District, Ningde, Fujian",
        "CITY":                   "Ningde",
        "STATE":                  "Fujian",
        "POSTAL_CODE":            "352100",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86 593-2583668",
        "ACTIVITY_AT_SOURCE":     "Global headquarters and battery manufacturing",
        "FACILITY_NAME_NATIVE":   "宁德时代新能源科技股份有限公司 全球总部",
        "FACILITY_ADDRESS_NATIVE": "福建省宁德市蕉城区漳湾镇新港路2号，352100",
        "source": "[C]",
    },
    # ── Fuding Plant (Ningde) ─────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Fuding Battery Manufacturing Base",
        "FACILITY_ADDRESS":       "Fuding City, Ningde, Fujian",
        "CITY":                   "Ningde",
        "STATE":                  "Fujian",
        "POSTAL_CODE":            "355200",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Lithium-ion battery cell manufacturing (largest single battery base, 120 GWh planned capacity)",
        "FACILITY_NAME_NATIVE":   "宁德时代福鼎锂电池生产基地",
        "FACILITY_ADDRESS_NATIVE": "福建省宁德市福鼎市",
        "source": "[N][A]",
    },
    # ── Zhaoqing, Guangdong ───────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Guangdong Ruiqing Contemporary Amperex Technology Limited",
        "FACILITY_ADDRESS":       "No. 1, Shidai Road, High-tech Development Zone, Zhaoqing, Guangdong",
        "CITY":                   "Zhaoqing",
        "STATE":                  "Guangdong",
        "POSTAL_CODE":            "526000",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86-(0)758-6626509",
        "ACTIVITY_AT_SOURCE":     "Battery cell and energy storage manufacturing",
        "FACILITY_NAME_NATIVE":   "广东瑞庆时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "广东省肇庆市高新技术开发区时代大道1号，526000",
        "source": "[C]",
    },
    # ── Liyang, Jiangsu ───────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Jiangsu Contemporary Amperex Technology Limited",
        "FACILITY_ADDRESS":       "No. 1000, Chengbei Road, Liyang, Jiangsu",
        "CITY":                   "Liyang",
        "STATE":                  "Jiangsu",
        "POSTAL_CODE":            "213300",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86-(0)519-68260023",
        "ACTIVITY_AT_SOURCE":     "Battery cell and energy storage manufacturing",
        "FACILITY_NAME_NATIVE":   "江苏时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "江苏省溧阳市城北路1000号，213300",
        "source": "[C]",
    },
    # ── Xining, Qinghai ───────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Qinghai Contemporary Amperex Technology Limited",
        "FACILITY_ADDRESS":       "No. 182, Chuangye Road, Nanchuan Industry Park, Xining, Qinghai",
        "CITY":                   "Xining",
        "STATE":                  "Qinghai",
        "POSTAL_CODE":            "810000",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86-(0)971-7461888",
        "ACTIVITY_AT_SOURCE":     "Battery cell and energy storage manufacturing",
        "FACILITY_NAME_NATIVE":   "青海时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "青海省西宁市南川区创业路182号，810000",
        "source": "[C]",
    },
    # ── Lingang, Shanghai ────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Ruiting Contemporary Amperex Technology (Shanghai) Limited",
        "FACILITY_ADDRESS":       "Buildings 3, 4, 5, No. 168, Xinsiping Road, Lin-gang Special Area, China (Shanghai) Pilot Free Trade Zone, Shanghai",
        "CITY":                   "Shanghai",
        "STATE":                  "Shanghai",
        "POSTAL_CODE":            "201306",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86 021-61189968",
        "ACTIVITY_AT_SOURCE":     "Battery cell and energy storage manufacturing",
        "FACILITY_NAME_NATIVE":   "瑞廷时代（上海）新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "中国（上海）自由贸易试验区临港新片区新四平公路168号3幢、4幢、5幢，201306",
        "source": "[C]",
    },
    # ── Yibin, Sichuan ────────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Sichuan Contemporary Amperex Technology Limited",
        "FACILITY_ADDRESS":       "No. 1, Industry Avenue, Lingang Economic Development Zone, Yibin, Sichuan",
        "CITY":                   "Yibin",
        "STATE":                  "Sichuan",
        "POSTAL_CODE":            "644000",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+86-(0)831-8258888",
        "ACTIVITY_AT_SOURCE":     "Battery cell and energy storage manufacturing",
        "FACILITY_NAME_NATIVE":   "四川时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "四川省宜宾市临港经开区产业大道1号，644000",
        "source": "[C]",
    },
    # ── Xiamen, Fujian ────────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Xiamen Battery Manufacturing Base",
        "FACILITY_ADDRESS":       "Haicang District, Xiamen, Fujian",
        "CITY":                   "Xiamen",
        "STATE":                  "Fujian",
        "POSTAL_CODE":            "361026",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Lithium-ion battery manufacturing (7 billion RMB investment, EV and energy storage batteries)",
        "FACILITY_NAME_NATIVE":   "宁德时代厦门锂离子电池生产基地",
        "FACILITY_ADDRESS_NATIVE": "福建省厦门市海沧区",
        "source": "[N][A]",
    },
    # ── Yichun, Jiangxi ──────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Yichun Battery Manufacturing Base",
        "FACILITY_ADDRESS":       "Yichun Economic and Technological Development Zone, Yichun, Jiangxi",
        "CITY":                   "Yichun",
        "STATE":                  "Jiangxi",
        "POSTAL_CODE":            "336000",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Lithium-ion battery manufacturing and lithium resource extraction (50 GWh phase 1 capacity)",
        "FACILITY_NAME_NATIVE":   "宁德时代宜春锂电池生产基地",
        "FACILITY_ADDRESS_NATIVE": "江西省宜春市经济技术开发区",
        "source": "[N][A]",
    },
    # ── Guiyang / Gui'an, Guizhou ─────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Guiyang Battery Production Base",
        "FACILITY_ADDRESS":       "Gui'an New Area, Guiyang, Guizhou",
        "CITY":                   "Guiyang",
        "STATE":                  "Guizhou",
        "POSTAL_CODE":            "550025",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Electric vehicle and energy storage battery manufacturing (60 GWh total capacity)",
        "FACILITY_NAME_NATIVE":   "宁德时代贵阳（贵安新区）电池生产基地",
        "FACILITY_ADDRESS_NATIVE": "贵州省贵阳市贵安新区",
        "source": "[N][A]",
    },
    # ── Jining, Shandong ──────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology Shandong Co., Ltd.",
        "FACILITY_ADDRESS":       "Yanzhou District, Jining, Shandong",
        "CITY":                   "Jining",
        "STATE":                  "Shandong",
        "POSTAL_CODE":            "272100",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Energy storage and EV battery manufacturing (first CATL production base in Northern China)",
        "FACILITY_NAME_NATIVE":   "时代新能源（山东）有限公司",
        "FACILITY_ADDRESS_NATIVE": "山东省济宁市兖州区",
        "source": "[N][A]",
    },
    # ── Luoyang, Henan ────────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Zhongzhou Contemporary Amperex Technology Limited",
        "FACILITY_ADDRESS":       "Luoyang High-tech Development Zone, Luoyang, Henan",
        "CITY":                   "Luoyang",
        "STATE":                  "Henan",
        "POSTAL_CODE":            "471000",
        "FACILITY_REGION":        "China",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Battery cell manufacturing (groundbreaking September 2022)",
        "FACILITY_NAME_NATIVE":   "中原时代（洛阳）新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "河南省洛阳市高新技术产业开发区",
        "source": "[N][A]",
    },
    # ── Arnstadt, Germany (Thuringia) ─────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology Thuringia GmbH",
        "FACILITY_ADDRESS":       "Robert-Bosch-Strasse 1, 99310 Arnstadt, Thuringia",
        "CITY":                   "Arnstadt",
        "STATE":                  "Thuringia",
        "POSTAL_CODE":            "99310",
        "FACILITY_REGION":        "Germany",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+49-(0)3628-6636-0",
        "ACTIVITY_AT_SOURCE":     "Battery cell manufacturing (CATL's first overseas manufacturing base)",
        "FACILITY_NAME_NATIVE":   "德国时代新能源科技（图林根）有限公司",
        "FACILITY_ADDRESS_NATIVE": "Robert-Bosch-Straße 1, 99310 Arnstadt, Thüringen",
        "source": "[C]",
    },
    # ── Munich, Germany ───────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology GmbH",
        "FACILITY_ADDRESS":       "Bayerstrasse 83-85a, 80335 Munich, Bavaria",
        "CITY":                   "Munich",
        "STATE":                  "Bavaria",
        "POSTAL_CODE":            "80335",
        "FACILITY_REGION":        "Germany",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+49-89-954285-408",
        "ACTIVITY_AT_SOURCE":     "European regional office and R&D",
        "FACILITY_NAME_NATIVE":   "德国时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "Bayerstr 83-85a, 80335 München",
        "source": "[C]",
    },
    # ── Debrecen, Hungary ─────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL Hungary Battery Factory",
        "FACILITY_ADDRESS":       "Southern Industrial Park, Debrecen, Hajdu-Bihar County",
        "CITY":                   "Debrecen",
        "STATE":                  "Hajdu-Bihar",
        "POSTAL_CODE":            "4031",
        "FACILITY_REGION":        "Hungary",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "Battery cell manufacturing (second overseas manufacturing base, commenced production 2025)",
        "FACILITY_NAME_NATIVE":   "CATL Magyarország Akkumulátorgyár",
        "FACILITY_ADDRESS_NATIVE": "Déli Ipari Park, Debrecen, Hajdu-Bihar megye",
        "source": "[S]",
    },
    # ── Paris, France ────────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology France",
        "FACILITY_ADDRESS":       "66 Champs Elysees, Paris",
        "CITY":                   "Paris",
        "STATE":                  "Ile-de-France",
        "POSTAL_CODE":            "75020",
        "FACILITY_REGION":        "France",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+33-01-84781461",
        "ACTIVITY_AT_SOURCE":     "European sales and customer liaison office",
        "FACILITY_NAME_NATIVE":   "法国时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "66 Champs Elysées, Paris, France, 75020",
        "source": "[C]",
    },
    # ── Yokohama, Japan ───────────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology Japan K.K.",
        "FACILITY_ADDRESS":       "11F Landmark Tower, 2-2-1 Minatomirai, Nishi-ku, Yokohama, Kanagawa",
        "CITY":                   "Yokohama",
        "STATE":                  "Kanagawa",
        "POSTAL_CODE":            "220-8111",
        "FACILITY_REGION":        "Japan",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+81-(0)45-264-9138",
        "ACTIVITY_AT_SOURCE":     "Japan regional office and customer relations",
        "FACILITY_NAME_NATIVE":   "時代新能源日本合同会社",
        "FACILITY_ADDRESS_NATIVE": "〒220-8111 神奈川県横浜市西区みなとみらい2-2-1 ランドマークタワー11F",
        "source": "[C]",
    },
    # ── Wilmington, Delaware, USA ─────────────────────────────────────────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology (USA), Inc.",
        "FACILITY_ADDRESS":       "1209 Orange Street, Wilmington, New Castle County, Delaware",
        "CITY":                   "Wilmington",
        "STATE":                  "Delaware",
        "POSTAL_CODE":            "19801",
        "FACILITY_REGION":        "United States",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+01-248-2896200",
        "ACTIVITY_AT_SOURCE":     "US registered corporate office",
        "FACILITY_NAME_NATIVE":   "美国时代新能源科技有限公司",
        "FACILITY_ADDRESS_NATIVE": "1209 Orange Street, Wilmington, Delaware 19801, USA",
        "source": "[C]",
    },
    # ── Auburn Hills, Michigan, USA ───────────────────────────────────────────
    {
        "FACILITY_NAME":          "CATL USA - Auburn Hills Engineering and Sales Office",
        "FACILITY_ADDRESS":       "2455 Featherstone Road, Auburn Hills, Michigan",
        "CITY":                   "Auburn Hills",
        "STATE":                  "Michigan",
        "POSTAL_CODE":            "48326",
        "FACILITY_REGION":        "United States",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+01-248-2896200",
        "ACTIVITY_AT_SOURCE":     "North American sales, R&D, and engineering office",
        "FACILITY_NAME_NATIVE":   "CATL USA Auburn Hills Engineering Office",
        "FACILITY_ADDRESS_NATIVE": "2455 Featherstone Rd, Auburn Hills, MI 48326, USA",
        "source": "[L][S]",
    },
    # ── Riyadh, Saudi Arabia ──────────────────────────────────────────────────
    {
        "FACILITY_NAME":          "NING SERVICE Experience Center Riyadh",
        "FACILITY_ADDRESS":       "Riyadh, Riyadh Province, Saudi Arabia",
        "CITY":                   "Riyadh",
        "STATE":                  "Riyadh Province",
        "POSTAL_CODE":            "",
        "FACILITY_REGION":        "Saudi Arabia",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "",
        "ACTIVITY_AT_SOURCE":     "New energy aftermarket service center - battery diagnostics, repair, maintenance, recycling and training (7,000 sqm, opened January 2026)",
        "FACILITY_NAME_NATIVE":   "NING SERVICE体验中心（利雅得）",
        "FACILITY_ADDRESS_NATIVE": "利雅得，沙特阿拉伯",
        "source": "[N][S]",
    },
    # ── Nanterre / Paris, France (additional office from LinkedIn) ───────────
    {
        "FACILITY_NAME":          "Contemporary Amperex Technology Europe - Nanterre Office",
        "FACILITY_ADDRESS":       "1 Boulevard des Bouvets, Nanterre, Hauts-de-Seine",
        "CITY":                   "Nanterre",
        "STATE":                  "Hauts-de-Seine",
        "POSTAL_CODE":            "92000",
        "FACILITY_REGION":        "France",
        "LATITUDE":               "",
        "LONGITUDE":              "",
        "FACILITY_CONTACT_NUMBER": "+33-01-84781461",
        "ACTIVITY_AT_SOURCE":     "European technology and business development office",
        "FACILITY_NAME_NATIVE":   "时代新能源欧洲业务拓展中心（楠泰尔）",
        "FACILITY_ADDRESS_NATIVE": "1 boulevard des bouvets, 92000 Nanterre, France",
        "source": "[L]",
    },
]


def clean_address(address: str) -> str:
    """Remove geocoding-unfriendly characters."""
    if not address:
        return address
    address = address.replace("#", "No.")
    address = re.sub(r'\s+', ' ', address).strip()
    return address


def bing_geocode(address: str, city: str = "", state: str = "", country: str = "") -> tuple:
    """Geocode using Bing Maps API. Returns (lat, lon) or (None, None)."""
    query = address.strip()
    if not query:
        parts = [p for p in [city, state, country] if p and p.strip()]
        query = ", ".join(parts)
    if not query:
        return None, None
    try:
        params = {"q": query, "key": BING_API_KEY, "maxResults": 1}
        resp = requests.get(BING_API_URL, params=params, timeout=15, verify=False)
        data = resp.json()
        resources = data.get("resourceSets", [{}])[0].get("resources", [])
        if resources:
            coords = resources[0]["point"]["coordinates"]
            return float(coords[0]), float(coords[1])
    except Exception as e:
        print(f"  Geocoding error for '{query[:70]}': {e}")
    return None, None


def build_dataframe(facilities: list[dict]) -> pd.DataFrame:
    rows = []
    for i, fac in enumerate(facilities):
        lat_raw = str(fac.get("LATITUDE", "")).strip()
        lon_raw = str(fac.get("LONGITUDE", "")).strip()

        has_coords = (lat_raw not in ("", "null", "None", "N/A") and
                      lon_raw not in ("", "null", "None", "N/A"))
        lat = lon = None
        coord_source = ""

        if has_coords:
            try:
                lat = float(lat_raw)
                lon = float(lon_raw)
                coord_source = "website"
            except ValueError:
                has_coords = False

        raw_address = fac.get("FACILITY_ADDRESS", "")
        clean_addr  = clean_address(raw_address)

        if not has_coords:
            print(f"  [{i+1}/{len(facilities)}] Geocoding: {clean_addr[:80]}")
            lat, lon = bing_geocode(
                clean_addr,
                fac.get("CITY", ""),
                fac.get("STATE", ""),
                fac.get("FACILITY_REGION", ""),
            )
            coord_source = "bing" if lat is not None else ""
            time.sleep(0.3)

        rows.append({
            "ISSUER_ID":               ISSUER_ID,
            "ISSUER_NAME":             ISSUER_NAME,
            "FACILITY_NAME":           fac.get("FACILITY_NAME", ""),
            "FACILITY_ADDRESS":        clean_addr,
            "CITY":                    fac.get("CITY", ""),
            "STATE":                   fac.get("STATE", ""),
            "POSTAL_CODE":             fac.get("POSTAL_CODE", ""),
            "FACILITY_REGION":         fac.get("FACILITY_REGION", ""),
            "LATITUDE":                lat if lat is not None else "",
            "LONGITUDE":               lon if lon is not None else "",
            "FACILITY_CONTACT_NUMBER": fac.get("FACILITY_CONTACT_NUMBER", ""),
            "RELEVANT_URL":            RELEVANT_URL,
            "ACTIVITY_AT_SOURCE":      fac.get("ACTIVITY_AT_SOURCE", ""),
            "coord_source":            coord_source,
            "FACILITY_NAME_NATIVE":    fac.get("FACILITY_NAME_NATIVE", ""),
            "FACILITY_ADDRESS_NATIVE": fac.get("FACILITY_ADDRESS_NATIVE", ""),
        })
    return pd.DataFrame(rows)


def main():
    print("=" * 65)
    print("CATL FACILITY CSV BUILDER")
    print(f"Total facilities compiled: {len(RAW_FACILITIES)}")
    print("=" * 65)

    print(f"\n[STEP 1] Geocoding {len(RAW_FACILITIES)} facilities via Bing Maps...")
    df = build_dataframe(RAW_FACILITIES)

    df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")
    print(f"\n[CHECKPOINT] Saved {len(df)} rows -> {OUTPUT_CSV}")

    # Count check
    print(f"\n[ASSESSMENT] {len(df)} facilities extracted")
    if len(df) >= 20:
        print("  ✓ Minimum count of 20 achieved.")
    else:
        print(f"  GAP: {20-len(df)} short of 20 minimum.")

    # Summary
    print("\n[RESULTS SUMMARY]")
    summary = df[["FACILITY_NAME", "CITY", "FACILITY_REGION", "coord_source"]].copy()
    print(summary.to_string(index=False))

    # Geocoding stats
    bing_count    = (df["coord_source"] == "bing").sum()
    website_count = (df["coord_source"] == "website").sum()
    blank_count   = (df["coord_source"] == "").sum()
    print(f"\n[GEOCODING STATS]")
    print(f"  Bing geocoded:      {bing_count}")
    print(f"  From website:       {website_count}")
    print(f"  No coords:          {blank_count}")

    return df


if __name__ == "__main__":
    main()
