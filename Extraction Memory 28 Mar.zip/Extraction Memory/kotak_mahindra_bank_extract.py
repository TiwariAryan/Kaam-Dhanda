"""
KOTAK MAHINDRA BANK LIMITED — Branch Extractor
Source: https://www.kotak.com/en/reach-us.html
Usage: python -m issuers.kotak_mahindra_bank.extract

Strategy:
  1. Fetch state/city list from /kotak/getStateCityList API
  2. For each state+city combo, call the .map.reachus. AEM Sling API
  3. Filter type=2 branches (non-ATM) with valid IFSC codes
  4. Deduplicate by identityValue
  5. Export to XLSX/CSV/JSON
"""
import asyncio
import base64
import json
import time
from pathlib import Path

import httpx

from issuers.common import (
    log, COLUMNS, quality_report, print_sample,
    save_json, export_xlsx, archive_scripts,
)

ISSUER     = "KOTAK MAHINDRA BANK LIMITED"
BASE_URL   = "https://www.kotak.com/en/reach-us.html"
OUT        = "kotak_mahindra_bank_output"
ISSUER_DIR = Path(__file__).parent

MAPS_BASE  = "https://www.kotak.bank.in/content/kotakcl/en/reach-us/_jcr_content/mid_par/maps"
STATE_CITY_URL = "https://www.kotak.com/kotak/getStateCityList"
PROGRESS_FILE = Path(OUT) / "progress.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "en-US,en;q=0.9",
    "X-Requested-With": "XMLHttpRequest",
    "Referer": "https://www.kotak.com/en/reach-us.html",
    "Origin": "https://www.kotak.com",
}


def b64(s):
    """Base64 encode a value (using jQuery base64 convention: same as standard)."""
    return base64.b64encode(str(s).encode()).decode()


def build_search_url(state: str, city: str, radius: float = 0.003) -> str:
    """Build the branch search API URL for a given state+city."""
    lat = "0"
    lng = "0"
    call_type = "userSearch"
    identifier = f"{state}|{city}"
    page_num = 0
    url = (
        f"{MAPS_BASE}.map.reachus."
        f"{b64(lat)}."
        f"{b64(lng)}."
        f"{b64(radius)}."
        f"{b64(call_type)}."
        f"{page_num}."
        f"{b64(identifier)}.json"
    )
    return url


def parse_branch(b: dict, city_slug: str) -> dict | None:
    """
    Parse a BranchList item into the standard column schema.
    Returns None if the entry should be excluded (ATM, recycler, etc.)
    """
    branch_type = b.get("branchOrATMType")
    ifsc = b.get("ifscCode", "NA")

    # Include only type 2 (branches) and type 4 (eLobby physical locations)
    # Exclude type 1 (ATMs/Recyclers) and entries with no valid IFSC
    if branch_type not in (2, 4):
        return None
    # For type 2, require a valid KKBK IFSC code
    if branch_type == 2 and (not ifsc or ifsc == "NA" or not ifsc.upper().startswith("KKBK")):
        return None

    name = b.get("branchOrATMName", "").strip()
    address = b.get("addressValue", "").strip()
    city = b.get("cityName", "").strip()
    state = b.get("stateName", "").strip()
    pincode = str(b.get("pincodeNumber", "")).strip()
    lat = b.get("latitudeValue")
    lng = b.get("longitudeValue")
    phone = b.get("phoneNumber", "").strip()
    branch_url = b.get("branchUrl", "").strip()

    # Build the relevant URL
    if branch_url and branch_url.lower() not in ("na", "", "null"):
        relevant_url = f"https://www.kotak.com/en/reach-us/detail/ifsc-code/{city_slug}/{branch_url}.html"
    else:
        relevant_url = BASE_URL

    # Clean address
    address = address.replace(";", ",").strip()
    if address.endswith(","):
        address = address[:-1].strip()

    # Validate coords
    lat_out = ""
    lng_out = ""
    if lat and lng:
        try:
            flat, flng = float(lat), float(lng)
            if 6 <= flat <= 37 and 68 <= flng <= 98:
                lat_out = str(flat)
                lng_out = str(flng)
        except (TypeError, ValueError):
            pass

    return {
        "FACILITY_NAME": name,
        "FACILITY_ADDRESS": address,
        "CITY": city.title(),
        "STATE": state.title(),
        "POSTAL_CODE": pincode if pincode and pincode != "0" else "",
        "FACILITY_REGION": "India",
        "LATITUDE": lat_out,
        "LONGITUDE": lng_out,
        "FACILITY_CONTACT_NUMBER": phone,
        "RELEVANT_URL": relevant_url,
        "BUSINESS_ACTIVITY": "Banking",
        "_identity": b.get("identityValue"),
        "_ifsc": ifsc,
        "_type": branch_type,
    }


async def fetch_city_branches(client: httpx.AsyncClient, state: str, city: str) -> list[dict]:
    """Fetch all branches for a state+city combination."""
    url = build_search_url(state, city)
    city_slug = city.lower().replace(" ", "-")
    for attempt in range(3):
        try:
            r = await client.get(url, timeout=30)
            if r.status_code == 200:
                data = r.json()
                branch_list = data.get("BranchList", [])
                records = []
                for b in branch_list:
                    parsed = parse_branch(b, city_slug)
                    if parsed:
                        records.append(parsed)
                return records
            elif r.status_code in (429, 503):
                await asyncio.sleep(5 * (attempt + 1))
            else:
                log(f"  [{state}|{city}] HTTP {r.status_code} - skipping")
                return []
        except Exception as e:
            if attempt < 2:
                await asyncio.sleep(2)
            else:
                log(f"  [{state}|{city}] Error: {e}")
    return []


def load_progress() -> tuple[dict, set]:
    """Load progress file. Returns (all_records_dict, done_combos_set)."""
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, encoding="utf-8") as f:
            prog = json.load(f)
        records_dict = {r["_identity"]: r for r in prog.get("records", [])}
        done = set(tuple(k.split("|", 1)) for k in prog.get("done", []))
        log(f"  Resuming from progress: {len(records_dict)} records, {len(done)} combos done")
        return records_dict, done
    return {}, set()


def save_progress(records_dict: dict, done_combos: set):
    """Save intermediate progress."""
    Path(OUT).mkdir(exist_ok=True)
    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "records": list(records_dict.values()),
            "done": [f"{s}|{c}" for s, c in done_combos],
        }, f, ensure_ascii=False)


async def main():
    log("=" * 70)
    log(f"{ISSUER} EXTRACTOR")
    log("=" * 70)

    Path(OUT).mkdir(exist_ok=True)

    # Load state/city list
    log("\n[1/4] Fetching state/city list...")
    async with httpx.AsyncClient(headers=HEADERS, follow_redirects=True, verify=False) as client:
        sc_resp = await client.get(STATE_CITY_URL, timeout=15)
        sc_data = sc_resp.json()

    state_city_map = sc_data.get("stateCityDropDownData", {})
    combos = [(state, city) for state, cities in state_city_map.items() for city in cities]
    log(f"  {len(state_city_map)} states, {len(combos)} state+city combinations")

    # Load progress
    records_dict, done_combos = load_progress()

    remaining = [(s, c) for s, c in combos if (s, c) not in done_combos]
    log(f"\n[2/4] Fetching branches ({len(remaining)} remaining combos)...")

    async with httpx.AsyncClient(headers=HEADERS, follow_redirects=True, verify=False) as client:
        for i, (state, city) in enumerate(remaining, 1):
            branches = await fetch_city_branches(client, state, city)
            new_count = 0
            for b in branches:
                identity = b["_identity"]
                if identity not in records_dict:
                    records_dict[identity] = b
                    new_count += 1

            done_combos.add((state, city))

            status = f"+{new_count}" if new_count else "dup"
            log(f"  [{i}/{len(remaining)}] {state}|{city}: {len(branches)} fetched ({status}), total={len(records_dict)}")

            # Save progress every 20 combos
            if i % 20 == 0:
                save_progress(records_dict, done_combos)
                log(f"  [Progress saved - {len(records_dict)} unique branches]")

            # Polite delay
            await asyncio.sleep(0.3)

    save_progress(records_dict, done_combos)

    # Filter to final records
    log(f"\n[3/4] Processing {len(records_dict)} unique records...")
    all_records = list(records_dict.values())

    # Separate by type
    type2_branches = [r for r in all_records if r.get("_type") == 2]
    type4_elobby = [r for r in all_records if r.get("_type") == 4]

    log(f"  Type 2 (branches): {len(type2_branches)}")
    log(f"  Type 4 (eLobby):   {len(type4_elobby)}")

    # Use type 2 branches as primary output (non-ATM as requested)
    final_records = type2_branches

    log(f"  Final non-ATM branches: {len(final_records)}")

    quality_report(final_records)
    print_sample(final_records, n=5)

    log(f"\n[4/4] Exporting...")
    jp = save_json(final_records, OUT, ISSUER, BASE_URL)
    export_xlsx(jp)

    # Also export CSV
    import csv
    csv_path = jp.with_suffix(".csv")
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as cf:
        writer = csv.DictWriter(cf, fieldnames=COLUMNS)
        writer.writeheader()
        for row in final_records:
            writer.writerow({k: row.get(k, "") for k in COLUMNS})
    log(f"  CSV: {csv_path}")

    # Archive scripts
    archive_scripts(ISSUER_DIR, [Path(__file__)])

    log(f"\n{'='*70}")
    log(f"DONE: {len(final_records)} non-ATM branches extracted")
    log(f"{'='*70}")

    # Clean up progress file on success
    if PROGRESS_FILE.exists():
        PROGRESS_FILE.unlink()


if __name__ == "__main__":
    asyncio.run(main())
