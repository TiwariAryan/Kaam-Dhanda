"""
CHROMA ATE INC. — Global Facility Extractor
Sources:
  https://www.chromaate.com/en/chroma/global/americas
  https://www.chromaate.com/en/chroma/global/asia
  https://www.chromaate.com/en/chroma/global/europe
Usage: python -m issuers.chroma_ate.extract
"""
import asyncio
import re
import sys
from pathlib import Path

import httpx
from bs4 import BeautifulSoup, NavigableString

# Add project root to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from issuers.common import (
    log, COLUMNS, quality_report, print_sample,
    save_json, export_xlsx, archive_scripts,
)

ISSUER     = "CHROMA ATE INC."
BASE_URL   = "https://www.chromaate.com"
OUT        = "chroma_ate_output"
ISSUER_DIR = Path(__file__).parent

SOURCE_URLS = {
    "americas": f"{BASE_URL}/en/chroma/global/americas",
    "asia":     f"{BASE_URL}/en/chroma/global/asia",
    "europe":   f"{BASE_URL}/en/chroma/global/europe",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

# CJK Unicode ranges
CJK_RE = re.compile(
    r'[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af\u3400-\u4dbf]'
)

def is_cjk_heavy(text: str) -> bool:
    """Return True if text contains >20% CJK characters."""
    if not text:
        return False
    cjk_count = len(CJK_RE.findall(text))
    return cjk_count / len(text) > 0.2


def strip_cjk(text: str) -> str:
    """Remove CJK characters, empty parentheses, and clean residual whitespace."""
    result = CJK_RE.sub('', text)
    result = re.sub(r'\(\s*\)', '', result)   # remove empty parentheses "()"
    result = re.sub(r'\s+', ' ', result).strip()
    return result


US_STATE_TO_ABBR = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR',
    'California': 'CA', 'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE',
    'Florida': 'FL', 'Georgia': 'GA', 'Hawaii': 'HI', 'Idaho': 'ID',
    'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA', 'Kansas': 'KS',
    'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS',
    'Missouri': 'MO', 'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV',
    'New Hampshire': 'NH', 'New Jersey': 'NJ', 'New Mexico': 'NM', 'New York': 'NY',
    'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH', 'Oklahoma': 'OK',
    'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
    'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT',
    'Vermont': 'VT', 'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV',
    'Wisconsin': 'WI', 'Wyoming': 'WY', 'District of Columbia': 'DC',
}
STREET_SUFFIXES = {
    'St', 'Street', 'Rd', 'Road', 'Ave', 'Avenue', 'Blvd', 'Boulevard',
    'Dr', 'Drive', 'Ln', 'Lane', 'Ct', 'Court', 'Pl', 'Place', 'Trail',
    'Trl', 'Way', 'Pkwy', 'Hwy', 'Suite', 'Ste', 'Floor', 'Fl', 'Cir',
}


def extract_english_address(li_tag) -> str:
    """
    Extract the English address from an address <li> element.
    The li may contain: English text + <br/> + Chinese/Japanese text.
    We take only the English portion.
    """
    parts = []
    for child in li_tag.children:
        if isinstance(child, NavigableString):
            text = str(child).strip()
            if text and not is_cjk_heavy(text):
                parts.append(text)
        elif child.name == 'br':
            # After a <br>, we might have a Chinese line — skip siblings after br
            break
    result = ' '.join(parts).strip()
    # Also remove PC: postal code notation embedded in address
    result = re.sub(r'\s*PC:\d+', '', result).strip()
    return result


def parse_address(address: str, country: str):
    """
    Parse address string into components.
    Returns dict with FACILITY_ADDRESS, CITY, STATE, POSTAL_CODE.

    Key design: FACILITY_ADDRESS always stores the full English address string.
    City, State, Postal are extracted separately using country-specific patterns.
    """
    result = {
        "FACILITY_ADDRESS": address,  # keep full address
        "CITY": "",
        "STATE": "",
        "POSTAL_CODE": "",
    }
    if not address:
        return result

    # Remove trailing country name to get a clean working copy for parsing
    country_variants = [
        country, "USA", "U.S.A.", "United States", "Taiwan", "China",
        "Germany", "Netherlands", "The Netherlands", "Japan", "Korea",
        "Singapore", "India", "Malaysia", "Thailand", "Vietnam",
        "Indonesia", "Philippines", "Hong Kong", "France", "Italy",
        "Poland", "Czech Republic", "Sweden", "Denmark", "Belgium",
        "Portugal", "Spain", "Slovakia", "Finland", "Norway", "Romania",
        "Bulgaria", "Mexico", "Brazil", "United Kingdom", "UK",
        "Russia", "Israel", "Turkey", "South Africa", "Australia",
        "New Zealand", "Canada",
    ]
    clean_addr = address
    for cv in country_variants:
        clean_addr = re.sub(
            r',?\s*' + re.escape(cv) + r'\s*$', '', clean_addr, flags=re.IGNORECASE
        ).strip()

    parts = [p.strip() for p in clean_addr.split(',') if p.strip()]
    cc = country.lower()

    if 'united states' in cc or cc == 'usa' or 'united states' in address.lower():
        # Pattern A: "Street, City, ST ZIPCODE, USA" (abbreviated state)
        m = re.search(r',\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)', address)
        if m:
            result["STATE"] = m.group(1)
            result["POSTAL_CODE"] = m.group(2)
            before = address[:m.start()].strip()
            bparts = [p.strip() for p in before.split(',') if p.strip()]
            if len(bparts) >= 2:
                result["CITY"] = bparts[-1].strip()
            elif len(bparts) == 1:
                # City embedded in address — extract last word(s) before a street suffix
                words = bparts[0].split()
                city_words = []
                for w in reversed(words):
                    if re.match(r'^\d', w) or w in STREET_SUFFIXES or w.rstrip('.') in STREET_SUFFIXES:
                        break
                    if re.match(r'^[A-Z][a-zA-Z-]+$', w):
                        city_words.insert(0, w)
                    else:
                        break
                result["CITY"] = ' '.join(city_words) if city_words else bparts[0]
        else:
            # Pattern B: spelled-out state "City, Arizona 85225, USA"
            for state_name, abbr in US_STATE_TO_ABBR.items():
                m2 = re.search(
                    r',\s*(' + re.escape(state_name) + r')\s+(\d{5}(?:-\d{4})?)',
                    address, re.IGNORECASE
                )
                if m2:
                    result["STATE"] = abbr
                    result["POSTAL_CODE"] = m2.group(2)
                    before = address[:m2.start()].strip()
                    bparts = [p.strip() for p in before.split(',') if p.strip()]
                    result["CITY"] = bparts[-1].strip() if bparts else ""
                    break

    elif 'mexico' in cc:
        # "Street, Colony, City, State, ZIPCODE, Mexico"
        m = re.search(r'(\d{5})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        # City = 3rd-to-last part, state = 2nd-to-last
        if len(parts) >= 3:
            result["CITY"] = parts[-3]
            result["STATE"] = parts[-2]
        elif len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'taiwan' in cc:
        # "88 Wenmao Road, Guishan District, Taoyuan City 333001"
        m = re.search(r'([A-Za-z\s]{3,20}(?:City|County))\s+(\d{5,6})', clean_addr)
        if m:
            result["CITY"] = m.group(1).strip()
            result["POSTAL_CODE"] = m.group(2)
        else:
            m2 = re.search(r'\b(\d{5,6})\b', clean_addr)
            if m2:
                result["POSTAL_CODE"] = m2.group(1)
            if parts:
                result["CITY"] = re.sub(r'\d+', '', parts[-1]).strip()

    elif 'china' in cc:
        m = re.search(r'PC:?\s*(\d{6})', address)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        # City = last short non-numeric, non-CJK part
        for p in reversed(parts):
            if not re.search(r'^\d', p) and len(p) < 30 and not is_cjk_heavy(p):
                result["CITY"] = p
                break

    elif 'hong kong' in cc:
        result["CITY"] = "Hong Kong"
        if parts:
            result["CITY"] = parts[-1] if len(parts) >= 1 else "Hong Kong"

    elif 'japan' in cc:
        m = re.search(r'(\d{3}-?\d{4})', address)
        if m:
            result["POSTAL_CODE"] = re.sub(r'-', '', m.group(1))
        if parts:
            result["CITY"] = parts[-2] if len(parts) >= 2 else parts[-1]

    elif 'south korea' in cc or 'korea' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'singapore' in cc:
        m = re.search(r'\b(\d{6})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        result["CITY"] = "Singapore"

    elif 'india' in cc:
        m = re.search(r'\b(\d{6})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            # City = last text part before the postal code
            before = clean_addr[:m.start()].strip().rstrip(',').strip()
            bparts = [p.strip() for p in before.split(',') if p.strip() and not re.match(r'^\d', p.strip())]
            if bparts:
                result["CITY"] = bparts[-1]
        elif len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'malaysia' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'thailand' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'vietnam' in cc:
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'indonesia' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'philippines' in cc:
        m = re.search(r'\b(\d{4})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    elif 'germany' in cc:
        # "Südtiroler Str. 9, 86165 Augsburg"
        m = re.search(r'\b(\d{5})\s+([A-Za-züäöÄÖÜß][A-Za-züäöÄÖÜß\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'netherlands' in cc:
        # "6716 AH Ede" → POSTAL=6716 AH, CITY=Ede
        m = re.search(r'(\d{4}\s*[A-Z]{2})\s+([A-Za-z][A-Za-z\s-]{1,20})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1).strip()
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'austria' in cc:
        # Some Austrian-listed distributors may have German addresses (D-XXXXX prefix)
        # Try German 5-digit postal first, then Austrian 4-digit
        m = re.search(r'\bD-(\d{5})\s+([A-Za-züäöÄÖÜß][A-Za-züäöÄÖÜß\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            result["CITY"] = m.group(2).strip().rstrip(',')
        else:
            m2 = re.search(r'\b(\d{4})\s+([A-Za-zÄÖÜäöü][A-Za-zÄÖÜäöü\s-]{1,20})', clean_addr)
            if m2:
                result["POSTAL_CODE"] = m2.group(1)
                result["CITY"] = m2.group(2).strip().rstrip(',')

    elif 'france' in cc:
        m = re.search(r'\b(\d{5})\s+([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'italy' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            after = clean_addr[m.end():].strip().lstrip(',').strip()
            after_parts = [p.strip() for p in after.split(',') if p.strip()]
            if after_parts:
                # Remove parenthetical province codes like "(MI)"
                city = re.sub(r'\s*\([A-Z]{2}\)', '', after_parts[0]).strip()
                result["CITY"] = city
            else:
                before = clean_addr[:m.start()].strip().rstrip(',')
                bparts = [p.strip() for p in before.split(',') if p.strip()]
                result["CITY"] = bparts[-1] if bparts else ""

    elif 'poland' in cc:
        m = re.search(r'\b(\d{2}-\d{3})\s+([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'czech' in cc:
        # Handle "619 00, Brno" (city after postal) or "619 00 Brno" (city after postal, space sep)
        m = re.search(r'(\d{3}\s?\d{2})', clean_addr)
        if m:
            result["POSTAL_CODE"] = re.sub(r'\s', '', m.group(1))
            after = clean_addr[m.end():].strip().lstrip(',').strip()
            after_parts = [p.strip() for p in after.split(',') if p.strip()]
            if after_parts:
                result["CITY"] = after_parts[0]
            else:
                # City might be in the SAME part before the postal
                before_parts = [p.strip() for p in clean_addr[:m.start()].split(',') if p.strip()]
                result["CITY"] = before_parts[-1] if before_parts else ""

    elif 'sweden' in cc:
        m = re.search(r'\b(\d{3}\s?\d{2})\s+([A-Za-z][A-Za-z\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = re.sub(r'\s', '', m.group(1))
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'denmark' in cc or 'norway' in cc or 'belgium' in cc or 'finland' in cc:
        m = re.search(r'\b(\d{4,5})\s+([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ\s-]{1,25})', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            result["CITY"] = m.group(2).strip().rstrip(',')

    elif 'israel' in cc:
        m = re.search(r'\b(\d{7})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            # City is before the postal code
            before = clean_addr[:m.start()].rstrip(',').strip()
            bparts = [p.strip() for p in before.split(',') if p.strip()]
            if bparts:
                result["CITY"] = bparts[-1]
        elif len(parts) >= 2:
            result["CITY"] = parts[-1]

    elif 'turkey' in cc:
        m = re.search(r'\b(\d{5})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
            # City often comes after the postal code (e.g. "06980, Kahramankazan – ANKARA")
            after = clean_addr[m.end():].strip().lstrip(',').strip()
            if after:
                # Take first clean word group (may have – separator)
                city_part = re.split(r'[–—]', after)[0].strip().lstrip(',').strip()
                city_part = city_part.split(',')[0].strip()
                result["CITY"] = city_part if city_part else (parts[-2] if len(parts) >= 2 else "")
            elif len(parts) >= 2:
                result["CITY"] = parts[-2]

    elif 'brazil' in cc:
        m = re.search(r'\b(\d{5})-?(\d{3})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1) + m.group(2)
            before = clean_addr[:m.start()].rstrip(',').strip()
            bparts = [p.strip() for p in before.split(',') if p.strip()]
            result["CITY"] = bparts[-1] if bparts else ""
        elif len(parts) >= 2:
            # Handle "City – STATE" format
            m2 = re.match(r'^(.+?)\s*[–—-]\s*([A-Z]{2})', clean_addr)
            if m2:
                result["CITY"] = m2.group(1).strip()
                result["STATE"] = m2.group(2).strip()
            else:
                result["CITY"] = parts[-2]
        elif len(parts) == 1:
            # "Porto Alegre – RS"
            m3 = re.match(r'^(.+?)\s*[–—-]\s*([A-Z]{2})', clean_addr)
            if m3:
                result["CITY"] = m3.group(1).strip()
                result["STATE"] = m3.group(2).strip()

    elif 'canada' in cc:
        # "Street, City, Province  POSTAL, Canada"
        m = re.search(r'([A-Z]\d[A-Z]\s?\d[A-Z]\d)', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1).strip()
        if len(parts) >= 2:
            result["CITY"] = parts[-2]

    else:
        # Generic fallback
        m = re.search(r'\b(\d{4,6})\b', clean_addr)
        if m:
            result["POSTAL_CODE"] = m.group(1)
        if len(parts) >= 2:
            result["CITY"] = parts[-1]
        elif len(parts) == 1:
            result["CITY"] = parts[0]

    # Clean up city — remove leading/trailing digits, dashes, and punctuation
    if result["CITY"]:
        city = result["CITY"]
        city = re.sub(r'^\d+\s*', '', city)          # remove leading digits
        city = city.strip().strip(',').strip('–').strip('-').strip()
        city = re.sub(r'\s*[–—-]\s*$', '', city)     # remove trailing en/em dashes
        city = re.sub(r'\s+', ' ', city).strip()
        result["CITY"] = city

    return result


COUNTRY_REGION_MAP = {
    "Taiwan": "Asia",
    "China": "Asia",
    "Japan": "Asia",
    "South Korea": "Asia",
    "Korea": "Asia",
    "Singapore": "Asia",
    "India": "Asia",
    "Malaysia": "Asia",
    "Thailand": "Asia",
    "Vietnam": "Asia",
    "Indonesia": "Asia",
    "Philippines": "Asia",
    "Hong Kong": "Asia",
    "United States": "Americas",
    "USA": "Americas",
    "Canada": "Americas",
    "Mexico": "Americas",
    "Brazil": "Americas",
    "Germany": "Europe",
    "Netherlands": "Europe",
    "Austria": "Europe",
    "France": "Europe",
    "Italy": "Europe",
    "Poland": "Europe",
    "Czech Republic": "Europe",
    "Sweden": "Europe",
    "Denmark": "Europe",
    "Belgium": "Europe",
    "Finland": "Europe",
    "Norway": "Europe",
    "United Kingdom": "Europe",
    "UK": "Europe",
    "Spain": "Europe",
    "Portugal": "Europe",
    "Romania": "Europe",
    "Bulgaria": "Europe",
    "Slovakia": "Europe",
    "Israel": "Middle East",
    "Turkey": "Middle East",
    "South Africa": "Africa",
    "Australia": "Oceania",
    "New Zealand": "Oceania",
    "Russia": "Europe",
}

BUSINESS_ACTIVITY_KEYWORDS = {
    "Manufacturing": ["manufactur", "production", "factory", "plant"],
    "Research & Development": ["r&d", "research", "development", "lab"],
    "Sales": ["sales", "commercial"],
    "Service": ["service", "repair", "maintenance", "support"],
    "Office": ["office", "headquarter", "hq", "branch"],
    "Distribution": ["distribution", "warehouse", "logistics"],
    "Test & Measurement": ["test", "measurement", "instrument", "testing"],
    "Technology Center": ["technology center", "tech center", "ev and battery"],
}


def map_business_activity(company_name: str, office_name: str, service_area: str) -> str:
    """Map available text to a standardized business activity."""
    combined = f"{company_name} {office_name} {service_area}".lower()
    activities = []
    for activity, keywords in BUSINESS_ACTIVITY_KEYWORDS.items():
        if any(kw in combined for kw in keywords):
            activities.append(activity)
    if not activities:
        activities = ["Office"]
    return "; ".join(sorted(set(activities)))


def parse_card(card, source_url: str, region_label: str) -> dict:
    """Parse a single country_card div into a standardized record."""
    # Country
    country_tag = card.find('p', class_='countyr_name')
    country = country_tag.get_text(strip=True) if country_tag else ""

    # Company name and office name from span.con_name
    con_name_tag = card.find('span', class_='con_name')
    company_name = ""
    office_name = ""
    if con_name_tag:
        texts = []
        for child in con_name_tag.children:
            if isinstance(child, NavigableString):
                # Strip CJK and keep English portion
                t = strip_cjk(str(child))
                if t:
                    texts.append(t)
            # <br> separates company name from office name (skip it as separator)
        if texts:
            company_name = texts[0]
            # Filter out trivially empty office names (e.g. "()" from CJK stripping)
            remaining = [t for t in texts[1:] if t and t not in ('()', '( )', '-')]
            office_name = ' '.join(remaining) if remaining else ""

    # Parse ul > li items
    service_area = ""
    address_raw = ""
    tel = ""
    fax = ""
    url = ""
    email = ""

    lis = card.find_all('li')
    for li in lis:
        # Skip social media li
        if 'social-icon' in (li.get('class') or []):
            continue

        li_text = li.get_text(separator=' ', strip=True)

        # Service area (in <em> tag)
        em = li.find('em')
        if em:
            sa_text = em.get_text(strip=True)
            if sa_text.startswith('Service Area:'):
                service_area = sa_text.replace('Service Area:', '').strip()
            continue

        # Tel
        if li_text.startswith('Tel:'):
            tel = li_text.replace('Tel:', '').strip()
            continue

        # Fax
        if li_text.startswith('Fax:'):
            fax = li_text.replace('Fax:', '').strip()
            continue

        # URL
        if li_text.startswith('URL:'):
            url_a = li.find('a')
            if url_a:
                url = url_a.get('href', '').strip()
            continue

        # Email
        if li_text.startswith('Email:'):
            email_a = li.find('a')
            if email_a:
                email = email_a.get_text(strip=True)
            continue

        # Address (remaining li that doesn't match above)
        if not address_raw and li_text and not is_cjk_heavy(li_text):
            address_raw = extract_english_address(li)

    # Parse address into components
    addr_parts = parse_address(address_raw, country)

    # Facility name: company name + office name if present
    facility_name = company_name
    if office_name:
        facility_name = f"{company_name} - {office_name}"

    # Map country to region
    facility_region = COUNTRY_REGION_MAP.get(country, region_label)

    # Business activity
    business_activity = map_business_activity(company_name, office_name, service_area)

    record = {
        "FACILITY_NAME":    facility_name,
        "FACILITY_ADDRESS": addr_parts["FACILITY_ADDRESS"],
        "CITY":             addr_parts["CITY"],
        "STATE":            addr_parts["STATE"],
        "POSTAL_CODE":      addr_parts["POSTAL_CODE"],
        "FACILITY_REGION":  country,  # Use actual country as region for specificity
        "LATITUDE":         "",
        "LONGITUDE":        "",
        "FACILITY_CONTACT_NUMBER": tel,
        "RELEVANT_URL":     source_url,
        "BUSINESS_ACTIVITY": business_activity,
        # Extra context fields (will be dropped for final export but useful for QC)
        "_country":        country,
        "_region_page":    region_label,
        "_company_name":   company_name,
        "_office_name":    office_name,
        "_service_area":   service_area,
        "_fax":            fax,
        "_url":            url,
        "_email":          email,
        "_address_raw":    address_raw,
    }
    return record


async def fetch_page(client: httpx.AsyncClient, url: str) -> str:
    r = await client.get(url, headers=HEADERS, follow_redirects=True, timeout=30)
    r.raise_for_status()
    return r.text


async def main():
    log("=" * 70)
    log(f"{ISSUER} — GLOBAL FACILITY EXTRACTOR")
    log("=" * 70)

    records = []

    async with httpx.AsyncClient(verify=False) as client:
        for region_label, url in SOURCE_URLS.items():
            log(f"\nFetching {region_label.upper()}: {url}")
            html = await fetch_page(client, url)
            soup = BeautifulSoup(html, 'html.parser')
            cards = soup.find_all('div', class_='country_card')
            log(f"  Found {len(cards)} country_card entries")

            for card in cards:
                rec = parse_card(card, url, region_label.capitalize())
                records.append(rec)

    log(f"\nTotal raw records: {len(records)}")

    # Deduplicate by facility name + address
    seen = set()
    deduped = []
    for r in records:
        key = (r["FACILITY_NAME"].lower(), r["FACILITY_ADDRESS"].lower())
        if key not in seen:
            seen.add(key)
            deduped.append(r)
    log(f"After dedup: {len(deduped)} records")

    quality_report(deduped)
    print_sample(deduped, n=5)

    jp = save_json(deduped, OUT, ISSUER, BASE_URL)
    export_xlsx(jp)

    archive_scripts(ISSUER_DIR, [Path(__file__)])
    log("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
