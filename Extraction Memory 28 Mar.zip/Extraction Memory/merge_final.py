"""
Merge all Bajaj Finance Limited extraction outputs into one final file.
Sources:
  1. BAJAJ_FINANCE_LIMITED_*_final.json   → 689 records (BHFL + Bajaj Allianz Life)
  2. bagic_branches_*.json                → 200 records (BAGIC)
  3. bfs_all_outlets.json OR BFS_NEARME_*.json  → BFS nearme records
"""
import json
import sys
import re
import glob
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.stdout.reconfigure(encoding='utf-8')

BASE = Path("c:/Users/tiwaary/cusror_extraction/Yash Extraction Skill/Interactive_Asset_Scraper_Share")
OUT = BASE / "bajaj_finance_output"
BAJAJ_DIR = BASE / "BAJAJ_FINANCE_LIMITED"

# Final schema (standardized)
SCHEMA = [
    "FACILITY_NAME",
    "FACILITY_ADDRESS",
    "FACILITY_ADDRESS_2",
    "CITY",
    "STATE",
    "POSTAL_CODE",
    "FACILITY_REGION",
    "LATITUDE",
    "LONGITUDE",
    "FACILITY_CONTACT_NUMBER",
    "RELEVANT_URL",
    "SOURCE_URL",
    "BUSINESS_ACTIVITY",
]

def log(msg):
    print(msg, flush=True)


def normalize_row(row: dict) -> dict:
    """Map any source row to the final schema."""
    return {
        "FACILITY_NAME":          row.get("FACILITY_NAME", ""),
        "FACILITY_ADDRESS":       row.get("FACILITY_ADDRESS", ""),
        "FACILITY_ADDRESS_2":     row.get("FACILITY_ADDRESS_2", ""),
        "CITY":                   row.get("CITY", ""),
        "STATE":                  row.get("STATE", ""),
        "POSTAL_CODE":            row.get("POSTAL_CODE") or row.get("PINCODE", ""),
        "FACILITY_REGION":        row.get("FACILITY_REGION", "India"),
        "LATITUDE":               row.get("LATITUDE", ""),
        "LONGITUDE":              row.get("LONGITUDE", ""),
        "FACILITY_CONTACT_NUMBER": row.get("FACILITY_CONTACT_NUMBER") or row.get("PHONE", ""),
        "RELEVANT_URL":           row.get("RELEVANT_URL", ""),
        "SOURCE_URL":             row.get("SOURCE_URL", ""),
        "BUSINESS_ACTIVITY":      row.get("BUSINESS_ACTIVITY", ""),
    }


def load_json_records(path: Path) -> list:
    """Load JSON file - handles both list and dict-with-data."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("data", "records", "outlets", "branches"):
            if key in data:
                return data[key]
        # It might be a dict keyed by outlet_id
        return list(data.values())
    return []


def main():
    log("=" * 70)
    log("Bajaj Finance Limited — Final Merge")
    log("=" * 70)

    all_rows = []

    # 1. Main output (BHFL + Bajaj Allianz Life)
    main_files = sorted(BAJAJ_DIR.glob("BAJAJ_FINANCE_LIMITED_*_final.json"))
    if not main_files:
        main_files = sorted(OUT.glob("BAJAJ_FINANCE_LIMITED_*_final.json"))

    if main_files:
        main_file = main_files[-1]  # latest
        records = load_json_records(main_file)
        for r in records:
            all_rows.append(normalize_row(r))
        log(f"Loaded {len(records)} records from {main_file.name}")
    else:
        log("WARNING: No main BAJAJ output file found!")

    # 2. BAGIC output
    bagic_files = sorted(OUT.glob("bagic_branches_*.json"))
    if bagic_files:
        bagic_file = bagic_files[-1]
        records = load_json_records(bagic_file)
        for r in records:
            all_rows.append(normalize_row(r))
        log(f"Loaded {len(records)} records from {bagic_file.name}")
    else:
        log("WARNING: No BAGIC output file found!")

    # 3. BFS output (nearme.bajajfinserv.in)
    # Try final output first, then in-progress file
    bfs_final_files = sorted(OUT.glob("BFS_NEARME_*.json"))
    bfs_progress_file = OUT / "bfs_all_outlets.json"

    if bfs_final_files:
        bfs_file = bfs_final_files[-1]
        records = load_json_records(bfs_file)
        for r in records:
            all_rows.append(normalize_row(r))
        log(f"Loaded {len(records)} records from {bfs_file.name}")
    elif bfs_progress_file.exists():
        # Load raw outlets dict and convert
        with open(bfs_progress_file, encoding="utf-8") as f:
            raw = json.load(f)
        outlets = list(raw.values()) if isinstance(raw, dict) else raw
        log(f"Loaded {len(outlets)} raw outlets from bfs_all_outlets.json (in-progress)")
        for o in outlets:
            addr_raw = o.get("address_raw", "")
            addr_parts = [p.strip() for p in addr_raw.split("|") if p.strip()]
            addr1 = addr_parts[0] if len(addr_parts) > 0 else ""
            addr2 = addr_parts[1] if len(addr_parts) > 1 else ""
            name = o.get("name_display") or o.get("name", "Bajaj Finserv")
            row = {
                "FACILITY_NAME":          name or "Bajaj Finserv",
                "FACILITY_ADDRESS":       addr1,
                "FACILITY_ADDRESS_2":     addr2,
                "CITY":                   o.get("city", ""),
                "STATE":                  o.get("state", ""),
                "POSTAL_CODE":            o.get("pincode", ""),
                "FACILITY_REGION":        "India",
                "LATITUDE":               o.get("latitude", ""),
                "LONGITUDE":              o.get("longitude", ""),
                "FACILITY_CONTACT_NUMBER": o.get("phone", ""),
                "RELEVANT_URL":           o.get("url", ""),
                "SOURCE_URL":             "https://nearme.bajajfinserv.in",
                "BUSINESS_ACTIVITY":      "Financial Services",
            }
            all_rows.append(row)
    else:
        log("WARNING: No BFS output file found! Run bfs_full_extract.py first.")

    log(f"\nTotal raw records (before dedup): {len(all_rows)}")

    # Convert to DataFrame
    df = pd.DataFrame(all_rows, columns=SCHEMA)

    # Basic cleanup
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].fillna("").astype(str).str.strip()

    # Deduplicate: by lat/lng/name combo (when lat/lng available), else by name+city
    log("Deduplicating...")
    df_with_coords = df[df["LATITUDE"].notna() & (df["LATITUDE"] != "")]
    df_no_coords = df[df["LATITUDE"].isna() | (df["LATITUDE"] == "")]

    df_with_coords = df_with_coords.drop_duplicates(subset=["LATITUDE", "LONGITUDE", "FACILITY_NAME"])
    df_no_coords = df_no_coords.drop_duplicates(subset=["FACILITY_NAME", "CITY", "STATE"])

    df_final = pd.concat([df_with_coords, df_no_coords], ignore_index=True)

    # Remove clearly empty rows
    df_final = df_final[df_final["FACILITY_NAME"].notna() & (df_final["FACILITY_NAME"] != "")]

    log(f"After dedup: {len(df_final)} records")

    # Summary by source
    log("\nRecords by BUSINESS_ACTIVITY:")
    for act, cnt in df_final["BUSINESS_ACTIVITY"].value_counts().items():
        log(f"  {act}: {cnt}")

    # Save
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_out = BAJAJ_DIR / f"BAJAJ_FINANCE_LIMITED_{ts}_FINAL_MERGED.json"
    xlsx_out = BAJAJ_DIR / f"BAJAJ_FINANCE_LIMITED_{ts}_FINAL_MERGED.xlsx"

    df_final.to_json(json_out, orient="records", indent=2, force_ascii=False)
    df_final.to_excel(xlsx_out, index=False)

    log(f"\nSaved JSON: {json_out}")
    log(f"Saved XLSX: {xlsx_out}")
    log(f"TOTAL RECORDS: {len(df_final)}")


if __name__ == "__main__":
    main()
