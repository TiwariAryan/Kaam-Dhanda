import requests
import json
import re
import sys
import io
import html as html_module
from bs4 import BeautifulSoup
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
import warnings
warnings.filterwarnings('ignore')

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
BASE_URL = "https://www.continental-industry.com"

COUNTRIES = [
    {"label": "Brazil", "url": "/global/en/about-us/business-area/americas/brazil"},
    {"label": "Chile", "url": "/global/en/about-us/business-area/americas/chile"},
    {"label": "Mexico", "url": "/global/en/about-us/business-area/americas/mexico"},
    {"label": "NorthAmerica", "url": "/global/en/about-us/business-area/americas/usa"},
    {"label": "Austria", "url": "/global/en/about-us/business-area/emea/austria"},
    {"label": "Belgium", "url": "/global/en/about-us/business-area/emea/benelux"},
    {"label": "Finland", "url": "/global/en/about-us/business-area/emea/finland"},
    {"label": "France", "url": "/global/en/about-us/business-area/emea/france"},
    {"label": "Hungary", "url": "/global/en/about-us/business-area/emea/hungary"},
    {"label": "Poland", "url": "/global/en/about-us/business-area/emea/poland"},
    {"label": "Romania", "url": "/global/en/about-us/business-area/emea/romania"},
    {"label": "Slovenia", "url": "/global/en/about-us/business-area/emea/slovenia"},
    {"label": "SouthAfrica", "url": "/global/en/about-us/business-area/emea/south-africa"},
    {"label": "Spain", "url": "/global/en/about-us/business-area/emea/spainportugal"},
    {"label": "Sweden", "url": "/global/en/about-us/business-area/emea/sweden"},
    {"label": "Switzerland", "url": "/global/en/about-us/business-area/emea/switzerland"},
    {"label": "Turkiye", "url": "/global/en/about-us/business-area/emea/turkey"},
    {"label": "UnitedKingdom", "url": "/global/en/about-us/business-area/emea/united-kingdom"},
    {"label": "Australia", "url": "/global/en/about-us/business-area/apac/australia"},
    {"label": "China", "url": "/global/en/about-us/business-area/apac/china"},
    {"label": "India", "url": "/global/en/about-us/business-area/apac/india"},
    {"label": "Japan", "url": "/global/en/about-us/business-area/apac/japan"},
    {"label": "Korea", "url": "/global/en/about-us/business-area/apac/korea"},
    {"label": "Singapore", "url": "/global/en/about-us/business-area/apac/singapore"},
]

def clean_text(text):
    """Clean HTML entities and whitespace"""
    text = html_module.unescape(text)
    text = text.replace('\xa0', ' ').replace('\u200b', '')
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def extract_phone(text):
    """Extract phone numbers from text"""
    phones = re.findall(r'(?:Tel|Phone|Fon|Fax|Tel\.?|Ph)[:\s]*([+\d\s()\-/]+)', text, re.IGNORECASE)
    if phones:
        return phones[0].strip().rstrip(',').rstrip('–').strip()
    return ''

def is_person_name(text):
    """Check if text is a person's name rather than a facility name"""
    person_indicators = [
        'Herr ', 'Frau ', 'Mr.', 'Ms.', 'Mrs.', 'Dr.',
        'Head of', 'Manager', 'Director', 'Sales', 'Analyst',
        'Supervisor', 'Gerente', 'Jefe', 'Gestora', 'Engenheiro',
        'Secretariat', 'Sekretariat'
    ]
    return any(ind in text for ind in person_indicators)

def extract_facilities_from_accordion(soup, country_label, source_url):
    """Extract facilities from accordion sections"""
    facilities = []
    
    # Find accordion sections
    accordions = soup.find_all('div', class_=re.compile('accordion'))
    
    for accordion in accordions:
        # Find the "Addresses" tab content
        # Look for divs that contain h5/h4 + p pairs
        divs = accordion.find_all('div', recursive=False)
        
        for div in divs:
            inner_divs = div.find_all('div', recursive=False)
            if len(inner_divs) < 3:
                continue
            
            # Check if this is an address tab (tab label often contains 'Adress', 'Location', etc.)
            tab_label = ''
            if len(inner_divs) >= 2:
                tab_label = inner_divs[1].get_text(strip=True)
            
            # Get the content div (usually the 3rd inner div)
            content_div = inner_divs[2] if len(inner_divs) > 2 else div
            
            # Find h5 elements followed by p elements
            h5_elements = content_div.find_all(['h5', 'h4'])
            
            for h5 in h5_elements:
                h5_html = str(h5)
                h5_text = clean_text(h5.get_text())
                
                # Handle h5 with <br> (like Australia: "Title<br>Company")
                br_parts = re.split(r'<br\s*/?>', h5_html)
                if len(br_parts) > 1:
                    h5_text = clean_text(re.sub(r'<[^>]+>', '', ' - '.join(br_parts)))
                
                # Remove "Adres:" prefix (Poland)
                h5_text = re.sub(r'^Adres:\s*', '', h5_text).strip()
                
                # Skip persons
                if is_person_name(h5_text):
                    continue
                
                # Skip empty
                if not h5_text or len(h5_text) < 3:
                    continue
                
                # Get following p element
                p_elem = h5.find_next_sibling('p')
                if not p_elem:
                    continue
                
                p_html = str(p_elem)
                p_text = clean_text(p_elem.get_text())
                
                # Check if p has <br> (multi-line address)
                if '<br' not in p_html:
                    # Some pages have address in single line
                    if len(p_text) < 10:
                        continue
                
                # Parse address from p tag
                phone = extract_phone(p_html)
                
                # Split by <br> tags
                addr_parts = re.split(r'<br\s*/?>', p_html)
                addr_parts_clean = []
                for part in addr_parts:
                    part_text = clean_text(re.sub(r'<[^>]+>', '', part))
                    # Skip empty, phone, email, directions
                    if not part_text or len(part_text) < 2:
                        continue
                    if any(skip in part_text.lower() for skip in ['google maps', 'google kartor', 'google haritalar', 'e-mail', 'anfahrt', 'directions', 'route']):
                        continue
                    if re.match(r'^(Tel|Phone|Fon|Fax|Ph|POB)[:\s]', part_text, re.IGNORECASE):
                        continue
                    addr_parts_clean.append(part_text)
                
                if not addr_parts_clean:
                    continue
                
                full_address = ', '.join(addr_parts_clean)
                
                facilities.append({
                    'facility_name': h5_text,
                    'address_parts': addr_parts_clean,
                    'full_address': full_address,
                    'phone': phone,
                    'country_page': country_label,
                    'source_url': source_url,
                })
    
    return facilities

def extract_china_facilities(soup, source_url):
    """Special handler for China page with Chinese text"""
    facilities = []
    accordions = soup.find_all('div', class_=re.compile('accordion'))
    
    for accordion in accordions:
        # Find all p tags with <br> in accordion
        p_tags = accordion.find_all('p')
        for p in p_tags:
            p_html = str(p)
            if '<br' not in p_html:
                continue
            
            parts = re.split(r'<br\s*/?>', p_html)
            parts_clean = []
            for part in parts:
                part_text = clean_text(re.sub(r'<[^>]+>', '', part))
                if part_text:
                    parts_clean.append(part_text)
            
            if len(parts_clean) < 3:
                continue
            
            # First part is typically the company name
            name = parts_clean[0]
            
            # Skip if it looks like a person or contact info
            if '电话' in name and len(name) < 15:
                continue
            if '联系' in name:
                continue
            
            # Extract phone
            phone = ''
            addr_parts = []
            for part in parts_clean:
                if '电话' in part or 'Tel' in part or '86-' in part:
                    phone_match = re.search(r'[\d\-\s+()]+', part)
                    if phone_match:
                        phone = phone_match.group().strip()
                else:
                    addr_parts.append(part)
            
            if len(addr_parts) < 2:
                continue
            
            facilities.append({
                'facility_name': addr_parts[0],
                'address_parts': addr_parts[1:],
                'full_address': ', '.join(addr_parts[1:]),
                'phone': phone,
                'country_page': 'China',
                'source_url': source_url,
            })
    
    return facilities

def extract_india_facilities(soup, source_url):
    """Special handler for India page"""
    facilities = []
    accordions = soup.find_all('div', class_=re.compile('accordion'))
    
    for accordion in accordions:
        p_tags = accordion.find_all('p')
        for p in p_tags:
            p_html = str(p)
            if '<br' not in p_html:
                continue
            
            p_text = clean_text(p.get_text())
            
            # Skip person entries  
            if any(skip in p_text for skip in ['Managing Director', 'Head of', 'Sales India', 'E-Mail']):
                continue
            
            parts = re.split(r'<br\s*/?>', p_html)
            parts_clean = []
            for part in parts:
                part_text = clean_text(re.sub(r'<[^>]+>', '', part))
                if part_text:
                    parts_clean.append(part_text)
            
            if len(parts_clean) < 3:
                continue
            
            # Check if this contains multiple facilities separated by blank parts
            current_facility = []
            current_name = ''
            
            for part in parts_clean:
                if not part.strip():
                    if current_name and current_facility:
                        phone = ''
                        addr_clean = []
                        for cp in current_facility:
                            if 'Phone' in cp or 'Tel' in cp:
                                phone_m = re.search(r'[+\d\s()\-]+', cp.split(':')[-1])
                                if phone_m:
                                    phone = phone_m.group().strip()
                            elif 'Google Maps' not in cp and 'E-Mail' not in cp:
                                addr_clean.append(cp)
                        
                        facilities.append({
                            'facility_name': current_name,
                            'address_parts': addr_clean,
                            'full_address': ', '.join(addr_clean),
                            'phone': phone,
                            'country_page': 'India',
                            'source_url': source_url,
                        })
                        current_facility = []
                        current_name = ''
                elif not current_name:
                    current_name = part
                else:
                    current_facility.append(part)
            
            # Don't forget the last facility
            if current_name and current_facility:
                phone = ''
                addr_clean = []
                for cp in current_facility:
                    if 'Phone' in cp or 'Tel' in cp:
                        phone_m = re.search(r'[+\d\s()\-]+', cp.split(':')[-1])
                        if phone_m:
                            phone = phone_m.group().strip()
                    elif 'Google Maps' not in cp and 'E-Mail' not in cp:
                        addr_clean.append(cp)
                
                if addr_clean:
                    facilities.append({
                        'facility_name': current_name,
                        'address_parts': addr_clean,
                        'full_address': ', '.join(addr_clean),
                        'phone': phone,
                        'country_page': 'India',
                        'source_url': source_url,
                    })
    
    return facilities

def extract_korea_facilities(soup, source_url):
    """Special handler for Korea page"""
    facilities = []
    accordions = soup.find_all('div', class_=re.compile('accordion'))
    
    for accordion in accordions:
        p_tags = accordion.find_all('p')
        for p in p_tags:
            p_html = str(p)
            if '<br' not in p_html:
                continue
            
            p_text = clean_text(p.get_text())
            
            # Skip contact entries
            if '담당' in p_text or '영업' in p_text or '이메일' in p_text:
                continue
            
            parts = re.split(r'<br\s*/?>', p_html)
            parts_clean = []
            for part in parts:
                part_text = clean_text(re.sub(r'<[^>]+>', '', part))
                if part_text:
                    parts_clean.append(part_text)
            
            if len(parts_clean) < 3:
                continue
            
            # In Korean pages: first line = company name, then address lines, last = country
            name = parts_clean[0]
            addr = parts_clean[1:-1]
            country = parts_clean[-1] if '대한민국' in parts_clean[-1] or 'Korea' in parts_clean[-1] else ''
            
            phone = ''
            for part in parts_clean:
                if '전화' in part or 'Tel' in part:
                    phone_m = re.search(r'[+\d\s()\-]+', part)
                    if phone_m:
                        phone = phone_m.group().strip()
            
            facilities.append({
                'facility_name': name,
                'address_parts': addr + ([country] if country else []),
                'full_address': ', '.join(addr + ([country] if country else [])),
                'phone': phone,
                'country_page': 'Korea',
                'source_url': source_url,
            })
    
    return facilities

def extract_japan_facility(soup, source_url):
    """Special handler for Japan page"""
    facilities = []
    h5_tags = soup.find_all('h5')
    for h5 in h5_tags:
        h5_text = clean_text(h5.get_text())
        if 'コンチネンタル' in h5_text or 'ContiTech' in h5_text:
            p = h5.find_next_sibling('p')
            if p:
                p_html = str(p)
                parts = re.split(r'<br\s*/?>', p_html)
                parts_clean = [clean_text(re.sub(r'<[^>]+>', '', part)) for part in parts if clean_text(re.sub(r'<[^>]+>', '', part))]
                if parts_clean:
                    facilities.append({
                        'facility_name': h5_text,
                        'address_parts': parts_clean,
                        'full_address': ', '.join(parts_clean),
                        'phone': '',
                        'country_page': 'Japan',
                        'source_url': source_url,
                    })
    
    # Also look for address in text blocks
    accordions = soup.find_all('div', class_=re.compile('accordion'))
    for accordion in accordions:
        p_tags = accordion.find_all('p')
        for p in p_tags:
            p_html = str(p)
            if '<br' not in p_html:
                continue
            p_text = clean_text(p.get_text())
            if '〒' in p_text or '横浜' in p_text or '東京' in p_text:
                parts = re.split(r'<br\s*/?>', p_html)
                parts_clean = [clean_text(re.sub(r'<[^>]+>', '', part)) for part in parts if clean_text(re.sub(r'<[^>]+>', '', part))]
                name = 'ContiTech Japan'
                facilities.append({
                    'facility_name': name,
                    'address_parts': parts_clean,
                    'full_address': ', '.join(parts_clean),
                    'phone': '',
                    'country_page': 'Japan',
                    'source_url': source_url,
                })
    
    return facilities

# Extract from North America - special handling for state-based service centers 
def post_process_north_america(facilities):
    """Fix North America facilities that have state names as facility names"""
    processed = []
    for f in facilities:
        name = f['facility_name']
        # Skip customer service entries
        if 'Customer Service' in name:
            continue
        # For state entries like "Alabama: 917 Industrial Park Circle..."
        if ':' in f['full_address'] and '–' in f['full_address']:
            # These have contact person embedded - clean them
            addr = f['full_address']
            # Remove the contact person part (after last –)
            parts = addr.split(',')
            clean_parts = []
            for part in parts:
                if '–' in part:
                    part = part.split('–')[0].strip()
                if re.match(r'^\(\d{3}\)', part.strip()):
                    continue
                clean_parts.append(part.strip())
            f['full_address'] = ', '.join([p for p in clean_parts if p])
            f['address_parts'] = clean_parts
        processed.append(f)
    return processed

# Main extraction
all_facilities = []

for country in COUNTRIES:
    full_url = BASE_URL + country['url']
    try:
        r = requests.get(full_url, headers=headers, verify=False, timeout=30)
        if r.status_code != 200:
            print(f"SKIP {country['label']}: Status {r.status_code}")
            continue
        
        if len(r.text) < 3000:
            print(f"SKIP {country['label']}: Page too small ({len(r.text)} bytes), likely redirect")
            continue
        
        soup = BeautifulSoup(r.text, 'html.parser')
        
        if country['label'] == 'China':
            facilities = extract_china_facilities(soup, full_url)
        elif country['label'] == 'India':
            facilities = extract_india_facilities(soup, full_url)
        elif country['label'] == 'Korea':
            facilities = extract_korea_facilities(soup, full_url)
        elif country['label'] == 'Japan':
            facilities = extract_japan_facility(soup, full_url)
        else:
            facilities = extract_facilities_from_accordion(soup, country['label'], full_url)
        
        if country['label'] == 'NorthAmerica':
            facilities = post_process_north_america(facilities)
        
        # Filter out contact-only entries (no real address)
        real_facilities = []
        for f in facilities:
            # Must have at least some address content
            if len(f['full_address']) < 10:
                continue
            # Skip entries that are purely contact info
            if all(any(skip in part.lower() for skip in ['email', 'e-mail', 'mail']) for part in f['address_parts']):
                continue
            real_facilities.append(f)
        
        print(f"{country['label']}: {len(real_facilities)} facilities")
        for f in real_facilities:
            print(f"  - {f['facility_name'][:50]}: {f['full_address'][:100]}")
        
        all_facilities.extend(real_facilities)
        
    except Exception as e:
        print(f"ERROR {country['label']}: {e}")
        import traceback
        traceback.print_exc()

print(f"\n\nTOTAL FACILITIES: {len(all_facilities)}")

# Save
with open('all_facilities_v2.json', 'w', encoding='utf-8') as f:
    json.dump(all_facilities, f, indent=2, ensure_ascii=False)

print("Saved to all_facilities_v2.json")
